/**
 * Document Management System
 * Main JavaScript file
 */

// Wait for the document to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Enable Bootstrap tooltips
    $('[data-toggle="tooltip"]').tooltip();
    
    // Enable Bootstrap popovers
    $('[data-toggle="popover"]').popover();
    
    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        $('.alert-dismissible').alert('close');
    }, 5000);
    
    // Custom file input - shows the selected file name
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
    
    // Sidebar toggle for small screens
    $('#sidebarToggle').on('click', function(e) {
        e.preventDefault();
        $('body').toggleClass('sidebar-toggled');
        $('.sidebar').toggleClass('toggled');
    });
    
    // Close sidebar when window is small
    if (window.innerWidth < 768) {
        $('body').addClass('sidebar-toggled');
        $('.sidebar').addClass('toggled');
    }
    
    // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
    $('body.fixed-nav .sidebar').on('mousewheel DOMMouseScroll wheel', function(e) {
        if (window.innerWidth > 768) {
            var e0 = e.originalEvent,
                delta = e0.wheelDelta || -e0.detail;
            this.scrollTop += (delta < 0 ? 1 : -1) * 30;
            e.preventDefault();
        }
    });
    
    // Scroll to top button
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#scroll-to-top').fadeIn();
        } else {
            $('#scroll-to-top').fadeOut();
        }
    });
    
    $('#scroll-to-top').click(function() {
        $('html, body').animate({
            scrollTop: 0
        }, 800);
        return false;
    });
    
    // Confirm delete actions
    $('.confirm-delete').on('click', function(e) {
        if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
            e.preventDefault();
        }
    });
    
    // Form validation
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all forms we want to apply custom validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    
    // Animate progress bars when they become visible
    var animateProgressBars = function() {
        $('.progress .progress-bar').each(function() {
            var progressValue = $(this).attr('aria-valuenow');
            $(this).css('width', '0%').animate({
                width: progressValue + '%'
            }, 1000);
        });
    };
    
    animateProgressBars();
    
    // Add "loading" state to buttons when clicked
    $('.btn-loading').on('click', function() {
        var loadingText = $(this).data('loading-text');
        if (loadingText) {
            var $this = $(this);
            $this.data('original-text', $this.html());
            $this.html(loadingText);
            $this.prop('disabled', true);
        }
    });
    
    // Date pickers initialization
    if ($.fn.datepicker) {
        $('.datepicker').datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true,
            todayHighlight: true
        });
    }
    
    // Dropzone file upload initialization
    if (typeof Dropzone !== 'undefined') {
        Dropzone.autoDiscover = false;
        
        $('.dropzone-upload').each(function() {
            var uploadUrl = $(this).data('upload-url');
            var maxFiles = $(this).data('max-files') || 1;
            var maxFilesize = $(this).data('max-filesize') || 10; // MB
            var acceptedFiles = $(this).data('accepted-files') || '.pdf';
            
            $(this).dropzone({
                url: uploadUrl,
                maxFiles: maxFiles,
                maxFilesize: maxFilesize,
                acceptedFiles: acceptedFiles,
                addRemoveLinks: true,
                dictDefaultMessage: 'Drop files here or click to upload',
                dictFileTooBig: 'File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB',
                dictInvalidFileType: 'You can\'t upload files of this type',
                dictResponseError: 'Server responded with {{statusCode}} code',
                dictCancelUpload: 'Cancel upload',
                dictUploadCanceled: 'Upload canceled',
                dictRemoveFile: 'Remove file',
                dictMaxFilesExceeded: 'You can only upload {{maxFiles}} file(s)'
            });
        });
    }
    
    // Initialize rich text editors
    if (typeof ClassicEditor !== 'undefined') {
        document.querySelectorAll('.rich-text-editor').forEach(function(editorElement) {
            ClassicEditor
                .create(editorElement)
                .catch(function(error) {
                    console.error(error);
                });
        });
    }
    
    // Handle copy to clipboard functionality
    $('.copy-to-clipboard').on('click', function() {
        var textToCopy = $(this).data('clipboard-text');
        var tempInput = document.createElement('input');
        document.body.appendChild(tempInput);
        tempInput.value = textToCopy;
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        
        // Show feedback
        var $this = $(this);
        var originalText = $this.html();
        $this.html('<i class="fas fa-check"></i> Copied!');
        setTimeout(function() {
            $this.html(originalText);
        }, 2000);
    });
    
    // Add recipient row functionality
    $('#add-recipient-row').on('click', function() {
        var recipientRow = $('.recipient-row:first').clone();
        recipientRow.find('input').val('');
        recipientRow.insertBefore($(this).parent());
        
        // Enable remove button
        recipientRow.find('.remove-recipient').removeClass('d-none');
    });
    
    // Remove recipient row
    $(document).on('click', '.remove-recipient', function() {
        $(this).closest('.recipient-row').remove();
    });
    
    // Show/hide password functionality
    $('.password-toggle').on('click', function() {
        var passwordInput = $(this).closest('.input-group').find('input');
        var icon = $(this).find('i');
        
        if (passwordInput.attr('type') === 'password') {
            passwordInput.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            passwordInput.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });
    
    // Initialize charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
        // Document status chart
        var statusChartCanvas = document.getElementById('documentStatusChart');
        if (statusChartCanvas) {
            var statusChartData = $(statusChartCanvas).data('chart');
            
            if (statusChartData) {
                new Chart(statusChartCanvas, {
                    type: 'doughnut',
                    data: {
                        labels: statusChartData.labels,
                        datasets: [{
                            data: statusChartData.data,
                            backgroundColor: [
                                '#1cc88a', // Completed
                                '#4e73df', // Sent
                                '#36b9cc', // Signed
                                '#858796', // Draft
                                '#5a5c69'  // Archived
                            ],
                            hoverBackgroundColor: [
                                '#17a673',
                                '#2e59d9',
                                '#2c9faf',
                                '#717384',
                                '#4e4f58'
                            ],
                            hoverBorderColor: "rgba(234, 236, 244, 1)",
                        }],
                    },
                    options: {
                        maintainAspectRatio: false,
                        tooltips: {
                            backgroundColor: "rgb(255,255,255)",
                            bodyFontColor: "#858796",
                            borderColor: '#dddfeb',
                            borderWidth: 1,
                            xPadding: 15,
                            yPadding: 15,
                            displayColors: false,
                            caretPadding: 10,
                        },
                        legend: {
                            display: true,
                            position: 'bottom'
                        },
                        cutoutPercentage: 70,
                    },
                });
            }
        }
    }
});

// Helper function to format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Helper function to format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

// Helper function to show loading spinner
function showLoading(element, message) {
    const loadingHtml = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="sr-only">Loading...</span>
            </div>
            <p class="mt-2">${message || 'Loading...'}</p>
        </div>
    `;
    
    element.innerHTML = loadingHtml;
}

// Helper function to debounce function calls
function debounce(func, wait, immediate) {
    let timeout;
    return function() {
        const context = this, args = arguments;
        const later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
}
