<?php
// Application constants
define('APP_NAME', 'DocuSign Management System');
define('APP_URL', 'http://' . $_SERVER['HTTP_HOST']);
define('UPLOAD_DIR', $_SERVER['DOCUMENT_ROOT'] . '/uploads/');
define('ALLOWED_EXTENSIONS', ['pdf']);
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
?>
