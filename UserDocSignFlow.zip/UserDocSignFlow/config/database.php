<?php
// Database configuration - using PostgreSQL
define('DB_HOST', getenv('PGHOST'));
define('DB_PORT', getenv('PGPORT'));
define('DB_USER', getenv('PGUSER'));
define('DB_PASS', getenv('PGPASSWORD'));
define('DB_NAME', getenv('PGDATABASE'));

// Create database connection using PostgreSQL
$connStr = sprintf(
    "host=%s port=%s dbname=%s user=%s password=%s", 
    DB_HOST, 
    DB_PORT, 
    DB_NAME, 
    DB_USER, 
    DB_PASS
);

$conn = pg_connect($connStr);

// Check connection
if (!$conn) {
    die("Connection failed: " . pg_last_error());
}
?>
