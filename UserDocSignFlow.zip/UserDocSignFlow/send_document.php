<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Get document ID from URL
$documentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Check if document exists and belongs to the current user
$userId = $_SESSION['user_id'];
$document = getUserDocument($documentId, $userId);

if (!$document) {
    // Document not found or doesn't belong to user
    redirect("/documents.php");
}

// Check if document is already sent
if ($document['status'] != 'draft') {
    $message = "This document has already been sent.";
    $messageType = "warning";
}

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">Send Document for Signature</h1>
        </div>
        
        <?php if (isset($message)): ?>
        <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        
        <?php if ($document['status'] == 'draft'): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Document Details</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <table class="table table-sm">
                            <tr>
                                <th width="120">File Name:</th>
                                <td><?php echo htmlspecialchars($document['original_filename']); ?></td>
                            </tr>
                            <tr>
                                <th>File Size:</th>
                                <td><?php echo formatFileSize($document['file_size']); ?></td>
                            </tr>
                            <tr>
                                <th>Description:</th>
                                <td><?php echo htmlspecialchars($document['description'] ?? 'No description'); ?></td>
                            </tr>
                            <tr>
                                <th>Created:</th>
                                <td><?php echo formatDate($document['created_at']); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <i class="fas fa-file-pdf fa-6x text-danger mb-3"></i>
                            <br>
                            <a href="/view_document.php?id=<?php echo $document['id']; ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                                <i class="fas fa-eye"></i> Preview Document
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Add Recipients</h5>
            </div>
            <div class="card-body">
                <form action="/process/send_document_process.php" method="post" id="send-document-form">
                    <input type="hidden" name="document_id" value="<?php echo $document['id']; ?>">
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> Add recipients who need to sign this document.
                    </div>
                    
                    <div id="recipients-container">
                        <div class="recipient-row card mb-3">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Recipient Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="recipients[0][name]" required>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Recipient Email <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" name="recipients[0][email]" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2 d-flex align-items-end">
                                        <button type="button" class="btn btn-danger btn-block remove-recipient" disabled>
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <button type="button" id="add-recipient" class="btn btn-outline-secondary">
                            <i class="fas fa-plus"></i> Add Another Recipient
                        </button>
                    </div>
                    
                    <hr>
                    
                    <div class="form-group">
                        <label for="email_subject">Email Subject <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="email_subject" name="email_subject" 
                               value="Please sign: <?php echo htmlspecialchars($document['original_filename']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email_message">Email Message <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="email_message" name="email_message" rows="4" required>Hello,

I've sent you a document to review and sign. Please click the link below to view and sign the document.

Thank you!</textarea>
                    </div>
                    
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="send_copy" name="send_copy" checked>
                            <label class="custom-control-label" for="send_copy">Send me a copy of the email</label>
                        </div>
                    </div>
                    
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-paper-plane"></i> Send Document
                        </button>
                        <a href="/documents.php" class="btn btn-outline-secondary btn-lg ml-2">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
        <?php else: ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-paper-plane fa-4x text-primary mb-3"></i>
                <h4>This document has already been sent</h4>
                <p class="mb-4">You can view the document and check the signature status.</p>
                <div>
                    <a href="/view_document.php?id=<?php echo $document['id']; ?>" class="btn btn-primary">
                        <i class="fas fa-eye"></i> View Document
                    </a>
                    <a href="/documents.php" class="btn btn-outline-secondary ml-2">
                        <i class="fas fa-arrow-left"></i> Back to Documents
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let recipientCount = 1;
    
    // Add recipient row
    document.getElementById('add-recipient').addEventListener('click', function() {
        const container = document.getElementById('recipients-container');
        const recipientRow = document.createElement('div');
        recipientRow.className = 'recipient-row card mb-3';
        recipientRow.innerHTML = `
            <div class="card-body">
                <div class="row">
                    <div class="col-md-5">
                        <div class="form-group">
                            <label>Recipient Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="recipients[${recipientCount}][name]" required>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <label>Recipient Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="recipients[${recipientCount}][email]" required>
                        </div>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="button" class="btn btn-danger btn-block remove-recipient">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.appendChild(recipientRow);
        recipientCount++;
        
        // Enable remove button on first recipient if more than one exists
        if (recipientCount > 1) {
            document.querySelector('.remove-recipient[disabled]')?.removeAttribute('disabled');
        }
    });
    
    // Remove recipient row
    document.addEventListener('click', function(e) {
        if (e.target.closest('.remove-recipient')) {
            const button = e.target.closest('.remove-recipient');
            const row = button.closest('.recipient-row');
            row.remove();
            recipientCount--;
            
            // Disable remove button on first recipient if only one exists
            if (recipientCount === 1) {
                document.querySelector('.remove-recipient').setAttribute('disabled', 'disabled');
            }
            
            // Re-index the form names
            const rows = document.querySelectorAll('.recipient-row');
            rows.forEach((row, index) => {
                const nameInput = row.querySelector('input[name^="recipients"][name$="[name]"]');
                const emailInput = row.querySelector('input[name^="recipients"][name$="[email]"]');
                
                nameInput.name = `recipients[${index}][name]`;
                emailInput.name = `recipients[${index}][email]`;
            });
        }
    });
    
    // Form validation before submit
    document.getElementById('send-document-form').addEventListener('submit', function(e) {
        const recipientRows = document.querySelectorAll('.recipient-row');
        if (recipientRows.length === 0) {
            e.preventDefault();
            alert('Please add at least one recipient.');
            return false;
        }
        
        // Show loading state
        const submitButton = this.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...';
    });
});
</script>

<?php include 'includes/footer.php'; ?>
