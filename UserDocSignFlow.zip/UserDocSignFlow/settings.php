<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Get current user data
$userId = $_SESSION['user_id'];

// Get user settings
$settings = $db->getRow("SELECT * FROM settings WHERE user_id = ?", [$userId]);

// If settings don't exist, create default settings
if (!$settings) {
    $db->insert(
        "INSERT INTO settings (user_id, email_notifications) VALUES (?, ?)",
        [$userId, true]
    );
    
    // Refresh settings
    $settings = $db->getRow("SELECT * FROM settings WHERE user_id = ?", [$userId]);
}

// Initialize message variable
$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_settings'])) {
    // Get form data
    $emailNotifications = isset($_POST['email_notifications']) ? 1 : 0;
    $signatureData = isset($_POST['signature_data']) ? $_POST['signature_data'] : null;
    
    // Update settings
    $db->query(
        "UPDATE settings SET email_notifications = ?, signature_image = ? WHERE user_id = ?",
        [$emailNotifications, $signatureData, $userId]
    );
    
    if ($db->affectedRows() > 0) {
        $message = "Settings updated successfully";
        $messageType = "success";
        
        // Refresh settings
        $settings = $db->getRow("SELECT * FROM settings WHERE user_id = ?", [$userId]);
    } else {
        $message = "No changes were made";
        $messageType = "info";
    }
}

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">Settings</h1>
        </div>
        
        <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Application Settings</h5>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="settings-form">
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="email_notifications" name="email_notifications" <?php echo ($settings['email_notifications'] ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="email_notifications">Email Notifications</label>
                        </div>
                        <small class="form-text text-muted">Receive email notifications when documents are signed or when you receive a document to sign.</small>
                    </div>
                    
                    <hr>
                    
                    <div class="form-group">
                        <label>Default Signature</label>
                        <p class="text-muted small">Create a signature that you can use when signing documents. This will be your default signature.</p>
                        
                        <div class="border rounded p-3 mb-3">
                            <?php if (!empty($settings['signature_image'])): ?>
                            <div class="text-center mb-3">
                                <img src="<?php echo $settings['signature_image']; ?>" alt="Your signature" class="img-fluid" style="max-height: 150px;">
                            </div>
                            <button type="button" class="btn btn-outline-danger btn-sm btn-block" id="clear-signature">
                                <i class="fas fa-trash-alt"></i> Clear Signature
                            </button>
                            <?php else: ?>
                            <div class="text-center mb-3">
                                <p>No signature set. Draw your signature below.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="signature-pad-container border rounded mb-3">
                            <div class="text-right p-2 bg-light border-bottom">
                                <button type="button" class="btn btn-sm btn-secondary" id="clear-pad">
                                    <i class="fas fa-eraser"></i> Clear
                                </button>
                            </div>
                            <canvas id="signature-pad" class="signature-pad"></canvas>
                        </div>
                        
                        <input type="hidden" name="signature_data" id="signature_data" value="<?php echo htmlspecialchars($settings['signature_image'] ?? ''); ?>">
                    </div>
                    
                    <button type="submit" name="update_settings" class="btn btn-primary">Save Settings</button>
                </form>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Account Data</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> This section allows you to export or delete your account data.
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Export Data</h5>
                                <p class="card-text">Download a copy of your personal data.</p>
                                <button type="button" class="btn btn-outline-primary">
                                    <i class="fas fa-download"></i> Export Data
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title text-danger">Delete Account</h5>
                                <p class="card-text">Permanently delete your account and all associated data.</p>
                                <button type="button" class="btn btn-outline-danger" data-toggle="modal" data-target="#deleteAccountModal">
                                    <i class="fas fa-trash-alt"></i> Delete Account
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Account Modal -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1" role="dialog" aria-labelledby="deleteAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteAccountModalLabel">Delete Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> <strong>Warning:</strong> This action cannot be undone.
                </div>
                <p>Are you sure you want to delete your account? All of your documents, signatures, and personal data will be permanently deleted.</p>
                <form id="delete-account-form">
                    <div class="form-group">
                        <label for="delete-confirmation">Please type "DELETE" to confirm:</label>
                        <input type="text" class="form-control" id="delete-confirmation" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirm-delete" disabled>Delete Account</button>
            </div>
        </div>
    </div>
</div>

<!-- Signature Pad JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize signature pad when the DOM is loaded
    const canvas = document.getElementById('signature-pad');
    const signaturePad = new SignaturePad(canvas, {
        backgroundColor: 'rgb(255, 255, 255)',
        penColor: 'rgb(0, 0, 0)'
    });
    
    // Resize canvas
    function resizeCanvas() {
        const ratio = Math.max(window.devicePixelRatio || 1, 1);
        canvas.width = canvas.offsetWidth * ratio;
        canvas.height = 200 * ratio;
        canvas.getContext("2d").scale(ratio, ratio);
        signaturePad.clear(); // Clear the canvas
        
        // If there's a stored signature, load it
        const storedSignature = document.getElementById('signature_data').value;
        if (storedSignature) {
            // Don't load to pad, we'll display it separately
        }
    }
    
    // Initial resize
    resizeCanvas();
    
    // Resize canvas on window resize
    window.addEventListener("resize", resizeCanvas);
    
    // Clear signature pad
    document.getElementById('clear-pad').addEventListener('click', function() {
        signaturePad.clear();
    });
    
    // Clear saved signature
    document.getElementById('clear-signature').addEventListener('click', function() {
        document.getElementById('signature_data').value = '';
        this.closest('.border').querySelector('img').style.display = 'none';
        this.style.display = 'none';
    });
    
    // Save signature on form submit
    document.getElementById('settings-form').addEventListener('submit', function() {
        if (!signaturePad.isEmpty()) {
            const signatureData = signaturePad.toDataURL();
            document.getElementById('signature_data').value = signatureData;
        }
    });
    
    // Handle delete account confirmation
    const deleteConfirmationInput = document.getElementById('delete-confirmation');
    const confirmDeleteButton = document.getElementById('confirm-delete');
    
    deleteConfirmationInput.addEventListener('input', function() {
        if (this.value === 'DELETE') {
            confirmDeleteButton.disabled = false;
        } else {
            confirmDeleteButton.disabled = true;
        }
    });
    
    confirmDeleteButton.addEventListener('click', function() {
        // Here you would send a request to delete the account
        // For this demo, we'll just show an alert
        alert('Account deletion functionality would be implemented here.');
        $('#deleteAccountModal').modal('hide');
    });
});
</script>

<?php include 'includes/footer.php'; ?>
