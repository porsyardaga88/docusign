<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Get current user ID
$userId = $_SESSION['user_id'];

// Get filter parameters
$status = isset($_GET['status']) ? clean($_GET['status']) : '';
$search = isset($_GET['search']) ? clean($_GET['search']) : '';

// Build query based on filters
$params = [$userId];
$whereClause = "user_id = ?";

if (!empty($status)) {
    $whereClause .= " AND status = ?";
    $params[] = $status;
}

if (!empty($search)) {
    $whereClause .= " AND (original_filename LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Get document count
$totalDocuments = $db->getValue("SELECT COUNT(*) FROM documents WHERE $whereClause", $params);

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$totalPages = ceil($totalDocuments / $limit);

// Get documents
$documents = $db->getRows(
    "SELECT * FROM documents WHERE $whereClause ORDER BY updated_at DESC LIMIT $limit OFFSET $offset",
    $params
);

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">My Documents</h1>
            <a href="/upload.php" class="btn btn-primary">
                <i class="fas fa-upload"></i> Upload Document
            </a>
        </div>
        
        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form-inline">
                    <div class="form-group mr-2 mb-2">
                        <label for="status" class="sr-only">Status</label>
                        <select class="form-control" id="status" name="status">
                            <option value="">All Statuses</option>
                            <option value="draft" <?php echo ($status == 'draft') ? 'selected' : ''; ?>>Draft</option>
                            <option value="sent" <?php echo ($status == 'sent') ? 'selected' : ''; ?>>Sent</option>
                            <option value="signed" <?php echo ($status == 'signed') ? 'selected' : ''; ?>>Signed</option>
                            <option value="completed" <?php echo ($status == 'completed') ? 'selected' : ''; ?>>Completed</option>
                            <option value="archived" <?php echo ($status == 'archived') ? 'selected' : ''; ?>>Archived</option>
                        </select>
                    </div>
                    <div class="form-group mr-2 mb-2">
                        <label for="search" class="sr-only">Search</label>
                        <input type="text" class="form-control" id="search" name="search" placeholder="Search documents" value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="btn btn-secondary mb-2">Filter</button>
                    <?php if (!empty($status) || !empty($search)): ?>
                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="btn btn-outline-secondary mb-2 ml-2">Clear Filters</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <!-- Documents list -->
        <div class="card">
            <div class="card-body p-0">
                <?php if (count($documents) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Document Name</th>
                                <th>Status</th>
                                <th>Date Modified</th>
                                <th>Size</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($documents as $document): ?>
                            <tr>
                                <td>
                                    <a href="/view_document.php?id=<?php echo $document['id']; ?>" class="document-name">
                                        <i class="fas fa-file-pdf text-danger mr-2"></i>
                                        <?php echo htmlspecialchars($document['original_filename']); ?>
                                    </a>
                                    <?php if (!empty($document['description'])): ?>
                                    <small class="d-block text-muted"><?php echo htmlspecialchars(substr($document['description'], 0, 50)) . (strlen($document['description']) > 50 ? '...' : ''); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo getStatusBadge($document['status']); ?></td>
                                <td><?php echo formatDate($document['updated_at']); ?></td>
                                <td><?php echo formatFileSize($document['file_size']); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="/view_document.php?id=<?php echo $document['id']; ?>" class="btn btn-info" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if ($document['status'] == 'draft'): ?>
                                        <a href="/send_document.php?id=<?php echo $document['id']; ?>" class="btn btn-primary" title="Send">
                                            <i class="fas fa-paper-plane"></i>
                                        </a>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <span class="sr-only">More actions</span>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="/view_document.php?id=<?php echo $document['id']; ?>&download=1">
                                                <i class="fas fa-download mr-2"></i> Download
                                            </a>
                                            <?php if ($document['status'] != 'archived'): ?>
                                            <a class="dropdown-item text-warning" href="/process/archive_document.php?id=<?php echo $document['id']; ?>">
                                                <i class="fas fa-archive mr-2"></i> Archive
                                            </a>
                                            <?php endif; ?>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item text-danger" href="#" onclick="confirmDelete(<?php echo $document['id']; ?>)">
                                                <i class="fas fa-trash-alt mr-2"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <div class="card-footer">
                    <nav aria-label="Documents pagination">
                        <ul class="pagination justify-content-center mb-0">
                            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="<?php echo ($page <= 1) ? '#' : htmlspecialchars($_SERVER["PHP_SELF"]) . '?page=' . ($page - 1) . (!empty($status) ? '&status=' . urlencode($status) : '') . (!empty($search) ? '&search=' . urlencode($search) : ''); ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            </li>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                                <a class="page-link" href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?page=' . $i . (!empty($status) ? '&status=' . urlencode($status) : '') . (!empty($search) ? '&search=' . urlencode($search) : ''); ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?php echo ($page >= $totalPages) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="<?php echo ($page >= $totalPages) ? '#' : htmlspecialchars($_SERVER["PHP_SELF"]) . '?page=' . ($page + 1) . (!empty($status) ? '&status=' . urlencode($status) : '') . (!empty($search) ? '&search=' . urlencode($search) : ''); ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
                
                <?php else: ?>
                <div class="text-center py-5">
                    <div class="mb-3">
                        <i class="fas fa-file-alt fa-4x text-muted"></i>
                    </div>
                    <h5>No documents found</h5>
                    <?php if (!empty($status) || !empty($search)): ?>
                    <p class="text-muted">Try changing your search criteria or clearing filters</p>
                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="btn btn-outline-primary">Clear Filters</a>
                    <?php else: ?>
                    <p class="text-muted">Upload your first document to get started</p>
                    <a href="/upload.php" class="btn btn-primary">Upload Document</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteModalLabel">Delete Document</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this document? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a href="#" id="confirmDeleteBtn" class="btn btn-danger">Delete</a>
            </div>
        </div>
    </div>
</div>

<script>
function confirmDelete(documentId) {
    document.getElementById('confirmDeleteBtn').href = '/process/delete_document.php?id=' + documentId;
    $('#deleteModal').modal('show');
}
</script>

<?php include 'includes/footer.php'; ?>
