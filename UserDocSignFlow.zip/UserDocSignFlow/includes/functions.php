<?php
require_once 'db.php';

// Clean and validate input data
function clean($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Redirect to a specific page
function redirect($url) {
    header("Location: $url");
    exit;
}

// Require login to access a page
function requireLogin() {
    if (!isLoggedIn()) {
        redirect("/login.php");
    }
}

// Generate a random token
function generateToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

// Hash password
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Verify password
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Get current user data
function getCurrentUser() {
    global $db;
    
    if (!isLoggedIn()) {
        return null;
    }
    
    return $db->getRow("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
}

// Get document by ID
function getDocument($documentId) {
    global $db;
    
    return $db->getRow("SELECT * FROM documents WHERE id = ?", [$documentId]);
}

// Get document by ID with owner validation
function getUserDocument($documentId, $userId) {
    global $db;
    
    return $db->getRow("SELECT * FROM documents WHERE id = ? AND user_id = ?", [$documentId, $userId]);
}

// Get recipients for a document
function getDocumentRecipients($documentId) {
    global $db;
    
    return $db->getRows("SELECT * FROM recipients WHERE document_id = ?", [$documentId]);
}

// Get recipient by token
function getRecipientByToken($token) {
    global $db;
    
    return $db->getRow("SELECT * FROM recipients WHERE token = ?", [$token]);
}

// Get signatures for a document
function getDocumentSignatures($documentId) {
    global $db;
    
    return $db->getRows("SELECT * FROM signatures WHERE document_id = ?", [$documentId]);
}

// Simple email function (without PHPMailer)
function sendEmail($recipient, $subject, $message, $attachments = []) {
    // For demonstration purposes, we'll simulate email sending without requiring PHPMailer
    
    // Define headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // Default sender if constants are not defined
    $fromEmail = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'noreply@example.com';
    $fromName = defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Document Management System';
    
    $headers .= "From: {$fromName} <{$fromEmail}>" . "\r\n";
    
    // Log the email details for debugging
    error_log("Email simulation - To: $recipient");
    error_log("Email simulation - Subject: $subject");
    error_log("Email simulation - Headers: $headers");
    
    // Log attachments information
    if (!empty($attachments)) {
        foreach ($attachments as $attachment) {
            error_log("Email simulation - Would attach: " . ($attachment['name'] ?? 'unnamed file'));
        }
    }
    
    // In development environment, we'll just simulate success
    return true;
    
    // In production environment, use PHP's mail function:
    // return mail($recipient, $subject, $message, $headers);
}

// Format date for display
function formatDate($date) {
    return date('F j, Y, g:i a', strtotime($date));
}

// Get document status badge HTML
function getStatusBadge($status) {
    $badgeClass = '';
    
    switch ($status) {
        case 'draft':
            $badgeClass = 'badge-secondary';
            break;
        case 'sent':
            $badgeClass = 'badge-primary';
            break;
        case 'signed':
            $badgeClass = 'badge-info';
            break;
        case 'completed':
            $badgeClass = 'badge-success';
            break;
        case 'archived':
            $badgeClass = 'badge-dark';
            break;
        default:
            $badgeClass = 'badge-light';
    }
    
    return '<span class="badge ' . $badgeClass . '">' . ucfirst($status) . '</span>';
}

// Format file size for display
function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    
    return round($bytes, 2) . ' ' . $units[$i];
}

// Create a thumbnail from the first page of a PDF
function createPdfThumbnail($pdfPath, $thumbnailPath) {
    // In a real implementation, you would use a library like Imagick or GhostScript
    // This is a simplified version that doesn't actually create a thumbnail
    return true;
}

// Count documents by status for a user
function countDocumentsByStatus($userId, $status) {
    global $db;
    
    return $db->getValue("SELECT COUNT(*) FROM documents WHERE user_id = ? AND status = ?", [$userId, $status]);
}

// Generate sign URL for a recipient
function generateSignUrl($token) {
    return BASE_URL . "/sign_document.php?token=" . $token;
}

// Create a demo user account if none exists
function createDemoUserIfNotExists() {
    global $db;
    
    $existingUser = $db->getRow("SELECT * FROM users WHERE username = ?", ['demo']);
    
    if (!$existingUser) {
        $hashedPassword = hashPassword('demo123');
        
        $userId = $db->insert(
            "INSERT INTO users (username, email, password, full_name) VALUES (?, ?, ?, ?)",
            ['demo', 'demo@example.com', $hashedPassword, 'Demo User']
        );
        
        // Create default settings for demo user
        $db->insert(
            "INSERT INTO settings (user_id, email_notifications) VALUES (?, ?)",
            [$userId, true]
        );
        
        return true;
    }
    
    return false;
}

// Call this function to ensure demo user exists
createDemoUserIfNotExists();
?>
