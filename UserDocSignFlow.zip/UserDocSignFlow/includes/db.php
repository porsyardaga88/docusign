<?php
require_once 'config.php';

class Database {
    private $connection;
    
    // Constructor - establishes database connection
    public function __construct() {
        $connectionString = sprintf(
            "host=%s port=%s dbname=%s user=%s password=%s", 
            DB_SERVER, 
            DB_PORT, 
            DB_NAME, 
            DB_USERNAME, 
            DB_PASSWORD
        );
        
        $this->connection = pg_connect($connectionString);
        
        if (!$this->connection) {
            die("Connection failed: " . pg_last_error());
        }
    }
    
    // Execute query with parameters
    public function query($sql, $params = [], $throwError = true) {
        try {
            if (!empty($params)) {
                // Convert parameters for PostgreSQL parametrized queries ($1, $2, etc.)
                $i = 1;
                $paramValues = [];
                
                // Replace ? with $1, $2, etc.
                $sql = preg_replace_callback('/\?/', function($matches) use (&$i) {
                    return '$' . $i++;
                }, $sql);
                
                foreach ($params as $param) {
                    $paramValues[] = $param;
                }
                
                $result = pg_query_params($this->connection, $sql, $paramValues);
            } else {
                try {
                    $result = pg_query($this->connection, $sql);
                } catch (Exception $e) {
                    error_log("Exception in pg_query: " . $e->getMessage());
                    throw $e;
                }
            }
            
            if (!$result) {
                $error = pg_last_error($this->connection);
                error_log("Query failed on SQL: " . $sql);
                error_log("Error message: " . $error);
                
                if ($throwError) {
                    throw new Exception("Query failed: " . $error);
                } else {
                    return false;
                }
            }
            
            return $result;
        } catch (Exception $e) {
            if ($throwError) {
                throw $e;
            } else {
                error_log($e->getMessage());
                return false;
            }
        }
    }
    
    // Insert data and return the inserted ID
    public function insert($sql, $params = []) {
        // For PostgreSQL, we need to add "RETURNING id" to get the last insert ID
        if (stripos($sql, 'INSERT INTO') !== false && stripos($sql, 'RETURNING') === false) {
            $sql .= ' RETURNING id';
        }
        
        $result = $this->query($sql, $params);
        $row = pg_fetch_row($result);
        
        return $row ? $row[0] : null;
    }
    
    // Get a single row as an associative array
    public function getRow($sql, $params = []) {
        $result = $this->query($sql, $params);
        
        if (pg_num_rows($result) > 0) {
            return pg_fetch_assoc($result);
        }
        
        return null;
    }
    
    // Get multiple rows as an array of associative arrays
    public function getRows($sql, $params = []) {
        $result = $this->query($sql, $params);
        $rows = [];
        
        while ($row = pg_fetch_assoc($result)) {
            $rows[] = $row;
        }
        
        return $rows;
    }
    
    // Get a single value from the first row and column
    public function getValue($sql, $params = []) {
        $result = $this->query($sql, $params);
        
        if (pg_num_rows($result) > 0) {
            $row = pg_fetch_row($result);
            return $row[0];
        }
        
        return null;
    }
    
    // Get the number of affected rows from the last query
    public function affectedRows() {
        return pg_affected_rows($this->connection);
    }
    
    // Close the database connection
    public function close() {
        pg_close($this->connection);
    }
    
    // Check if a type exists in PostgreSQL
    private function typeExists($typeName) {
        $result = $this->query("
            SELECT 1 FROM pg_type WHERE typname = '$typeName'
        ", [], false);
        
        return $result && pg_num_rows($result) > 0;
    }
    
    // Create all necessary tables if they don't exist
    public function createTables() {
        // Create document status enum type if it doesn't exist
        if (!$this->typeExists('document_status')) {
            $this->query("
                CREATE TYPE document_status AS ENUM ('draft', 'sent', 'signed', 'completed', 'archived')
            ");
        }
        
        // Create recipient status enum type if it doesn't exist
        if (!$this->typeExists('recipient_status')) {
            $this->query("
                CREATE TYPE recipient_status AS ENUM ('pending', 'viewed', 'signed', 'declined')
            ");
        }
        
        // Users table
        $this->query("
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(255) NOT NULL UNIQUE,
                email VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                full_name VARCHAR(255) NOT NULL,
                position VARCHAR(255) DEFAULT NULL,
                company VARCHAR(255) DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Create the update_modified_column function if it doesn't exist
        try {
            $this->query("
                CREATE OR REPLACE FUNCTION update_modified_column()
                RETURNS TRIGGER AS $$
                BEGIN
                    NEW.updated_at = now();
                    RETURN NEW;
                END;
                $$ language 'plpgsql'
            ");
        } catch (Exception $e) {
            // Function may already exist
        }
        
        // Add updated_at trigger for users if it doesn't exist
        $triggerExists = $this->query("
            SELECT 1 FROM pg_trigger 
            WHERE tgname = 'update_users_updated_at'
        ", [], false);
        
        if (!$triggerExists || pg_num_rows($triggerExists) == 0) {
            try {
                $this->query("
                    CREATE TRIGGER update_users_updated_at
                    BEFORE UPDATE ON users
                    FOR EACH ROW
                    EXECUTE PROCEDURE update_modified_column()
                ");
            } catch (Exception $e) {
                // Trigger may already exist or other issue
                error_log("Error creating users trigger: " . $e->getMessage());
            }
        }
        
        // Documents table
        $this->query("
            CREATE TABLE IF NOT EXISTS documents (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL,
                filename VARCHAR(255) NOT NULL,
                original_filename VARCHAR(255) NOT NULL,
                file_path VARCHAR(512) NOT NULL,
                file_size INTEGER NOT NULL,
                description TEXT,
                status document_status NOT NULL DEFAULT 'draft',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Add updated_at trigger for documents if it doesn't exist
        $triggerExists = $this->query("
            SELECT 1 FROM pg_trigger 
            WHERE tgname = 'update_documents_updated_at'
        ", [], false);
        
        if (!$triggerExists || pg_num_rows($triggerExists) == 0) {
            try {
                $this->query("
                    CREATE TRIGGER update_documents_updated_at
                    BEFORE UPDATE ON documents
                    FOR EACH ROW
                    EXECUTE PROCEDURE update_modified_column()
                ");
            } catch (Exception $e) {
                // Trigger may already exist or other issue
                error_log("Error creating documents trigger: " . $e->getMessage());
            }
        }
        
        // Recipients table
        $this->query("
            CREATE TABLE IF NOT EXISTS recipients (
                id SERIAL PRIMARY KEY,
                document_id INTEGER NOT NULL,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                status recipient_status NOT NULL DEFAULT 'pending',
                token VARCHAR(64) NOT NULL,
                sign_url VARCHAR(512) NOT NULL,
                signed_at TIMESTAMP NULL DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
            )
        ");
        
        // Add updated_at trigger for recipients if it doesn't exist
        $triggerExists = $this->query("
            SELECT 1 FROM pg_trigger 
            WHERE tgname = 'update_recipients_updated_at'
        ", [], false);
        
        if (!$triggerExists || pg_num_rows($triggerExists) == 0) {
            try {
                $this->query("
                    CREATE TRIGGER update_recipients_updated_at
                    BEFORE UPDATE ON recipients
                    FOR EACH ROW
                    EXECUTE PROCEDURE update_modified_column()
                ");
            } catch (Exception $e) {
                // Trigger may already exist or other issue
                error_log("Error creating recipients trigger: " . $e->getMessage());
            }
        }
        
        // Signatures table
        $this->query("
            CREATE TABLE IF NOT EXISTS signatures (
                id SERIAL PRIMARY KEY,
                recipient_id INTEGER NOT NULL,
                document_id INTEGER NOT NULL,
                signature_data TEXT NOT NULL,
                x_coordinate INTEGER NOT NULL,
                y_coordinate INTEGER NOT NULL,
                page_number INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (recipient_id) REFERENCES recipients(id) ON DELETE CASCADE,
                FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
            )
        ");
        
        // Settings table
        $this->query("
            CREATE TABLE IF NOT EXISTS settings (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL,
                email_notifications BOOLEAN NOT NULL DEFAULT TRUE,
                signature_image TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Add updated_at trigger for settings if it doesn't exist
        $triggerExists = $this->query("
            SELECT 1 FROM pg_trigger 
            WHERE tgname = 'update_settings_updated_at'
        ", [], false);
        
        if (!$triggerExists || pg_num_rows($triggerExists) == 0) {
            try {
                $this->query("
                    CREATE TRIGGER update_settings_updated_at
                    BEFORE UPDATE ON settings
                    FOR EACH ROW
                    EXECUTE PROCEDURE update_modified_column()
                ");
            } catch (Exception $e) {
                // Trigger may already exist or other issue
                error_log("Error creating settings trigger: " . $e->getMessage());
            }
        }
        
        // PDF Templates table
        $this->query("
            CREATE TABLE IF NOT EXISTS pdf_templates (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                file_path VARCHAR(512) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        // Add updated_at trigger for pdf_templates if it doesn't exist
        $triggerExists = $this->query("
            SELECT 1 FROM pg_trigger 
            WHERE tgname = 'update_pdf_templates_updated_at'
        ", [], false);
        
        if (!$triggerExists || pg_num_rows($triggerExists) == 0) {
            try {
                $this->query("
                    CREATE TRIGGER update_pdf_templates_updated_at
                    BEFORE UPDATE ON pdf_templates
                    FOR EACH ROW
                    EXECUTE PROCEDURE update_modified_column()
                ");
            } catch (Exception $e) {
                // Trigger may already exist or other issue
                error_log("Error creating pdf_templates trigger: " . $e->getMessage());
            }
        }
    }
}

// Initialize database and create tables
$db = new Database();
$db->createTables();
?>
