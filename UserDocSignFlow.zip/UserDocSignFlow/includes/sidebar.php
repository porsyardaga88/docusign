<div class="sidebar bg-light">
    <div class="sidebar-sticky">
        <div class="text-center mb-4 mt-3">
            <div class="user-avatar">
                <i class="fas fa-user-circle fa-4x text-primary"></i>
            </div>
            <h5 class="mt-2"><?php echo htmlspecialchars($currentUser['full_name']); ?></h5>
            <p class="text-muted small"><?php echo htmlspecialchars($currentUser['email']); ?></p>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>" href="/dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'documents.php') ? 'active' : ''; ?>" href="/documents.php">
                    <i class="fas fa-file-pdf"></i> My Documents
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'upload.php') ? 'active' : ''; ?>" href="/upload.php">
                    <i class="fas fa-upload"></i> Upload Document
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'templates.php') ? 'active' : ''; ?>" href="/templates.php">
                    <i class="fas fa-file-alt"></i> Templates
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'profile.php') ? 'active' : ''; ?>" href="/profile.php">
                    <i class="fas fa-id-card"></i> Profile
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'settings.php') ? 'active' : ''; ?>" href="/settings.php">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
        
        <hr>
        
        <div class="sidebar-heading">Quick Stats</div>
        <div class="px-3 py-2">
            <?php
            $userId = $_SESSION['user_id'];
            $draftCount = countDocumentsByStatus($userId, 'draft');
            $sentCount = countDocumentsByStatus($userId, 'sent');
            $signedCount = countDocumentsByStatus($userId, 'signed');
            $completedCount = countDocumentsByStatus($userId, 'completed');
            ?>
            <div class="small">
                <div class="d-flex justify-content-between mb-1">
                    <span>Draft:</span>
                    <span class="badge badge-secondary"><?php echo $draftCount; ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span>Sent:</span>
                    <span class="badge badge-primary"><?php echo $sentCount; ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span>Signed:</span>
                    <span class="badge badge-info"><?php echo $signedCount; ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span>Completed:</span>
                    <span class="badge badge-success"><?php echo $completedCount; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
