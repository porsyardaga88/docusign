<?php
// Database configuration
define('DB_SERVER', getenv('PGHOST'));
define('DB_USERNAME', getenv('PGUSER'));
define('DB_PASSWORD', getenv('PGPASSWORD'));
define('DB_NAME', getenv('PGDATABASE'));
define('DB_PORT', getenv('PGPORT'));
define('DB_TYPE', 'postgresql'); // Used to determine connection type

// Email configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com'); // Replace with actual email
define('SMTP_PASSWORD', 'your-password'); // Use environment variable in production
define('SMTP_FROM_EMAIL', 'your-email@gmail.com');
define('SMTP_FROM_NAME', 'Document Management System');

// Application configuration
define('BASE_URL', 'http://localhost:5000'); // Adjust for production
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('SESSION_TIME', 3600); // 1 hour

// Create uploads directory if it doesn't exist
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0777, true);
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set default timezone
date_default_timezone_set('UTC');
?>
