<?php if (isLoggedIn()): ?>
        </div>
    </div>
<?php else: ?>
    </div>
<?php endif; ?>

<footer class="footer bg-light mt-5 py-3">
    <div class="container text-center">
        <span class="text-muted">&copy; <?php echo date('Y'); ?> DocuSign Pro - Document Management System</span>
    </div>
</footer>

<!-- jQuery, Popper.js, and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- PDF.js for PDF rendering -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.6.347/pdf.min.js"></script>

<!-- Custom JS -->
<script src="/js/script.js"></script>

</body>
</html>
