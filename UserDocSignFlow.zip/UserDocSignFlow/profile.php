<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Get current user data
$userId = $_SESSION['user_id'];
$user = $db->getRow("SELECT * FROM users WHERE id = ?", [$userId]);

// Initialize message variable
$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    // Get form data
    $fullName = clean($_POST['full_name']);
    $email = clean($_POST['email']);
    $position = clean($_POST['position']);
    $company = clean($_POST['company']);
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format";
        $messageType = "danger";
    } else {
        // Check if email already exists for another user
        $existingEmail = $db->getRow("SELECT * FROM users WHERE email = ? AND id != ?", [$email, $userId]);
        if ($existingEmail) {
            $message = "Email already exists for another user";
            $messageType = "danger";
        } else {
            // Update user profile
            $db->query(
                "UPDATE users SET full_name = ?, email = ?, position = ?, company = ? WHERE id = ?",
                [$fullName, $email, $position, $company, $userId]
            );
            
            if ($db->affectedRows() > 0) {
                $message = "Profile updated successfully";
                $messageType = "success";
                
                // Refresh user data
                $user = $db->getRow("SELECT * FROM users WHERE id = ?", [$userId]);
            } else {
                $message = "No changes were made";
                $messageType = "info";
            }
        }
    }
}

// Handle password update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_password'])) {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    
    // Verify current password
    if (!verifyPassword($currentPassword, $user['password'])) {
        $message = "Current password is incorrect";
        $messageType = "danger";
    } else if (strlen($newPassword) < 6) {
        $message = "New password must be at least 6 characters long";
        $messageType = "danger";
    } else if ($newPassword != $confirmPassword) {
        $message = "New passwords do not match";
        $messageType = "danger";
    } else {
        // Hash and update password
        $hashedPassword = hashPassword($newPassword);
        
        $db->query(
            "UPDATE users SET password = ? WHERE id = ?",
            [$hashedPassword, $userId]
        );
        
        if ($db->affectedRows() > 0) {
            $message = "Password updated successfully";
            $messageType = "success";
        } else {
            $message = "No changes were made";
            $messageType = "info";
        }
    }
}

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">My Profile</h1>
        </div>
        
        <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <i class="fas fa-user-circle fa-6x text-primary"></i>
                        </div>
                        <h5 class="card-title"><?php echo htmlspecialchars($user['full_name']); ?></h5>
                        <p class="card-text text-muted">
                            <?php echo htmlspecialchars($user['position'] ? $user['position'] : 'No position set'); ?><br>
                            <?php echo htmlspecialchars($user['company'] ? $user['company'] : 'No company set'); ?>
                        </p>
                        <p class="card-text small">
                            <i class="fas fa-envelope mr-1"></i> <?php echo htmlspecialchars($user['email']); ?><br>
                            <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user['username']); ?><br>
                            <i class="fas fa-calendar-alt mr-1"></i> Joined: <?php echo formatDate($user['created_at']); ?>
                        </p>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="mb-0">Profile Completion</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        // Calculate profile completion percentage
                        $completionFields = [
                            !empty($user['full_name']),
                            !empty($user['email']),
                            !empty($user['position']),
                            !empty($user['company'])
                        ];
                        
                        $completionCount = array_sum($completionFields);
                        $completionTotal = count($completionFields);
                        $completionPercent = round(($completionCount / $completionTotal) * 100);
                        ?>
                        
                        <div class="progress mb-3">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $completionPercent; ?>%;" 
                                 aria-valuenow="<?php echo $completionPercent; ?>" aria-valuemin="0" aria-valuemax="100">
                                <?php echo $completionPercent; ?>%
                            </div>
                        </div>
                        
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Full Name
                                <?php if (!empty($user['full_name'])): ?>
                                <span class="badge badge-success"><i class="fas fa-check"></i></span>
                                <?php else: ?>
                                <span class="badge badge-warning"><i class="fas fa-times"></i></span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Email
                                <?php if (!empty($user['email'])): ?>
                                <span class="badge badge-success"><i class="fas fa-check"></i></span>
                                <?php else: ?>
                                <span class="badge badge-warning"><i class="fas fa-times"></i></span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Position
                                <?php if (!empty($user['position'])): ?>
                                <span class="badge badge-success"><i class="fas fa-check"></i></span>
                                <?php else: ?>
                                <span class="badge badge-warning"><i class="fas fa-times"></i></span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Company
                                <?php if (!empty($user['company'])): ?>
                                <span class="badge badge-success"><i class="fas fa-check"></i></span>
                                <?php else: ?>
                                <span class="badge badge-warning"><i class="fas fa-times"></i></span>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Edit Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                <small class="form-text text-muted">Username cannot be changed</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="full_name">Full Name</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="position">Position</label>
                                        <input type="text" class="form-control" id="position" name="position" value="<?php echo htmlspecialchars($user['position'] ?? ''); ?>" placeholder="e.g. Manager, Director">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="company">Company</label>
                                        <input type="text" class="form-control" id="company" name="company" value="<?php echo htmlspecialchars($user['company'] ?? ''); ?>" placeholder="Your company name">
                                    </div>
                                </div>
                            </div>
                            
                            <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                        </form>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Change Password</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                <small class="form-text text-muted">Password must be at least 6 characters long</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <button type="submit" name="update_password" class="btn btn-warning">Change Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
