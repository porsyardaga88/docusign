<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Get document ID from URL
$documentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Check if download parameter is set
$downloadRequested = isset($_GET['download']) && $_GET['download'] == 1;

// Check if document exists and belongs to the current user
$userId = $_SESSION['user_id'];
$document = getUserDocument($documentId, $userId);

if (!$document) {
    // Document not found or doesn't belong to user
    redirect("/documents.php");
}

// Get document recipients
$recipients = getDocumentRecipients($documentId);

// Handle document download
if ($downloadRequested) {
    $filePath = __DIR__ . $document['file_path'];
    
    if (file_exists($filePath)) {
        // Set headers for download
        header('Content-Description: File Transfer');
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $document['original_filename'] . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        
        // Clear output buffer and read file
        ob_clean();
        flush();
        readfile($filePath);
        exit;
    } else {
        $error = "File not found on server.";
    }
}

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">View Document</h1>
            <div>
                <a href="/documents.php" class="btn btn-outline-secondary mr-2">
                    <i class="fas fa-arrow-left"></i> Back to Documents
                </a>
                <div class="btn-group">
                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?php echo $documentId; ?>&download=1" class="btn btn-primary">
                        <i class="fas fa-download"></i> Download
                    </a>
                    <?php if ($document['status'] == 'draft'): ?>
                    <a href="/send_document.php?id=<?php echo $documentId; ?>" class="btn btn-success">
                        <i class="fas fa-paper-plane"></i> Send for Signature
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo htmlspecialchars($document['original_filename']); ?></h5>
                        <div>
                            <button type="button" class="btn btn-sm btn-outline-primary mr-1" id="zoomIn">
                                <i class="fas fa-search-plus"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-primary mr-1" id="zoomOut">
                                <i class="fas fa-search-minus"></i>
                            </button>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-secondary" id="prev">
                                    <i class="fas fa-chevron-left"></i> Prev
                                </button>
                                <button type="button" class="btn btn-outline-secondary" id="next">
                                    Next <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0 text-center">
                        <div class="document-viewer">
                            <div class="document-container">
                                <canvas id="pdf-renderer"></canvas>
                            </div>
                            <div class="document-controls bg-light border-top p-2 d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="text-muted small">Page <span id="page_num"></span> of <span id="page_count"></span></span>
                                </div>
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-link btn-sm text-muted" id="fullscreen">
                                        <i class="fas fa-expand"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Document Details</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <tr>
                                <th width="120">Status:</th>
                                <td><?php echo getStatusBadge($document['status']); ?></td>
                            </tr>
                            <tr>
                                <th>Size:</th>
                                <td><?php echo formatFileSize($document['file_size']); ?></td>
                            </tr>
                            <tr>
                                <th>Uploaded:</th>
                                <td><?php echo formatDate($document['created_at']); ?></td>
                            </tr>
                            <tr>
                                <th>Last Updated:</th>
                                <td><?php echo formatDate($document['updated_at']); ?></td>
                            </tr>
                        </table>
                        
                        <?php if (!empty($document['description'])): ?>
                        <div class="mt-3">
                            <h6>Description:</h6>
                            <p class="text-muted small"><?php echo nl2br(htmlspecialchars($document['description'])); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Recipients</h5>
                        <span class="badge badge-pill badge-secondary"><?php echo count($recipients); ?></span>
                    </div>
                    <div class="card-body p-0">
                        <?php if (count($recipients) > 0): ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($recipients as $recipient): ?>
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo htmlspecialchars($recipient['name']); ?></strong>
                                        <small class="d-block text-muted"><?php echo htmlspecialchars($recipient['email']); ?></small>
                                    </div>
                                    <?php
                                    $statusClass = '';
                                    $statusIcon = '';
                                    
                                    switch ($recipient['status']) {
                                        case 'pending':
                                            $statusClass = 'badge-secondary';
                                            $statusIcon = 'clock';
                                            break;
                                        case 'viewed':
                                            $statusClass = 'badge-info';
                                            $statusIcon = 'eye';
                                            break;
                                        case 'signed':
                                            $statusClass = 'badge-success';
                                            $statusIcon = 'check-circle';
                                            break;
                                        case 'declined':
                                            $statusClass = 'badge-danger';
                                            $statusIcon = 'times-circle';
                                            break;
                                    }
                                    ?>
                                    <span class="badge <?php echo $statusClass; ?>">
                                        <i class="fas fa-<?php echo $statusIcon; ?> mr-1"></i>
                                        <?php echo ucfirst($recipient['status']); ?>
                                    </span>
                                </div>
                                <?php if ($recipient['status'] === 'signed' && !empty($recipient['signed_at'])): ?>
                                <small class="text-muted">Signed on: <?php echo formatDate($recipient['signed_at']); ?></small>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                        <div class="text-center py-4">
                            <p class="text-muted mb-0">No recipients added yet.</p>
                            <?php if ($document['status'] == 'draft'): ?>
                            <a href="/send_document.php?id=<?php echo $documentId; ?>" class="btn btn-sm btn-primary mt-2">
                                <i class="fas fa-paper-plane"></i> Send for Signature
                            </a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if ($document['status'] === 'sent' || $document['status'] === 'signed'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Signing Progress</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $totalRecipients = count($recipients);
                        $signedCount = 0;
                        
                        foreach ($recipients as $recipient) {
                            if ($recipient['status'] === 'signed') {
                                $signedCount++;
                            }
                        }
                        
                        $progress = ($totalRecipients > 0) ? round(($signedCount / $totalRecipients) * 100) : 0;
                        ?>
                        
                        <div class="progress mb-3">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $progress; ?>%;" 
                                 aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100">
                                <?php echo $progress; ?>%
                            </div>
                        </div>
                        
                        <p class="text-center">
                            <strong><?php echo $signedCount; ?></strong> of <strong><?php echo $totalRecipients; ?></strong> recipients have signed
                        </p>
                        
                        <?php if ($progress === 100 && $document['status'] !== 'completed'): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> All recipients have signed this document!
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Initialize variables
let pdfDoc = null;
let pageNum = 1;
let pageRendering = false;
let pageNumPending = null;
let scale = 1.0;
let canvas = document.getElementById('pdf-renderer');
let ctx = canvas.getContext('2d');

// PDF.js initialization
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.6.347/pdf.worker.min.js';

// Load PDF document
function loadPdf() {
    const url = '<?php echo BASE_URL . $document['file_path']; ?>';
    
    pdfjsLib.getDocument(url).promise.then(function(pdf) {
        pdfDoc = pdf;
        document.getElementById('page_count').textContent = pdf.numPages;
        
        // Initial render
        renderPage(pageNum);
    });
}

// Render specific page
function renderPage(num) {
    pageRendering = true;
    
    // Get page
    pdfDoc.getPage(num).then(function(page) {
        const viewport = page.getViewport({scale: scale});
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        // Render PDF page
        const renderContext = {
            canvasContext: ctx,
            viewport: viewport
        };
        
        const renderTask = page.render(renderContext);
        
        renderTask.promise.then(function() {
            pageRendering = false;
            
            if (pageNumPending !== null) {
                renderPage(pageNumPending);
                pageNumPending = null;
            }
        });
    });
    
    // Update page number
    document.getElementById('page_num').textContent = num;
}

// Queue page rendering when previous rendering is not finished
function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

// Previous page
function previousPage() {
    if (pageNum <= 1) {
        return;
    }
    pageNum--;
    queueRenderPage(pageNum);
}

// Next page
function nextPage() {
    if (pageNum >= pdfDoc.numPages) {
        return;
    }
    pageNum++;
    queueRenderPage(pageNum);
}

// Zoom in
document.getElementById('zoomIn').addEventListener('click', function() {
    scale += 0.25;
    renderPage(pageNum);
});

// Zoom out
document.getElementById('zoomOut').addEventListener('click', function() {
    if (scale <= 0.5) return;
    scale -= 0.25;
    renderPage(pageNum);
});

// Full screen mode
document.getElementById('fullscreen').addEventListener('click', function() {
    const viewer = document.querySelector('.document-viewer');
    
    if (!document.fullscreenElement) {
        viewer.requestFullscreen().catch(err => {
            console.log(`Error attempting to enable full-screen mode: ${err.message}`);
        });
    } else {
        document.exitFullscreen();
    }
});

// Register navigation buttons
document.getElementById('prev').addEventListener('click', previousPage);
document.getElementById('next').addEventListener('click', nextPage);

// Initialize after page load
document.addEventListener('DOMContentLoaded', function() {
    loadPdf();
});
</script>

<?php include 'includes/footer.php'; ?>
