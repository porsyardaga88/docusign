<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Get token from URL
$token = isset($_GET['token']) ? clean($_GET['token']) : '';

// Check if token is valid
$recipient = getRecipientByToken($token);

if (!$recipient) {
    // Invalid token, show error page
    http_response_code(404);
    include 'includes/header.php';
    echo '<div class="container mt-5">
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <h4 class="mb-0">Invalid Link</h4>
            </div>
            <div class="card-body text-center py-5">
                <i class="fas fa-exclamation-triangle fa-4x text-danger mb-3"></i>
                <h5>This signing link is invalid or has expired</h5>
                <p class="text-muted">Please contact the sender for a new link.</p>
            </div>
        </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

// Get document data
$documentId = $recipient['document_id'];
$document = getDocument($documentId);

if (!$document) {
    // Document not found
    http_response_code(404);
    include 'includes/header.php';
    echo '<div class="container mt-5">
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <h4 class="mb-0">Document Not Found</h4>
            </div>
            <div class="card-body text-center py-5">
                <i class="fas fa-file-excel fa-4x text-danger mb-3"></i>
                <h5>The requested document could not be found</h5>
                <p class="text-muted">The document may have been deleted. Please contact the sender.</p>
            </div>
        </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

// Check if document is already signed by this recipient
if ($recipient['status'] === 'signed') {
    include 'includes/header.php';
    echo '<div class="container mt-5">
        <div class="card border-success">
            <div class="card-header bg-success text-white">
                <h4 class="mb-0">Document Already Signed</h4>
            </div>
            <div class="card-body text-center py-5">
                <i class="fas fa-check-circle fa-4x text-success mb-3"></i>
                <h5>You have already signed this document</h5>
                <p>Thank you for completing the signing process.</p>
                <div class="mt-3">
                    <a href="/verify_signature.php?token=' . $token . '" class="btn btn-primary">
                        <i class="fas fa-file-signature"></i> View Signed Document
                    </a>
                </div>
            </div>
        </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

// Update recipient status to 'viewed' if it's 'pending'
if ($recipient['status'] === 'pending') {
    $db->query(
        "UPDATE recipients SET status = 'viewed' WHERE id = ?",
        [$recipient['id']]
    );
}

include 'includes/header.php';
?>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="h3 mb-0">Sign Document: <?php echo htmlspecialchars($document['original_filename']); ?></h1>
            <p class="text-muted">Please review the document and add your signature where indicated</p>
        </div>
        <div class="col-md-4 text-right">
            <button type="button" class="btn btn-outline-primary mr-2" id="zoomIn">
                <i class="fas fa-search-plus"></i>
            </button>
            <button type="button" class="btn btn-outline-primary mr-2" id="zoomOut">
                <i class="fas fa-search-minus"></i>
            </button>
            <button type="button" class="btn btn-success" id="complete-sign">
                <i class="fas fa-check"></i> Complete Signing
            </button>
        </div>
    </div>

    <div class="row">
        <div class="col-md-9">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Document Preview</h5>
                    <div class="document-navigation">
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="prev">
                            <i class="fas fa-chevron-left"></i> Previous
                        </button>
                        <span id="page_num"></span> / <span id="page_count"></span>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="next">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="document-container">
                        <canvas id="pdf-renderer"></canvas>
                        <div id="signature-container"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Signature</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3 text-center">
                        <p class="text-muted small">Draw your signature below</p>
                        <div class="signature-pad-container border mb-2">
                            <canvas id="signature-pad" class="signature-pad"></canvas>
                        </div>
                        <button type="button" class="btn btn-sm btn-secondary" id="clear-signature">
                            <i class="fas fa-eraser"></i> Clear
                        </button>
                    </div>
                    <div class="text-center mt-4">
                        <button type="button" class="btn btn-primary btn-block" id="add-signature-btn">
                            <i class="fas fa-plus-circle"></i> Add Signature to Document
                        </button>
                    </div>
                    <div class="mt-3">
                        <p class="text-muted small text-center">Click "Add Signature" then click on the document where you want to place your signature</p>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Signing Instructions</h5>
                </div>
                <div class="card-body">
                    <ol class="pl-3 small">
                        <li class="mb-2">Review the document carefully</li>
                        <li class="mb-2">Draw your signature in the signature pad</li>
                        <li class="mb-2">Click "Add Signature" button</li>
                        <li class="mb-2">Click on the document where you want to place your signature</li>
                        <li class="mb-2">When all signatures are placed, click "Complete Signing"</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Signature placement modal -->
    <div class="modal fade" id="signature-placement-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Place Your Signature</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <p>Click on the document where you want to place your signature.</p>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Confirm completion modal -->
    <div class="modal fade" id="complete-signing-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Complete Signing Process</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> 
                        Once you complete the signing process, you cannot make changes to your signature.
                    </div>
                    <p>Are you sure you want to complete the signing process?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <form action="/process/sign_document_process.php" method="post" id="sign-document-form">
                        <input type="hidden" name="token" value="<?php echo $token; ?>">
                        <input type="hidden" name="signature_data" id="final-signature-data">
                        <input type="hidden" name="signature_x" id="signature-x">
                        <input type="hidden" name="signature_y" id="signature-y">
                        <input type="hidden" name="signature_page" id="signature-page">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check"></i> Complete Signing
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Initialize variables
let pdfDoc = null;
let pageNum = 1;
let pageRendering = false;
let pageNumPending = null;
let scale = 1.0;
let canvas = document.getElementById('pdf-renderer');
let ctx = canvas.getContext('2d');
let signaturePad = null;
let signaturePlacementActive = false;
let signaturePlacementData = null;
let currentSignatures = [];

// PDF.js initialization
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.6.347/pdf.worker.min.js';

// Load PDF document
function loadPdf() {
    const url = '<?php echo BASE_URL . $document['file_path']; ?>';
    
    pdfjsLib.getDocument(url).promise.then(function(pdf) {
        pdfDoc = pdf;
        document.getElementById('page_count').textContent = pdf.numPages;
        
        // Initial render
        renderPage(pageNum);
    });
}

// Render specific page
function renderPage(num) {
    pageRendering = true;
    
    // Get page
    pdfDoc.getPage(num).then(function(page) {
        const viewport = page.getViewport({scale: scale});
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        // Render PDF page
        const renderContext = {
            canvasContext: ctx,
            viewport: viewport
        };
        
        const renderTask = page.render(renderContext);
        
        renderTask.promise.then(function() {
            pageRendering = false;
            
            if (pageNumPending !== null) {
                renderPage(pageNumPending);
                pageNumPending = null;
            }
            
            // Draw existing signatures for this page
            drawExistingSignatures();
        });
    });
    
    // Update page number
    document.getElementById('page_num').textContent = num;
}

// Queue page rendering when previous rendering is not finished
function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

// Previous page
function previousPage() {
    if (pageNum <= 1) {
        return;
    }
    pageNum--;
    queueRenderPage(pageNum);
}

// Next page
function nextPage() {
    if (pageNum >= pdfDoc.numPages) {
        return;
    }
    pageNum++;
    queueRenderPage(pageNum);
}

// Initialize signature pad
function initSignaturePad() {
    const signatureCanvas = document.getElementById('signature-pad');
    signaturePad = new SignaturePad(signatureCanvas, {
        backgroundColor: 'rgb(255, 255, 255)',
        penColor: 'rgb(0, 0, 0)'
    });
    
    // Resize canvas
    function resizeCanvas() {
        const ratio = Math.max(window.devicePixelRatio || 1, 1);
        signatureCanvas.width = signatureCanvas.offsetWidth * ratio;
        signatureCanvas.height = 200 * ratio;
        signatureCanvas.getContext("2d").scale(ratio, ratio);
        signaturePad.clear();
    }
    
    // Initial resize
    resizeCanvas();
    
    // Resize on window resize
    window.addEventListener("resize", resizeCanvas);
    
    // Clear signature
    document.getElementById('clear-signature').addEventListener('click', function() {
        signaturePad.clear();
    });
}

// Handle add signature button click
document.getElementById('add-signature-btn').addEventListener('click', function() {
    if (signaturePad.isEmpty()) {
        alert('Please provide a signature first.');
        return;
    }
    
    // Get signature data
    signaturePlacementData = signaturePad.toDataURL();
    signaturePlacementActive = true;
    
    // Show placement modal
    $('#signature-placement-modal').modal('show');
});

// Handle canvas click for signature placement
canvas.addEventListener('click', function(e) {
    if (!signaturePlacementActive || !signaturePlacementData) {
        return;
    }
    
    // Calculate position relative to canvas
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Add signature to current signatures
    currentSignatures.push({
        data: signaturePlacementData,
        x: x,
        y: y,
        page: pageNum
    });
    
    // Draw the signature
    const img = new Image();
    img.onload = function() {
        ctx.drawImage(img, x, y, 200, 100);
    };
    img.src = signaturePlacementData;
    
    // Reset placement mode
    signaturePlacementActive = false;
    $('#signature-placement-modal').modal('hide');
    
    // Enable complete signing button
    document.getElementById('complete-sign').classList.remove('disabled');
});

// Draw existing signatures for the current page
function drawExistingSignatures() {
    currentSignatures.forEach(function(signature) {
        if (signature.page === pageNum) {
            const img = new Image();
            img.onload = function() {
                ctx.drawImage(img, signature.x, signature.y, 200, 100);
            };
            img.src = signature.data;
        }
    });
}

// Complete signing process
document.getElementById('complete-sign').addEventListener('click', function() {
    if (currentSignatures.length === 0) {
        alert('Please add at least one signature to the document.');
        return;
    }
    
    // Get the last signature (most recent)
    const lastSignature = currentSignatures[currentSignatures.length - 1];
    
    // Set form values
    document.getElementById('final-signature-data').value = lastSignature.data;
    document.getElementById('signature-x').value = lastSignature.x;
    document.getElementById('signature-y').value = lastSignature.y;
    document.getElementById('signature-page').value = lastSignature.page;
    
    // Show confirmation modal
    $('#complete-signing-modal').modal('show');
});

// Zoom in
document.getElementById('zoomIn').addEventListener('click', function() {
    scale += 0.25;
    renderPage(pageNum);
});

// Zoom out
document.getElementById('zoomOut').addEventListener('click', function() {
    if (scale <= 0.5) return;
    scale -= 0.25;
    renderPage(pageNum);
});

// Register navigation buttons
document.getElementById('prev').addEventListener('click', previousPage);
document.getElementById('next').addEventListener('click', nextPage);

// Initialize after page load
document.addEventListener('DOMContentLoaded', function() {
    loadPdf();
    initSignaturePad();
});
</script>

<?php include 'includes/footer.php'; ?>
