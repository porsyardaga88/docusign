<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// If user is already logged in, redirect to dashboard
if (isLoggedIn()) {
    redirect("/dashboard.php");
}

$username = $email = $fullName = "";
$errors = [];

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty($_POST["username"])) {
        $errors[] = "Username is required";
    } else {
        $username = clean($_POST["username"]);
        
        // Check if username already exists
        $existingUser = $db->getRow("SELECT * FROM users WHERE username = ?", [$username]);
        if ($existingUser) {
            $errors[] = "Username already exists";
        }
    }
    
    // Validate email
    if (empty($_POST["email"])) {
        $errors[] = "Email is required";
    } else {
        $email = clean($_POST["email"]);
        
        // Check if email format is valid
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        }
        
        // Check if email already exists
        $existingEmail = $db->getRow("SELECT * FROM users WHERE email = ?", [$email]);
        if ($existingEmail) {
            $errors[] = "Email already exists";
        }
    }
    
    // Validate full name
    if (empty($_POST["full_name"])) {
        $errors[] = "Full name is required";
    } else {
        $fullName = clean($_POST["full_name"]);
    }
    
    // Validate password
    if (empty($_POST["password"])) {
        $errors[] = "Password is required";
    } else if (strlen($_POST["password"]) < 6) {
        $errors[] = "Password must be at least 6 characters long";
    }
    
    // Validate password confirmation
    if (empty($_POST["confirm_password"])) {
        $errors[] = "Please confirm your password";
    } else if ($_POST["password"] != $_POST["confirm_password"]) {
        $errors[] = "Passwords do not match";
    }
    
    // If no errors, create user
    if (empty($errors)) {
        $hashedPassword = hashPassword($_POST["password"]);
        
        // Insert user into database
        $userId = $db->insert(
            "INSERT INTO users (username, email, password, full_name) VALUES (?, ?, ?, ?)",
            [$username, $email, $hashedPassword, $fullName]
        );
        
        if ($userId) {
            // Create default settings for user
            $db->insert(
                "INSERT INTO settings (user_id, email_notifications) VALUES (?, ?)",
                [$userId, true]
            );
            
            // Set session variables
            $_SESSION["user_id"] = $userId;
            $_SESSION["username"] = $username;
            
            // Redirect to dashboard
            redirect("/dashboard.php");
        } else {
            $errors[] = "Registration failed. Please try again.";
        }
    }
}

include 'includes/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fas fa-user-plus"></i> Register</h4>
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                <div class="alert alert-danger" role="alert">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Choose a username" value="<?php echo htmlspecialchars($username); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter your full name" value="<?php echo htmlspecialchars($fullName); ?>" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Choose a password" required>
                                <small class="form-text text-muted">Password must be at least 6 characters long</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="confirm_password">Confirm Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="terms" required>
                        <label class="form-check-label" for="terms">I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                </form>
                
                <hr>
                
                <div class="text-center">
                    <p class="mb-0">Already have an account? <a href="/login.php">Login here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
