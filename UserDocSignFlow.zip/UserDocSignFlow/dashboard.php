<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Get current user data
$currentUser = getCurrentUser();

// Get document statistics
$userId = $_SESSION['user_id'];
$draftCount = countDocumentsByStatus($userId, 'draft');
$sentCount = countDocumentsByStatus($userId, 'sent');
$signedCount = countDocumentsByStatus($userId, 'signed');
$completedCount = countDocumentsByStatus($userId, 'completed');
$totalCount = $db->getValue("SELECT COUNT(*) FROM documents WHERE user_id = ?", [$userId]);

// Get recent documents
$recentDocuments = $db->getRows(
    "SELECT * FROM documents WHERE user_id = ? ORDER BY updated_at DESC LIMIT 5",
    [$userId]
);

// Get documents awaiting signatures
$awaitingSignatures = $db->getRows(
    "SELECT d.*, COUNT(r.id) as recipient_count, SUM(CASE WHEN r.status = 'signed' THEN 1 ELSE 0 END) as signed_count
     FROM documents d
     LEFT JOIN recipients r ON d.id = r.document_id
     WHERE d.user_id = ? AND d.status = 'sent'
     GROUP BY d.id
     ORDER BY d.updated_at DESC",
    [$userId]
);

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="mb-4">
            <h1 class="h3">Welcome, <?php echo htmlspecialchars($currentUser['full_name']); ?>!</h1>
            <p class="text-muted">Here's an overview of your document activity</p>
        </div>
        
        <!-- Stats cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card h-100 bg-primary text-white shadow-sm border-0 rounded-lg" style="max-height: 180px;">
                    <div class="card-body py-3">
                        <div class="d-flex align-items-center">
                            <div class="rounded-circle bg-white p-2 d-flex align-items-center justify-content-center mr-3" style="width: 40px; height: 40px;">
                                <i class="fas fa-file-alt text-primary"></i>
                            </div>
                            <div>
                                <div class="small mb-1 opacity-75">Total Documents</div>
                                <h4 class="mb-0 font-weight-bold"><?php echo $totalCount; ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0 py-2">
                        <a href="/documents.php" class="text-white small">
                            <span class="opacity-75">View all</span> <i class="fas fa-arrow-right fa-sm ml-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card h-100 bg-info text-white shadow-sm border-0 rounded-lg" style="max-height: 180px;">
                    <div class="card-body py-3">
                        <div class="d-flex align-items-center">
                            <div class="rounded-circle bg-white p-2 d-flex align-items-center justify-content-center mr-3" style="width: 40px; height: 40px;">
                                <i class="fas fa-signature text-info"></i>
                            </div>
                            <div>
                                <div class="small mb-1 opacity-75">Awaiting Signatures</div>
                                <h4 class="mb-0 font-weight-bold"><?php echo $sentCount; ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0 py-2">
                        <a href="/documents.php?status=sent" class="text-white small">
                            <span class="opacity-75">View pending</span> <i class="fas fa-arrow-right fa-sm ml-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card h-100 bg-success text-white shadow-sm border-0 rounded-lg" style="max-height: 180px;">
                    <div class="card-body py-3">
                        <div class="d-flex align-items-center">
                            <div class="rounded-circle bg-white p-2 d-flex align-items-center justify-content-center mr-3" style="width: 40px; height: 40px;">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div>
                                <div class="small mb-1 opacity-75">Completed</div>
                                <h4 class="mb-0 font-weight-bold"><?php echo $completedCount; ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0 py-2">
                        <a href="/documents.php?status=completed" class="text-white small">
                            <span class="opacity-75">View completed</span> <i class="fas fa-arrow-right fa-sm ml-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card h-100 bg-secondary text-white shadow-sm border-0 rounded-lg" style="max-height: 180px;">
                    <div class="card-body py-3">
                        <div class="d-flex align-items-center">
                            <div class="rounded-circle bg-white p-2 d-flex align-items-center justify-content-center mr-3" style="width: 40px; height: 40px;">
                                <i class="fas fa-pencil-alt text-secondary"></i>
                            </div>
                            <div>
                                <div class="small mb-1 opacity-75">Drafts</div>
                                <h4 class="mb-0 font-weight-bold"><?php echo $draftCount; ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0 py-2">
                        <a href="/documents.php?status=draft" class="text-white small">
                            <span class="opacity-75">View drafts</span> <i class="fas fa-arrow-right fa-sm ml-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick actions -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center mb-3 mb-md-0">
                        <a href="/upload.php" class="btn btn-outline-primary btn-lg btn-block">
                            <i class="fas fa-upload mb-2 d-block"></i>
                            Upload Document
                        </a>
                    </div>
                    <div class="col-md-4 text-center mb-3 mb-md-0">
                        <a href="/documents.php" class="btn btn-outline-secondary btn-lg btn-block">
                            <i class="fas fa-file-pdf mb-2 d-block"></i>
                            View Documents
                        </a>
                    </div>
                    <div class="col-md-4 text-center">
                        <a href="/profile.php" class="btn btn-outline-info btn-lg btn-block">
                            <i class="fas fa-user-edit mb-2 d-block"></i>
                            Edit Profile
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent documents -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Recent Documents</h5>
                <a href="/documents.php" class="btn btn-sm btn-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <?php if (count($recentDocuments) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Document</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentDocuments as $document): ?>
                            <tr>
                                <td>
                                    <a href="/view_document.php?id=<?php echo $document['id']; ?>">
                                        <?php echo htmlspecialchars($document['original_filename']); ?>
                                    </a>
                                </td>
                                <td><?php echo formatDate($document['updated_at']); ?></td>
                                <td><?php echo getStatusBadge($document['status']); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="/view_document.php?id=<?php echo $document['id']; ?>" class="btn btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if ($document['status'] == 'draft'): ?>
                                        <a href="/send_document.php?id=<?php echo $document['id']; ?>" class="btn btn-primary">
                                            <i class="fas fa-paper-plane"></i>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <div class="mb-3">
                        <i class="fas fa-file-alt fa-4x text-muted"></i>
                    </div>
                    <h5>No documents yet</h5>
                    <p class="text-muted">Upload your first document to get started</p>
                    <a href="/upload.php" class="btn btn-primary">Upload Document</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Awaiting signatures -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Documents Awaiting Signatures</h5>
            </div>
            <div class="card-body p-0">
                <?php if (count($awaitingSignatures) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Document</th>
                                <th>Sent Date</th>
                                <th>Progress</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($awaitingSignatures as $document): ?>
                            <tr>
                                <td>
                                    <a href="/view_document.php?id=<?php echo $document['id']; ?>">
                                        <?php echo htmlspecialchars($document['original_filename']); ?>
                                    </a>
                                </td>
                                <td><?php echo formatDate($document['updated_at']); ?></td>
                                <td>
                                    <div class="progress">
                                        <?php 
                                        $progress = 0;
                                        if ($document['recipient_count'] > 0) {
                                            $progress = round(($document['signed_count'] / $document['recipient_count']) * 100);
                                        }
                                        ?>
                                        <div class="progress-bar" role="progressbar" style="width: <?php echo $progress; ?>%;"
                                             aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100">
                                            <?php echo $progress; ?>%
                                        </div>
                                    </div>
                                    <small class="text-muted"><?php echo $document['signed_count']; ?> of <?php echo $document['recipient_count']; ?> signatures</small>
                                </td>
                                <td>
                                    <a href="/view_document.php?id=<?php echo $document['id']; ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <div class="mb-3">
                        <i class="fas fa-signature fa-4x text-muted"></i>
                    </div>
                    <h5>No pending signatures</h5>
                    <p class="text-muted">Send a document for signature to get started</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Featured image -->
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-body p-0">
                        <img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf" class="img-fluid" alt="Professional dashboard">
                    </div>
                    <div class="card-footer bg-light">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="mb-0">Manage Your Documents Efficiently</h5>
                                <p class="text-muted mb-0">Upload, send, sign, and track all your important documents in one place.</p>
                            </div>
                            <a href="/upload.php" class="btn btn-primary">Get Started</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
