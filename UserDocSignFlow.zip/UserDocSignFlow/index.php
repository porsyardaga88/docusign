<?php
// Enable error reporting 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'includes/config.php';
require_once 'includes/functions.php';

// If user is already logged in, redirect to dashboard
if (isLoggedIn()) {
    redirect("/dashboard.php");
}

include 'includes/header.php';
?>

<div class="row mt-5">
    <div class="col-md-6">
        <div class="jumbotron">
            <h1 class="display-4">DocuSign Pro</h1>
            <p class="lead">A complete document management system with digital signature capabilities</p>
            <hr class="my-4">
            <p>Upload, send, sign, and manage your important documents securely.</p>
            <a class="btn btn-primary btn-lg" href="/register.php" role="button">Get Started</a>
            <a class="btn btn-outline-primary btn-lg ml-2" href="/login.php" role="button">Login</a>
        </div>
    </div>
    <div class="col-md-6">
        <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f" class="img-fluid rounded shadow" alt="Document signing">
    </div>
</div>

<div class="row mt-5">
    <div class="col-md-4">
        <div class="card text-center mb-4">
            <div class="card-body">
                <i class="fas fa-file-upload fa-3x text-primary mb-3"></i>
                <h5 class="card-title">Upload Documents</h5>
                <p class="card-text">Easily upload your PDF documents to our secure platform.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center mb-4">
            <div class="card-body">
                <i class="fas fa-share-alt fa-3x text-primary mb-3"></i>
                <h5 class="card-title">Send for Signature</h5>
                <p class="card-text">Send documents to recipients for electronic signatures via email.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center mb-4">
            <div class="card-body">
                <i class="fas fa-signature fa-3x text-primary mb-3"></i>
                <h5 class="card-title">Digital Signatures</h5>
                <p class="card-text">Sign documents directly in your browser with our easy-to-use interface.</p>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-6">
        <img src="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5" class="img-fluid rounded shadow" alt="Digital signatures">
    </div>
    <div class="col-md-6">
        <h2>Secure Digital Signatures</h2>
        <p class="lead">Our system provides a legally binding electronic signature solution that complies with e-signature laws.</p>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><i class="fas fa-check text-success mr-2"></i> Legally binding signatures</li>
            <li class="list-group-item"><i class="fas fa-check text-success mr-2"></i> Tamper-evident technology</li>
            <li class="list-group-item"><i class="fas fa-check text-success mr-2"></i> Audit trail for all documents</li>
            <li class="list-group-item"><i class="fas fa-check text-success mr-2"></i> Easy-to-use signing interface</li>
        </ul>
    </div>
</div>

<div class="row mt-5">
    <div class="col-md-12">
        <div class="card bg-light">
            <div class="card-body">
                <h3 class="text-center mb-4">Ready to get started?</h3>
                <p class="text-center">Create your account today and begin managing your documents efficiently.</p>
                <div class="text-center">
                    <a href="/register.php" class="btn btn-primary">Sign Up Now</a>
                    <span class="mx-3">or</span>
                    <a href="/login.php" class="btn btn-outline-primary">Login</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
