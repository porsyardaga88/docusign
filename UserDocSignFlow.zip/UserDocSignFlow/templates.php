<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Get current user data
$currentUser = getCurrentUser();

// Handle template selection
$selectedTemplate = isset($_GET['template']) ? $_GET['template'] : '';

// Create sample templates
$templates = [
    'acceptance_letter' => [
        'name' => 'Acceptance Letter',
        'description' => 'A formal letter confirming acceptance of an offer, application, or proposal.',
        'type' => 'text',
        'signable' => true,
        'content' => <<<EOT
[Your Company Name]
[Street Address]
[City, State ZIP]
[Date]

[Recipient Name]
[Recipient Title]
[Company Name]
[Street Address]
[City, State ZIP]

Subject: Acceptance of [Offer/Proposal/Application]

Dear [Recipient Name],

I am pleased to inform you that [Your Company Name] has accepted your [offer/proposal/application] for [brief description of what was offered/proposed/applied for] dated [date of offer/proposal/application].

We have carefully reviewed the details of your [offer/proposal/application] and find the terms and conditions to be satisfactory. We look forward to [brief description of the next steps or what the acceptance means, e.g., "beginning our partnership" or "welcoming you to our team"].

Please consider this letter as our formal acceptance. We will proceed with [any specific actions that will be taken, e.g., "preparing the necessary paperwork" or "scheduling an onboarding session"].

If you have any questions or require further information, please do not hesitate to contact me at [your phone number] or [your email address].

We look forward to a productive and mutually beneficial relationship.

Sincerely,

[Your Full Name]
[Your Title]
[Your Company Name]
[Your Phone Number]
[Your Email Address]
EOT
    ],
    'contract_agreement' => [
        'name' => 'Contract Agreement',
        'description' => 'A standard contract template for business agreements and services.',
        'type' => 'text',
        'signable' => true,
        'content' => <<<EOT
CONTRACT AGREEMENT

This Contract Agreement (the "Agreement") is entered into as of [Date] (the "Effective Date"), by and between:

[Your Company Name], a company organized and existing under the laws of [State/Country], with its principal place of business at [Your Company Address] (hereinafter referred to as the "Company")

and

[Client/Partner Name], a [individual/company] with [address/organized and existing under the laws of State/Country, with its principal place of business at Client Address] (hereinafter referred to as the "Client").

1. SERVICES
The Company agrees to provide the following services to the Client (the "Services"):
• [Detailed description of service 1]
• [Detailed description of service 2]
• [Detailed description of service 3]

2. TERM
This Agreement shall commence on the Effective Date and shall continue until [end date or "completion of the Services"], unless earlier terminated as provided herein.

3. COMPENSATION
In consideration for the Services, the Client shall pay the Company as follows:
[Payment terms, including amounts, schedules, and method of payment]

4. CONFIDENTIALITY
Both parties acknowledge that they may be exposed to confidential information during the performance of this Agreement. Each party agrees to maintain the confidentiality of all such information and not to disclose it to any third party without prior written consent.

5. TERMINATION
This Agreement may be terminated by either party upon [number] days' written notice to the other party.

6. GOVERNING LAW
This Agreement shall be governed by and construed in accordance with the laws of [State/Country].

7. SIGNATURES
By signing below, the parties agree to comply with all terms and conditions of this Agreement.

[Your Company Name]                           [Client/Partner Name]
________________________                 ________________________
Signature                                      Signature

________________________                 ________________________
Printed Name & Title                           Printed Name & Title

________________________                 ________________________
Date                                           Date
EOT
    ],
    'employment_offer' => [
        'name' => 'Employment Offer Letter',
        'description' => 'A formal employment offer letter to welcome new team members.',
        'type' => 'text',
        'signable' => true,
        'content' => <<<EOT
[Your Company Letterhead]

[Date]

[Prospective Employee Name]
[Address]
[City, State ZIP]

Dear [Prospective Employee Name],

We are pleased to offer you the position of [Job Title] at [Company Name]. We believe your skills and experience will be a valuable addition to our team.

Position Details:
• Job Title: [Job Title]
• Department: [Department]
• Reports to: [Manager Name], [Manager Title]
• Start Date: [Start Date]
• Schedule: [Full-time/Part-time], [Schedule details if applicable]
• Location: [Work location]

Compensation and Benefits:
• Salary: [Amount] per [year/hour]
• Benefits: [Health insurance, retirement plan, etc.]
• Paid Time Off: [Details of vacation, sick leave, etc.]
• [Other benefits]

This offer is contingent upon:
• [Background check]
• [Reference verification]
• [Drug test]
• [Other conditions]

To accept this offer, please sign and return this letter by [deadline date]. If you have any questions regarding this offer, please contact me at [phone number] or [email address].

We are excited about the possibility of you joining our team and look forward to your contribution to [Company Name].

Sincerely,

[Your Name]
[Your Title]
[Company Name]

Acceptance:

I, [Prospective Employee Name], accept the offer of employment as outlined above.

________________________
Signature

________________________
Date
EOT
    ],
    'html_contract' => [
        'name' => 'HTML Contract Template',
        'description' => 'A professionally styled contract with custom formatting and signature fields.',
        'type' => 'html',
        'signable' => true,
        'content' => <<<EOT
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Professional Contract</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            font-size: 12pt;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        .company-name {
            font-size: 24pt;
            font-weight: bold;
            color: #2c3e50;
        }
        .document-title {
            font-size: 18pt;
            text-transform: uppercase;
            margin: 30px 0;
            text-align: center;
            color: #2c3e50;
        }
        .section-title {
            font-size: 14pt;
            font-weight: bold;
            margin-top: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
        }
        .parties {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
        }
        .party {
            width: 45%;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .party-title {
            font-weight: bold;
            margin-bottom: 10px;
            color: #2c3e50;
        }
        .clause {
            margin-bottom: 15px;
        }
        .signature-area {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
        }
        .signature-block {
            width: 45%;
            text-align: center;
        }
        .signature-line {
            border-top: 1px solid #333;
            margin-top: 50px;
            margin-bottom: 10px;
        }
        .date-area {
            margin-top: 20px;
        }
        .signature-instructions {
            font-style: italic;
            color: #777;
            font-size: 10pt;
        }
        .signature-field {
            height: 100px;
            border: 1px dashed #999;
            margin: 10px 0;
            position: relative;
        }
        .signature-field::after {
            content: "Sign Here";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #999;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="company-name">[YOUR COMPANY NAME]</div>
        <div>[Company Address], [City, State ZIP]</div>
        <div>[Phone] | [Email] | [Website]</div>
    </div>
    
    <div class="document-title">Service Agreement Contract</div>
    
    <div>
        This Service Agreement (the "Agreement") is entered into as of <u>[Effective Date]</u> (the "Effective Date"), by and between the parties identified below:
    </div>
    
    <div class="parties">
        <div class="party">
            <div class="party-title">SERVICE PROVIDER:</div>
            <div>[Your Company Name]</div>
            <div>[Address]</div>
            <div>[City, State ZIP]</div>
            <div>[Phone]</div>
            <div>[Email]</div>
        </div>
        <div class="party">
            <div class="party-title">CLIENT:</div>
            <div>[Client Name]</div>
            <div>[Address]</div>
            <div>[City, State ZIP]</div>
            <div>[Phone]</div>
            <div>[Email]</div>
        </div>
    </div>
    
    <div class="section-title">1. SERVICES</div>
    <div class="clause">
        The Service Provider agrees to provide the following services to the Client (the "Services"):
        <ul>
            <li>[Detailed description of service 1]</li>
            <li>[Detailed description of service 2]</li>
            <li>[Add more services as needed]</li>
        </ul>
    </div>
    
    <div class="section-title">2. TERM</div>
    <div class="clause">
        This Agreement shall commence on the Effective Date and shall continue until [End Date or "completion of the Services"], unless earlier terminated as provided herein.
    </div>
    
    <div class="section-title">3. COMPENSATION</div>
    <div class="clause">
        In consideration for the Services, the Client shall pay the Service Provider as follows:
        <br><br>
        [Payment terms, including amounts, schedules, and method of payment]
    </div>
    
    <div class="section-title">4. CONFIDENTIALITY</div>
    <div class="clause">
        Both parties acknowledge that they may be exposed to confidential information during the performance of this Agreement. Each party agrees to maintain the confidentiality of all such information and not to disclose it to any third party without prior written consent.
    </div>
    
    <div class="section-title">5. TERMINATION</div>
    <div class="clause">
        This Agreement may be terminated by either party upon [number] days' written notice to the other party.
    </div>
    
    <div class="section-title">6. GOVERNING LAW</div>
    <div class="clause">
        This Agreement shall be governed by and construed in accordance with the laws of [State/Country].
    </div>
    
    <div class="signature-area">
        <div class="signature-block">
            <div class="signature-instructions">Service Provider Signature:</div>
            <div class="signature-field" data-signature="provider"></div>
            <div class="signature-line"></div>
            <div>[Service Provider Name & Title]</div>
            <div class="date-area">Date: _________________</div>
        </div>
        
        <div class="signature-block">
            <div class="signature-instructions">Client Signature:</div>
            <div class="signature-field" data-signature="client"></div>
            <div class="signature-line"></div>
            <div>[Client Name & Title]</div>
            <div class="date-area">Date: _________________</div>
        </div>
    </div>
</body>
</html>
EOT
    ]
];

// Handle template download
if (isset($_GET['download']) && array_key_exists($_GET['download'], $templates)) {
    $template = $templates[$_GET['download']];
    
    if ($template['type'] == 'html') {
        $filename = str_replace(' ', '_', strtolower($template['name'])) . '.html';
        header('Content-Type: text/html');
    } else {
        $filename = str_replace(' ', '_', strtolower($template['name'])) . '.txt';
        header('Content-Type: text/plain');
    }
    
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($template['content']));
    echo $template['content'];
    exit;
}

// Handle PDF template uploads
$uploadMessage = '';
$uploadSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_template'])) {
    // Check if file was uploaded without errors
    if (isset($_FILES['template_file']) && $_FILES['template_file']['error'] == 0) {
        $allowed = array('pdf' => 'application/pdf');
        $filename = $_FILES['template_file']['name'];
        $filetype = $_FILES['template_file']['type'];
        $filesize = $_FILES['template_file']['size'];
        
        // Verify file extension and MIME type
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (array_key_exists($ext, $allowed) && $filetype == $allowed[$ext]) {
            // Check file size - 5MB maximum
            $maxsize = 5 * 1024 * 1024;
            
            if ($filesize < $maxsize) {
                // Create upload directory if it doesn't exist
                $uploadDir = 'uploads/templates/';
                if (!file_exists($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                // Generate a unique filename
                $newFilename = uniqid() . '_' . $filename;
                $templateName = clean($_POST['template_name']);
                $templateDescription = clean($_POST['template_description']);
                
                // Save the file
                if (move_uploaded_file($_FILES['template_file']['tmp_name'], $uploadDir . $newFilename)) {
                    // Save the template info to the database
                    $userId = $_SESSION['user_id'];
                    $templatePath = $uploadDir . $newFilename;
                    
                    // Insert into database (will need to create this table)
                    $db->insert(
                        "INSERT INTO pdf_templates (user_id, name, description, file_path, created_at) VALUES (?, ?, ?, ?, NOW())",
                        [$userId, $templateName, $templateDescription, $templatePath]
                    );
                    
                    $uploadSuccess = true;
                    $uploadMessage = "Template uploaded successfully.";
                } else {
                    $uploadMessage = "Error saving the file.";
                }
            } else {
                $uploadMessage = "File is too large. Maximum size is 5MB.";
            }
        } else {
            $uploadMessage = "Invalid file type. Only PDF files are allowed.";
        }
    } else {
        $uploadMessage = "Error uploading file. Please try again.";
    }
}

// Get user's PDF templates from database
$pdfTemplates = [];
if (isLoggedIn()) {
    $userId = $_SESSION['user_id'];
    // Check if the table exists first
    $tableExists = $db->getValue("SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'pdf_templates'");
    
    if ($tableExists) {
        $pdfTemplates = $db->getRows(
            "SELECT * FROM pdf_templates WHERE user_id = ? ORDER BY created_at DESC",
            [$userId]
        );
    } else {
        // Create the pdf_templates table if it doesn't exist
        $db->query("
            CREATE TABLE IF NOT EXISTS pdf_templates (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                file_path VARCHAR(255) NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
    }
}

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">Document Templates</h1>
            
            <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-plus"></i> Add Template
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="#uploadPdfTemplate" data-toggle="modal">
                        <i class="fas fa-file-pdf text-danger"></i> Upload PDF Template
                    </a>
                    <a class="dropdown-item" href="#createHtmlTemplate" data-toggle="modal">
                        <i class="fas fa-file-code text-primary"></i> Create HTML Template
                    </a>
                    <a class="dropdown-item" href="#customTextTemplate">
                        <i class="fas fa-file-alt text-secondary"></i> Create Text Template
                    </a>
                </div>
            </div>
        </div>
        
        <?php if (!empty($uploadMessage)): ?>
        <div class="alert alert-<?php echo $uploadSuccess ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
            <?php echo $uploadMessage; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        
        <!-- Template type tabs -->
        <ul class="nav nav-tabs mb-4" id="templateTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="standard-templates-tab" data-toggle="tab" href="#standardTemplates" role="tab">
                    <i class="fas fa-file-alt"></i> Standard Templates
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="html-templates-tab" data-toggle="tab" href="#htmlTemplates" role="tab">
                    <i class="fas fa-file-code"></i> HTML Templates
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="pdf-templates-tab" data-toggle="tab" href="#pdfTemplates" role="tab">
                    <i class="fas fa-file-pdf"></i> PDF Templates
                </a>
            </li>
        </ul>
        
        <div class="tab-content" id="templateTabsContent">
            <!-- Standard text templates -->
            <div class="tab-pane fade show active" id="standardTemplates" role="tabpanel">
                <div class="row mb-4">
                    <?php 
                    foreach ($templates as $templateId => $template): 
                        if ($template['type'] == 'text'):
                    ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <span class="badge badge-pill <?php echo $template['signable'] ? 'badge-success' : 'badge-secondary'; ?>">
                                    <?php echo $template['signable'] ? 'Signable' : 'Non-Signable'; ?>
                                </span>
                                <span class="text-muted small">Text Template</span>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($template['name']); ?></h5>
                                <p class="card-text text-muted small"><?php echo htmlspecialchars($template['description']); ?></p>
                            </div>
                            <div class="card-footer bg-white border-top-0">
                                <div class="btn-group btn-block">
                                    <a href="?template=<?php echo $templateId; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i> Preview
                                    </a>
                                    <a href="?download=<?php echo $templateId; ?>" class="btn btn-sm btn-outline-success">
                                        <i class="fas fa-download"></i> Download
                                    </a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary use-template" data-template="<?php echo $templateId; ?>">
                                        <i class="fas fa-plus"></i> Use
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
            </div>
            
            <!-- HTML templates -->
            <div class="tab-pane fade" id="htmlTemplates" role="tabpanel">
                <div class="row mb-4">
                    <?php 
                    foreach ($templates as $templateId => $template): 
                        if ($template['type'] == 'html'):
                    ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <span class="badge badge-pill badge-primary">HTML</span>
                                <span class="text-muted small">
                                    <i class="fas <?php echo $template['signable'] ? 'fa-signature text-success' : 'fa-times text-danger'; ?>"></i>
                                    <?php echo $template['signable'] ? 'Signable' : 'Non-Signable'; ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($template['name']); ?></h5>
                                <p class="card-text text-muted small"><?php echo htmlspecialchars($template['description']); ?></p>
                            </div>
                            <div class="card-footer bg-white border-top-0">
                                <div class="btn-group btn-block">
                                    <a href="?template=<?php echo $templateId; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i> Preview
                                    </a>
                                    <a href="?download=<?php echo $templateId; ?>" class="btn btn-sm btn-outline-success">
                                        <i class="fas fa-download"></i> Download
                                    </a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary use-template" data-template="<?php echo $templateId; ?>">
                                        <i class="fas fa-plus"></i> Use
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
            </div>
            
            <!-- PDF templates -->
            <div class="tab-pane fade" id="pdfTemplates" role="tabpanel">
                <?php if (!empty($pdfTemplates)): ?>
                <div class="row mb-4">
                    <?php foreach ($pdfTemplates as $template): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <span class="badge badge-pill badge-danger">PDF</span>
                                <span class="text-muted small">
                                    <i class="far fa-calendar-alt"></i> 
                                    <?php echo date('M j, Y', strtotime($template['created_at'])); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($template['name']); ?></h5>
                                <p class="card-text text-muted small"><?php echo htmlspecialchars($template['description']); ?></p>
                            </div>
                            <div class="card-footer bg-white border-top-0">
                                <div class="btn-group btn-block">
                                    <a href="<?php echo $template['file_path']; ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <a href="<?php echo $template['file_path']; ?>" download class="btn btn-sm btn-outline-success">
                                        <i class="fas fa-download"></i> Download
                                    </a>
                                    <a href="/sign_document.php?template_id=<?php echo $template['id']; ?>" class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-signature"></i> Sign
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-5">
                    <div class="mb-3">
                        <i class="fas fa-file-pdf fa-4x text-muted"></i>
                    </div>
                    <h5>No PDF templates yet</h5>
                    <p class="text-muted">Upload a PDF template to get started</p>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#uploadPdfTemplate">
                        <i class="fas fa-upload"></i> Upload PDF Template
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ($selectedTemplate && array_key_exists($selectedTemplate, $templates)): ?>
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo htmlspecialchars($templates[$selectedTemplate]['name']); ?> Preview</h5>
                <div>
                    <span class="badge badge-pill badge-<?php echo $templates[$selectedTemplate]['type'] == 'html' ? 'primary' : 'secondary'; ?> mr-2">
                        <?php echo strtoupper($templates[$selectedTemplate]['type']); ?>
                    </span>
                    <a href="?download=<?php echo $selectedTemplate; ?>" class="btn btn-sm btn-success">
                        <i class="fas fa-download"></i> Download
                    </a>
                    <a href="#" class="btn btn-sm btn-primary use-template" data-template="<?php echo $selectedTemplate; ?>">
                        <i class="fas fa-plus"></i> Use This Template
                    </a>
                </div>
            </div>
            <div class="card-body">
                <?php if ($templates[$selectedTemplate]['type'] == 'html'): ?>
                <div class="border rounded mb-3">
                    <div class="bg-light border-bottom p-2">
                        <small class="text-muted"><i class="fas fa-code"></i> HTML Preview</small>
                    </div>
                    <iframe id="htmlPreview" srcdoc="<?php echo htmlspecialchars($templates[$selectedTemplate]['content']); ?>" style="width: 100%; height: 600px; border: none;"></iframe>
                </div>
                <div class="accordion" id="htmlCodeAccordion">
                    <div class="card">
                        <div class="card-header p-0" id="htmlCodeHeading">
                            <button class="btn btn-link btn-block text-left text-decoration-none" type="button" data-toggle="collapse" data-target="#htmlCodeCollapse" aria-expanded="false" aria-controls="htmlCodeCollapse">
                                <i class="fas fa-code"></i> View HTML Code
                            </button>
                        </div>
                        <div id="htmlCodeCollapse" class="collapse" aria-labelledby="htmlCodeHeading" data-parent="#htmlCodeAccordion">
                            <div class="card-body p-0">
                                <pre class="bg-light p-3 border rounded mb-0" style="max-height: 400px; overflow: auto;"><code class="html"><?php echo htmlspecialchars($templates[$selectedTemplate]['content']); ?></code></pre>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <pre class="bg-light p-3 border rounded" style="white-space: pre-wrap;"><?php echo htmlspecialchars($templates[$selectedTemplate]['content']); ?></pre>
                <?php endif; ?>
            </div>
        </div>
        <?php elseif (!isset($_GET['template'])): ?>
        <div class="card mb-4">
            <div class="card-body">
                <div class="text-center py-5">
                    <div class="mb-3">
                        <i class="fas fa-file-alt fa-4x text-muted"></i>
                    </div>
                    <h5>Select a template to preview</h5>
                    <p class="text-muted">Choose from our collection of professional document templates</p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Custom text template feature -->
        <div class="card" id="customTextTemplate">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i class="fas fa-file-alt text-secondary"></i> Create Custom Text Template</h5>
            </div>
            <div class="card-body">
                <form id="customTemplateForm">
                    <div class="form-group">
                        <label for="templateName">Template Name</label>
                        <input type="text" class="form-control" id="templateName" required>
                    </div>
                    <div class="form-group">
                        <label for="templateDescription">Description</label>
                        <input type="text" class="form-control" id="templateDescription" required>
                    </div>
                    <div class="form-group">
                        <label for="templateContent">Template Content</label>
                        <textarea class="form-control" id="templateContent" rows="10" required></textarea>
                        <small class="form-text text-muted">
                            Use placeholders like [Company Name], [Date], etc. for dynamic content.
                        </small>
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" class="form-check-input" id="templateSignable" checked>
                        <label class="form-check-label" for="templateSignable">Make template signable</label>
                    </div>
                    <button type="button" class="btn btn-primary" id="saveTemplateBtn">
                        <i class="fas fa-save"></i> Save Template
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Upload PDF Template Modal -->
<div class="modal fade" id="uploadPdfTemplate" tabindex="-1" role="dialog" aria-labelledby="uploadPdfTemplateTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="uploadPdfTemplateTitle">Upload PDF Template</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="template_name">Template Name</label>
                        <input type="text" class="form-control" id="template_name" name="template_name" required>
                    </div>
                    <div class="form-group">
                        <label for="template_description">Description</label>
                        <textarea class="form-control" id="template_description" name="template_description" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="template_file">PDF File</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="template_file" name="template_file" accept=".pdf" required>
                            <label class="custom-file-label" for="template_file">Choose file</label>
                        </div>
                        <small class="form-text text-muted">
                            Only PDF files are allowed. Maximum size: 5MB.
                        </small>
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> PDF templates can be used for signing and sending to recipients.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" name="upload_template" class="btn btn-primary">Upload Template</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Create HTML Template Modal -->
<div class="modal fade" id="createHtmlTemplate" tabindex="-1" role="dialog" aria-labelledby="createHtmlTemplateTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createHtmlTemplateTitle">Create HTML Template</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> HTML templates allow for rich formatting and styling. You can include signature fields in your template.
                </div>
                <div class="form-group">
                    <label for="html_template_name">Template Name</label>
                    <input type="text" class="form-control" id="html_template_name" required>
                </div>
                <div class="form-group">
                    <label for="html_template_description">Description</label>
                    <textarea class="form-control" id="html_template_description" rows="2" required></textarea>
                </div>
                <div class="form-group">
                    <label for="html_template_content">HTML Content</label>
                    <div class="border">
                        <textarea class="form-control" id="html_template_content" rows="15" style="font-family: monospace;"></textarea>
                    </div>
                    <small class="form-text text-muted">
                        Use HTML and CSS to create your template. Add signature fields with <code>&lt;div class="signature-field" data-signature="name"&gt;&lt;/div&gt;</code>.
                    </small>
                </div>
                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="html_template_signable" checked>
                    <label class="form-check-label" for="html_template_signable">Make template signable</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="saveHtmlTemplateBtn">Save Template</button>
            </div>
        </div>
    </div>
</div>

<!-- Use Template Modal -->
<div class="modal fade" id="useTemplateModal" tabindex="-1" role="dialog" aria-labelledby="useTemplateModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="useTemplateModalLabel">Use Template</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="template-info mb-4">
                    <h6 class="text-muted">Selected Template:</h6>
                    <h5 id="selectedTemplateName"></h5>
                    <span class="badge badge-pill badge-primary mb-3" id="selectedTemplateType"></span>
                </div>
                
                <p>How would you like to use this template?</p>
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action" id="createDocumentBtn">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1">Create New Document</h5>
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <p class="mb-1">Use this template to create a new document in the system.</p>
                    </a>
                    <a href="#" class="list-group-item list-group-item-action" id="editTemplateBtn">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1">Edit Template</h5>
                            <i class="fas fa-edit"></i>
                        </div>
                        <p class="mb-1">Modify this template before creating a document.</p>
                    </a>
                    <a href="#" class="list-group-item list-group-item-action" id="signTemplateBtn">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1">Sign Template</h5>
                            <i class="fas fa-signature"></i>
                        </div>
                        <p class="mb-1">Directly sign this template.</p>
                    </a>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<!-- PDF Verification Modal -->
<div class="modal fade" id="pdfVerificationModal" tabindex="-1" role="dialog" aria-labelledby="pdfVerificationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pdfVerificationModalLabel">PDF Signature Verification</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="text-center py-4">
                    <div class="mb-4">
                        <i class="fas fa-check-circle fa-4x text-success"></i>
                    </div>
                    <h5 class="mb-3">PDF Is Signable</h5>
                    <p>This PDF can be used for electronic signatures. The system has verified that it:</p>
                    <ul class="list-group list-group-flush text-left">
                        <li class="list-group-item text-success"><i class="fas fa-check"></i> Is compatible with our signature system</li>
                        <li class="list-group-item text-success"><i class="fas fa-check"></i> Doesn't have existing security restrictions</li>
                        <li class="list-group-item text-success"><i class="fas fa-check"></i> Supports form field placement</li>
                    </ul>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a href="#" id="continueToSignBtn" class="btn btn-primary">Continue to Sign</a>
            </div>
        </div>
    </div>
</div>

<script>
    // Initialize template features
    document.addEventListener('DOMContentLoaded', function() {
        // Use template buttons
        const useTemplateButtons = document.querySelectorAll('.use-template');
        useTemplateButtons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const templateId = this.getAttribute('data-template');
                
                // Get template info (this would need to be enhanced for a real implementation)
                let templateName = 'Selected Template';
                let templateType = 'TEXT';
                
                if (templateId) {
                    // Find the template name and type from the DOM
                    const cardEl = this.closest('.card');
                    if (cardEl) {
                        const nameEl = cardEl.querySelector('.card-title');
                        if (nameEl) templateName = nameEl.textContent;
                        
                        const typeEl = cardEl.querySelector('.badge-pill');
                        if (typeEl) templateType = typeEl.textContent;
                    }
                }
                
                // Update the modal with template info
                document.getElementById('selectedTemplateName').textContent = templateName;
                document.getElementById('selectedTemplateType').textContent = templateType;
                
                // Store the template ID for later use
                sessionStorage.setItem('selectedTemplateId', templateId);
                
                $('#useTemplateModal').modal('show');
            });
        });
        
        // Create document from template
        const createDocumentBtn = document.getElementById('createDocumentBtn');
        if (createDocumentBtn) {
            createDocumentBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const templateId = sessionStorage.getItem('selectedTemplateId');
                
                // In a real implementation, this would create a document
                alert('Creating document from template! This functionality will be fully implemented soon.');
                $('#useTemplateModal').modal('hide');
                
                // Redirect to a document creation page (to be implemented)
                // window.location.href = '/create_document.php?template=' + templateId;
            });
        }
        
        // Edit template 
        const editTemplateBtn = document.getElementById('editTemplateBtn');
        if (editTemplateBtn) {
            editTemplateBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const templateId = sessionStorage.getItem('selectedTemplateId');
                
                if (templateId) {
                    // Check if we're currently viewing the template
                    const urlParams = new URLSearchParams(window.location.search);
                    const currentTemplate = urlParams.get('template');
                    
                    if (currentTemplate === templateId) {
                        // Get the content from the currently displayed template
                        let content = '';
                        let templateTypeSelector = '#customTextTemplate';
                        
                        const preEl = document.querySelector('.card-body pre');
                        if (preEl) {
                            content = preEl.textContent;
                            
                            // Check which type of template we're dealing with
                            const templateTypeEl = document.querySelector('.badge-pill.mr-2');
                            if (templateTypeEl && templateTypeEl.textContent.trim() === 'HTML') {
                                templateTypeSelector = '#createHtmlTemplate';
                                
                                // For HTML templates, we'll need to put it in the HTML editor
                                document.getElementById('html_template_content').value = content;
                                document.getElementById('html_template_name').value = document.getElementById('selectedTemplateName').textContent + ' (Copy)';
                                document.getElementById('html_template_description').value = '';
                                
                                // Show the HTML template modal
                                $('#useTemplateModal').modal('hide');
                                $(templateTypeSelector).modal('show');
                                return;
                            }
                        }
                        
                        // For text templates
                        document.getElementById('templateContent').value = content;
                        document.getElementById('templateName').value = document.getElementById('selectedTemplateName').textContent + ' (Copy)';
                        document.getElementById('templateDescription').value = '';
                        
                        $('#useTemplateModal').modal('hide');
                        // Scroll to the form
                        document.getElementById('customTemplateForm').scrollIntoView({behavior: 'smooth'});
                    } else {
                        // Not viewing the template, so we need to redirect
                        window.location.href = '?template=' + templateId;
                    }
                }
            });
        }
        
        // Sign template
        const signTemplateBtn = document.getElementById('signTemplateBtn');
        if (signTemplateBtn) {
            signTemplateBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const templateId = sessionStorage.getItem('selectedTemplateId');
                
                // Show PDF verification modal for a moment (simulating checking)
                $('#useTemplateModal').modal('hide');
                
                // Simulate checking PDF
                setTimeout(function() {
                    $('#pdfVerificationModal').modal('show');
                }, 500);
            });
        }
        
        // Continue to sign button
        const continueToSignBtn = document.getElementById('continueToSignBtn');
        if (continueToSignBtn) {
            continueToSignBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const templateId = sessionStorage.getItem('selectedTemplateId');
                
                // Close modal
                $('#pdfVerificationModal').modal('hide');
                
                // Redirect to sign page (to be implemented)
                alert('Continuing to sign document! This functionality will be fully implemented soon.');
                // window.location.href = '/sign_document.php?template=' + templateId;
            });
        }
        
        // Save custom text template
        const saveTemplateBtn = document.getElementById('saveTemplateBtn');
        if (saveTemplateBtn) {
            saveTemplateBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const name = document.getElementById('templateName').value.trim();
                const description = document.getElementById('templateDescription').value.trim();
                const content = document.getElementById('templateContent').value.trim();
                const signable = document.getElementById('templateSignable').checked;
                
                if (!name || !description || !content) {
                    alert('Please fill in all fields.');
                    return;
                }
                
                // In a real implementation, this would save the template to the database
                alert('Template saved successfully! (This is a demo, actual saving functionality will be implemented in the future)');
                document.getElementById('customTemplateForm').reset();
            });
        }
        
        // Save HTML template
        const saveHtmlTemplateBtn = document.getElementById('saveHtmlTemplateBtn');
        if (saveHtmlTemplateBtn) {
            saveHtmlTemplateBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const name = document.getElementById('html_template_name').value.trim();
                const description = document.getElementById('html_template_description').value.trim();
                const content = document.getElementById('html_template_content').value.trim();
                const signable = document.getElementById('html_template_signable').checked;
                
                if (!name || !description || !content) {
                    alert('Please fill in all fields.');
                    return;
                }
                
                // In a real implementation, this would save the template to the database
                alert('HTML Template saved successfully! (This is a demo, actual saving functionality will be implemented in the future)');
                $('#createHtmlTemplate').modal('hide');
                document.getElementById('html_template_name').value = '';
                document.getElementById('html_template_description').value = '';
                document.getElementById('html_template_content').value = '';
            });
        }
        
        // Initialize file input display for custom file inputs
        const fileInputs = document.querySelectorAll('.custom-file-input');
        fileInputs.forEach(function(input) {
            input.addEventListener('change', function(e) {
                const fileName = e.target.files[0].name;
                const label = e.target.nextElementSibling;
                label.textContent = fileName;
            });
        });
    });
</script>

<?php include 'includes/footer.php'; ?>