<?php
// Set page title
$page_title = "View Document";

// Include necessary files
require_once '../config/database.php';
require_once '../config/constants.php';
require_once '../includes/header.php';

// Check if document ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../dashboard/documents.php");
    exit();
}

// Get document ID
$document_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

// Get document details
$stmt = $conn->prepare("SELECT id, user_id, title, filename, filepath, status, recipient_email, created_at FROM documents WHERE id = ?");
$stmt->bind_param("i", $document_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if document exists and belongs to the user
if ($result->num_rows === 0) {
    header("Location: ../dashboard/documents.php");
    exit();
}

$document = $result->fetch_assoc();

// Check if the document belongs to the current user
if ($document['user_id'] != $user_id) {
    header("Location: ../dashboard/documents.php");
    exit();
}

// Get document path
$document_path = UPLOAD_DIR . $document['filepath'];
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo htmlspecialchars($document['title']); ?></h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="send.php?id=<?php echo $document_id; ?>" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-paper-plane"></i> Send for Signature
                </a>
                <a href="download.php?id=<?php echo $document_id; ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-download"></i> Download
                </a>
                <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Document Preview</h5>
                </div>
                <div class="card-body p-0">
                    <div id="pdfViewer" style="height: 600px;"></div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Document Details</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><strong>Title:</strong></span>
                            <span><?php echo htmlspecialchars($document['title']); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><strong>Filename:</strong></span>
                            <span><?php echo htmlspecialchars($document['filename']); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><strong>Status:</strong></span>
                            <span class="badge bg-<?php echo getDocumentStatusClass($document['status']); ?>">
                                <?php echo getDocumentStatus($document['status']); ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><strong>Recipient:</strong></span>
                            <span><?php echo htmlspecialchars($document['recipient_email'] ?? 'Not sent yet'); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><strong>Date Created:</strong></span>
                            <span><?php echo formatDate($document['created_at']); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Signature Status</h5>
                </div>
                <div class="card-body">
                    <?php if ($document['status'] == 0): ?>
                        <div class="alert alert-warning mb-0">
                            <i class="fas fa-clock me-2"></i> This document has not been signed yet.
                            <hr>
                            <a href="send.php?id=<?php echo $document_id; ?>" class="btn btn-primary btn-sm">Send for Signature</a>
                        </div>
                    <?php elseif ($document['status'] == 1): ?>
                        <div class="alert alert-success mb-0">
                            <i class="fas fa-check-circle me-2"></i> This document has been signed.
                            <hr>
                            <a href="download.php?id=<?php echo $document_id; ?>" class="btn btn-primary btn-sm">Download Signed Document</a>
                        </div>
                    <?php elseif ($document['status'] == 2): ?>
                        <div class="alert alert-danger mb-0">
                            <i class="fas fa-exclamation-circle me-2"></i> This document has expired.
                            <hr>
                            <a href="send.php?id=<?php echo $document_id; ?>" class="btn btn-primary btn-sm">Resend for Signature</a>
                        </div>
                    <?php elseif ($document['status'] == 3): ?>
                        <div class="alert alert-danger mb-0">
                            <i class="fas fa-times-circle me-2"></i> This document has been rejected.
                            <hr>
                            <a href="send.php?id=<?php echo $document_id; ?>" class="btn btn-primary btn-sm">Resend for Signature</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this document? This action cannot be undone.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <a href="delete.php?id=<?php echo $document_id; ?>" class="btn btn-danger">Delete</a>
            </div>
        </div>
    </div>
</div>

<!-- PDF.js scripts -->
<script src="<?php echo APP_URL; ?>/assets/js/pdf.min.js"></script>
<script src="<?php echo APP_URL; ?>/assets/js/pdf.worker.min.js"></script>
<script>
// Specify the path to the PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = '<?php echo APP_URL; ?>/assets/js/pdf.worker.min.js';

// The URL of the PDF document
var url = '<?php echo APP_URL; ?>/documents/download.php?id=<?php echo $document_id; ?>&raw=1';

// Asynchronous download PDF
var loadingTask = pdfjsLib.getDocument(url);
loadingTask.promise.then(function(pdf) {
    console.log('PDF loaded');
    
    // Get the first page
    pdf.getPage(1).then(function(page) {
        console.log('Page loaded');
        
        var scale = 1.5;
        var viewport = page.getViewport({scale: scale});

        // Prepare canvas using PDF page dimensions
        var container = document.getElementById('pdfViewer');
        var canvas = document.createElement('canvas');
        container.appendChild(canvas);
        
        var context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        canvas.style.width = '100%';
        canvas.style.height = 'auto';

        // Render PDF page into canvas context
        var renderContext = {
            canvasContext: context,
            viewport: viewport
        };
        
        var renderTask = page.render(renderContext);
        renderTask.promise.then(function () {
            console.log('Page rendered');
        });
    });
}, function (reason) {
    // PDF loading error
    console.error(reason);
    document.getElementById('pdfViewer').innerHTML = '<div class="alert alert-danger m-3">Failed to load PDF. Please try downloading it instead.</div>';
});
</script>

<?php
// Include footer
require_once '../includes/footer.php';
?>
