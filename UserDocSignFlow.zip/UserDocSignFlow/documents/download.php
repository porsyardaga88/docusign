<?php
// Start session
session_start();

// Include necessary files
require_once '../config/database.php';
require_once '../config/constants.php';
require_once '../includes/functions.php';

// Check if document ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../dashboard/documents.php");
    exit();
}

// Get document ID
$document_id = (int)$_GET['id'];

// Check if token is provided for public access
$has_token = isset($_GET['token']) && !empty($_GET['token']);
$is_raw = isset($_GET['raw']) && $_GET['raw'] == 1;

// If token is not provided, require login
if (!$has_token) {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../auth/login.php");
        exit();
    }
    
    $user_id = $_SESSION['user_id'];
    
    // Check if the document belongs to the current user
    $stmt = $conn->prepare("SELECT filepath, filename FROM documents WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $document_id, $user_id);
} else {
    // Use token to verify access
    $token = $_GET['token'];
    $stmt = $conn->prepare("SELECT filepath, filename FROM documents WHERE id = ? AND signature_token = ?");
    $stmt->bind_param("is", $document_id, $token);
}

$stmt->execute();
$result = $stmt->get_result();

// Check if document exists and user has access
if ($result->num_rows === 0) {
    header("Location: ../dashboard/documents.php");
    exit();
}

$document = $result->fetch_assoc();
$file_path = UPLOAD_DIR . $document['filepath'];

// Check if file exists
if (!file_exists($file_path)) {
    die('File not found.');
}

// Get file info
$file_size = filesize($file_path);
$file_name = $document['filename'];

// Set headers for file download
header('Content-Description: File Transfer');
header('Content-Type: application/pdf');

if (!$is_raw) {
    header('Content-Disposition: attachment; filename="' . $file_name . '"');
}

header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . $file_size);

// Clear output buffer
ob_clean();
flush();

// Read file and output to browser
readfile($file_path);
exit;
?>
