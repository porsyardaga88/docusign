<?php
// Set page title
$page_title = "Upload Document";

// Include necessary files
require_once '../config/database.php';
require_once '../config/constants.php';
require_once '../includes/header.php';

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Initialize variables
$title = "";
$upload_err = $upload_success = "";

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate title
    if (empty(trim($_POST["title"]))) {
        $upload_err = "Please enter a document title.";
    } else {
        $title = sanitize($_POST["title"]);
    }
    
    // Check if file was uploaded
    if (empty($upload_err) && isset($_FILES["document"]) && $_FILES["document"]["error"] == UPLOAD_ERR_OK) {
        $file_name = $_FILES["document"]["name"];
        $file_tmp = $_FILES["document"]["tmp_name"];
        $file_size = $_FILES["document"]["size"];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Check file extension
        if (!isAllowedExtension($file_name)) {
            $upload_err = "Only PDF files are allowed.";
        }
        
        // Check file size
        if ($file_size > MAX_FILE_SIZE) {
            $upload_err = "File size must be less than " . (MAX_FILE_SIZE / 1024 / 1024) . "MB.";
        }
        
        // If no errors, proceed with upload
        if (empty($upload_err)) {
            // Generate unique filename
            $new_file_name = generateRandomString() . '_' . time() . '.' . $file_ext;
            $upload_path = UPLOAD_DIR . $new_file_name;
            
            // Create upload directory if it doesn't exist
            if (!file_exists(UPLOAD_DIR)) {
                mkdir(UPLOAD_DIR, 0755, true);
            }
            
            // Move uploaded file to destination
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // Save document information to database
                $stmt = $conn->prepare("INSERT INTO documents (user_id, title, filename, filepath, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt->bind_param("isssi", $user_id, $title, $file_name, $new_file_name, $status);
                
                $status = 0; // 0 = Pending
                
                if ($stmt->execute()) {
                    $document_id = $stmt->insert_id;
                    $upload_success = "Document uploaded successfully.";
                    
                    // Redirect to view document page
                    header("Location: view.php?id=" . $document_id);
                    exit();
                } else {
                    $upload_err = "Error saving document information. Please try again.";
                    // Delete uploaded file if database insertion fails
                    unlink($upload_path);
                }
                
                // Close statement
                $stmt->close();
            } else {
                $upload_err = "Error uploading file. Please try again.";
            }
        }
    } else if ($_FILES["document"]["error"] != UPLOAD_ERR_OK && $_FILES["document"]["error"] != UPLOAD_ERR_NO_FILE) {
        // Handle file upload errors
        switch ($_FILES["document"]["error"]) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                $upload_err = "File size exceeds the maximum limit.";
                break;
            case UPLOAD_ERR_PARTIAL:
                $upload_err = "The file was only partially uploaded.";
                break;
            case UPLOAD_ERR_NO_TMP_DIR:
                $upload_err = "Missing a temporary folder.";
                break;
            case UPLOAD_ERR_CANT_WRITE:
                $upload_err = "Failed to write file to disk.";
                break;
            case UPLOAD_ERR_EXTENSION:
                $upload_err = "File upload stopped by extension.";
                break;
            default:
                $upload_err = "Unknown upload error.";
        }
    } else if ($_FILES["document"]["error"] == UPLOAD_ERR_NO_FILE) {
        $upload_err = "Please select a file to upload.";
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Upload Document</h1>
    </div>

    <?php if (!empty($upload_success)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $upload_success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($upload_err)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $upload_err; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="title" class="form-label">Document Title</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo $title; ?>" required>
                            <div class="form-text">Give your document a descriptive title.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="document" class="form-label">Select Document (PDF)</label>
                            <input type="file" class="form-control" id="document" name="document" accept=".pdf" required>
                            <div class="form-text">Only PDF files are supported (max <?php echo MAX_FILE_SIZE / 1024 / 1024; ?>MB).</div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">Upload Document</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Upload Guidelines</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            Only PDF files are accepted
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            Maximum file size: <?php echo MAX_FILE_SIZE / 1024 / 1024; ?>MB
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            Make sure your document is clear and readable
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            You can add signature fields after uploading
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-body">
                    <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40" class="img-fluid rounded" alt="Document Upload">
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once '../includes/footer.php';
?>
