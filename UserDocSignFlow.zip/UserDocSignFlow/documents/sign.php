<?php
// Start session
session_start();

// Include necessary files
require_once '../config/database.php';
require_once '../config/constants.php';
require_once '../includes/functions.php';

// Check if token is provided
if (!isset($_GET['token']) || empty($_GET['token'])) {
    header("Location: ../index.php");
    exit();
}

// Get token
$token = $_GET['token'];

// Get document details based on token
$stmt = $conn->prepare("SELECT d.id, d.user_id, d.title, d.filename, d.filepath, d.status, u.name as sender_name, u.email as sender_email 
                       FROM documents d 
                       JOIN users u ON d.user_id = u.id 
                       WHERE d.signature_token = ? AND d.status = 0");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

// Check if document exists
if ($result->num_rows === 0) {
    // Token is invalid or document already signed
    header("Location: ../index.php");
    exit();
}

$document = $result->fetch_assoc();
$document_id = $document['id'];
$document_path = UPLOAD_DIR . $document['filepath'];

// Check if form is submitted
$signature_data = $signature_err = $sign_success = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate signature
    if (empty($_POST["signature_data"])) {
        $signature_err = "Please sign the document.";
    } else {
        $signature_data = $_POST["signature_data"];
        
        // Update document status to signed (1)
        $stmt = $conn->prepare("UPDATE documents SET status = 1, signed_at = NOW(), signature_data = ? WHERE id = ?");
        $stmt->bind_param("si", $signature_data, $document_id);
        
        if ($stmt->execute()) {
            // Send email to document owner
            $to = $document['sender_email'];
            $subject = "Document Signed: " . $document['title'];
            $body = "Hello " . $document['sender_name'] . ",<br><br>";
            $body .= "The document \"" . $document['title'] . "\" has been signed.<br><br>";
            $body .= "You can view and download the signed document from your dashboard.<br><br>";
            $body .= "Thank you for using " . APP_NAME . "!";
            
            sendEmail($to, $subject, $body);
            
            $sign_success = "Document signed successfully!";
        } else {
            $signature_err = "Something went wrong. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Document - <?php echo APP_NAME; ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <header class="navbar navbar-expand-md navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="fas fa-file-signature me-2"></i><?php echo APP_NAME; ?>
            </a>
        </div>
    </header>

    <div class="container py-5">
        <?php if (!empty($sign_success)): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <?php echo $sign_success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            
            <div class="card mb-4">
                <div class="card-body text-center">
                    <i class="fas fa-check-circle text-success fa-5x mb-3"></i>
                    <h2>Thank You!</h2>
                    <p class="lead">The document has been signed successfully.</p>
                    <p>A confirmation email has been sent to the document owner.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h4 class="mb-0"><?php echo htmlspecialchars($document['title']); ?></h4>
                        </div>
                        <div class="card-body p-0">
                            <div id="pdfViewer" style="height: 600px;"></div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Sign Document</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($signature_err)): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $signature_err; ?>
                                </div>
                            <?php endif; ?>
                            
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?token=" . $token); ?>" method="post" id="signatureForm">
                                <div class="mb-3">
                                    <label for="signature" class="form-label">Your Signature:</label>
                                    <div class="border rounded p-3">
                                        <canvas id="signatureCanvas" width="320" height="200" class="border rounded w-100"></canvas>
                                    </div>
                                    <div class="d-flex justify-content-between mt-2">
                                        <button type="button" id="clearSignature" class="btn btn-sm btn-outline-secondary">Clear</button>
                                        <div>
                                            <span class="text-muted small">Please sign above</span>
                                        </div>
                                    </div>
                                    <input type="hidden" name="signature_data" id="signature_data">
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="agreement" required>
                                    <label class="form-check-label" for="agreement">I agree that this is my legal signature and I consent to sign this document.</label>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary" id="signButton">Sign Document</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Document Information</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><strong>Title:</strong></span>
                                    <span><?php echo htmlspecialchars($document['title']); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><strong>Sender:</strong></span>
                                    <span><?php echo htmlspecialchars($document['sender_name']); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><strong>Date:</strong></span>
                                    <span><?php echo date("F j, Y"); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <footer class="bg-light py-4 mt-auto">
        <div class="container">
            <div class="text-center">
                <p class="text-muted mb-0">&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- PDF.js scripts -->
    <script src="../assets/js/pdf.min.js"></script>
    <script src="../assets/js/pdf.worker.min.js"></script>
    <!-- Signature Pad -->
    <script src="../assets/js/signature_pad.min.js"></script>
    
    <script>
    <?php if (empty($sign_success)): ?>
        // Initialize PDF.js
        pdfjsLib.GlobalWorkerOptions.workerSrc = '../assets/js/pdf.worker.min.js';
        
        // The URL of the PDF document
        var url = 'download.php?id=<?php echo $document_id; ?>&raw=1&token=<?php echo $token; ?>';
        
        // Asynchronous download PDF
        var loadingTask = pdfjsLib.getDocument(url);
        loadingTask.promise.then(function(pdf) {
            console.log('PDF loaded');
            
            // Get the first page
            pdf.getPage(1).then(function(page) {
                console.log('Page loaded');
                
                var scale = 1.5;
                var viewport = page.getViewport({scale: scale});
        
                // Prepare canvas using PDF page dimensions
                var container = document.getElementById('pdfViewer');
                var canvas = document.createElement('canvas');
                container.appendChild(canvas);
                
                var context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                canvas.style.width = '100%';
                canvas.style.height = 'auto';
        
                // Render PDF page into canvas context
                var renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };
                
                var renderTask = page.render(renderContext);
                renderTask.promise.then(function () {
                    console.log('Page rendered');
                });
            });
        }, function (reason) {
            // PDF loading error
            console.error(reason);
            document.getElementById('pdfViewer').innerHTML = '<div class="alert alert-danger m-3">Failed to load PDF.</div>';
        });
        
        // Initialize Signature Pad
        var canvas = document.getElementById('signatureCanvas');
        var signaturePad = new SignaturePad(canvas, {
            backgroundColor: 'rgb(255, 255, 255)',
            penColor: 'rgb(0, 0, 0)'
        });
        
        // Clear signature
        document.getElementById('clearSignature').addEventListener('click', function() {
            signaturePad.clear();
        });
        
        // Form submission
        document.getElementById('signatureForm').addEventListener('submit', function(e) {
            if (signaturePad.isEmpty()) {
                e.preventDefault();
                alert('Please sign the document');
                return false;
            }
            
            // Save signature data
            var signatureData = signaturePad.toDataURL();
            document.getElementById('signature_data').value = signatureData;
        });
        
        // Adjust canvas size
        function resizeCanvas() {
            var ratio = Math.max(window.devicePixelRatio || 1, 1);
            canvas.width = canvas.offsetWidth * ratio;
            canvas.height = canvas.offsetHeight * ratio;
            canvas.getContext("2d").scale(ratio, ratio);
            signaturePad.clear(); // Clear the canvas
        }
        
        // Resize canvas on window resize
        window.addEventListener("resize", resizeCanvas);
        resizeCanvas(); // Initial resize
    <?php endif; ?>
    </script>
</body>
</html>
