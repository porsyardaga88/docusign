<?php
// Set page title
$page_title = "Send Document";

// Include necessary files
require_once '../config/database.php';
require_once '../config/constants.php';
require_once '../includes/header.php';

// Check if document ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../dashboard/documents.php");
    exit();
}

// Get document ID and user ID
$document_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

// Get document details
$stmt = $conn->prepare("SELECT id, title, filename, filepath, status FROM documents WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $document_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if document exists and belongs to the user
if ($result->num_rows === 0) {
    header("Location: ../dashboard/documents.php");
    exit();
}

$document = $result->fetch_assoc();

// Initialize variables
$recipient_email = $recipient_name = $message = "";
$send_err = $send_success = "";

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate recipient email
    if (empty(trim($_POST["recipient_email"]))) {
        $send_err = "Please enter recipient email.";
    } else {
        $recipient_email = filter_var(trim($_POST["recipient_email"]), FILTER_VALIDATE_EMAIL);
        if (!$recipient_email) {
            $send_err = "Please enter a valid email address.";
        }
    }
    
    // Validate recipient name
    if (empty(trim($_POST["recipient_name"]))) {
        $recipient_name = "Recipient";
    } else {
        $recipient_name = sanitize($_POST["recipient_name"]);
    }
    
    // Get message
    $message = sanitize($_POST["message"]);
    
    // If no errors, proceed with sending
    if (empty($send_err)) {
        // Generate signature token
        $signature_token = bin2hex(random_bytes(16));
        
        // Update document with recipient and token
        $stmt = $conn->prepare("UPDATE documents SET recipient_email = ?, recipient_name = ?, signature_token = ?, sent_at = NOW() WHERE id = ?");
        $stmt->bind_param("sssi", $recipient_email, $recipient_name, $signature_token, $document_id);
        
        if ($stmt->execute()) {
            // Prepare email
            $sign_link = APP_URL . "/documents/sign.php?token=" . $signature_token;
            
            $subject = "Document for Signature: " . $document['title'];
            
            $body = "<p>Hello " . $recipient_name . ",</p>";
            $body .= "<p>" . $_SESSION['name'] . " has sent you a document to sign using " . APP_NAME . ".</p>";
            
            if (!empty($message)) {
                $body .= "<p><strong>Message:</strong> " . nl2br($message) . "</p>";
            }
            
            $body .= "<p>Please click on the link below to view and sign the document:</p>";
            $body .= "<p><a href='" . $sign_link . "'>" . $document['title'] . "</a></p>";
            $body .= "<p>Thank you,<br>" . $_SESSION['name'] . "</p>";
            
            // Send email
            if (sendEmail($recipient_email, $subject, $body)) {
                $send_success = "Document sent successfully to " . $recipient_email;
            } else {
                $send_err = "Failed to send email. Please try again.";
            }
        } else {
            $send_err = "Something went wrong. Please try again.";
        }
        
        // Close statement
        $stmt->close();
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Send Document for Signature</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="view.php?id=<?php echo $document_id; ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-eye"></i> View Document
                </a>
            </div>
        </div>
    </div>

    <?php if (!empty($send_success)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $send_success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        
        <div class="card mb-4">
            <div class="card-body text-center">
                <i class="fas fa-envelope-open-text text-success fa-4x mb-3"></i>
                <h2>Document Sent Successfully!</h2>
                <p class="lead">Your document has been sent to <strong><?php echo htmlspecialchars($recipient_email); ?></strong> for signing.</p>
                <div class="mt-4">
                    <a href="../dashboard/documents.php" class="btn btn-primary me-2">View All Documents</a>
                    <a href="send.php?id=<?php echo $document_id; ?>" class="btn btn-outline-primary">Send to Another Recipient</a>
                </div>
            </div>
        </div>
    <?php else: ?>
        <?php if (!empty($send_err)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $send_err; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Recipient Information</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $document_id); ?>" method="post">
                            <div class="mb-3">
                                <label for="recipient_email" class="form-label">Recipient Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="recipient_email" name="recipient_email" value="<?php echo htmlspecialchars($recipient_email); ?>" required>
                                <div class="form-text">Enter the email address of the person who needs to sign this document.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="recipient_name" class="form-label">Recipient Name</label>
                                <input type="text" class="form-control" id="recipient_name" name="recipient_name" value="<?php echo htmlspecialchars($recipient_name); ?>">
                                <div class="form-text">Enter the name of the recipient (optional).</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="message" class="form-label">Message (Optional)</label>
                                <textarea class="form-control" id="message" name="message" rows="4"><?php echo htmlspecialchars($message); ?></textarea>
                                <div class="form-text">Add a personal message to include in the email.</div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i> Send Document
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Document Details</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <strong>Title:</strong> <?php echo htmlspecialchars($document['title']); ?>
                            </li>
                            <li class="list-group-item">
                                <strong>Filename:</strong> <?php echo htmlspecialchars($document['filename']); ?>
                            </li>
                            <li class="list-group-item">
                                <strong>Status:</strong>
                                <span class="badge bg-<?php echo getDocumentStatusClass($document['status']); ?>">
                                    <?php echo getDocumentStatus($document['status']); ?>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Email Preview</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Subject:</strong> Document for Signature: <?php echo htmlspecialchars($document['title']); ?></p>
                        <hr>
                        <p>Hello [Recipient],</p>
                        <p><?php echo htmlspecialchars($_SESSION['name']); ?> has sent you a document to sign using <?php echo APP_NAME; ?>.</p>
                        <p><strong>Message:</strong> [Your message will appear here]</p>
                        <p>Please click on the link below to view and sign the document:</p>
                        <p><a href="#"><?php echo htmlspecialchars($document['title']); ?></a></p>
                        <p>Thank you,<br><?php echo htmlspecialchars($_SESSION['name']); ?></p>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php
// Include footer
require_once '../includes/footer.php';
?>
