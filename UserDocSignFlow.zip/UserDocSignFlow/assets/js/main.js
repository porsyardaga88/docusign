/**
 * Main JavaScript for DocuSign Management System
 */

document.addEventListener('DOMContentLoaded', function() {
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Toggle password visibility
    var togglePasswordButtons = document.querySelectorAll('.toggle-password');
    togglePasswordButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            var passwordInput = document.querySelector(this.getAttribute('data-target'));
            var icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // Confirm delete for the "Delete Account" functionality
    var confirmDeleteInput = document.getElementById('confirmDelete');
    var confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    
    if (confirmDeleteInput && confirmDeleteBtn) {
        confirmDeleteInput.addEventListener('input', function() {
            if (this.value.toUpperCase() === 'DELETE') {
                confirmDeleteBtn.removeAttribute('disabled');
            } else {
                confirmDeleteBtn.setAttribute('disabled', 'disabled');
            }
        });
    }
    
    // File input preview (show filename)
    var fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(function(input) {
        input.addEventListener('change', function() {
            var fileName = this.files[0]?.name;
            var fileLabel = document.querySelector('label[for="' + this.id + '"]');
            
            if (fileLabel && fileName) {
                var smallElement = fileLabel.querySelector('small');
                
                if (!smallElement) {
                    smallElement = document.createElement('small');
                    smallElement.classList.add('d-block', 'mt-1', 'text-truncate');
                    fileLabel.appendChild(smallElement);
                }
                
                smallElement.textContent = fileName;
            }
        });
    });
    
    // Change password form validation
    var changePasswordForm = document.getElementById('changePasswordForm');
    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', function(e) {
            var currentPassword = document.getElementById('current_password').value;
            var newPassword = document.getElementById('new_password').value;
            var confirmPassword = document.getElementById('confirm_password').value;
            var isValid = true;
            
            // Clear previous error messages
            document.querySelectorAll('.invalid-feedback').forEach(function(el) {
                el.remove();
            });
            document.querySelectorAll('.is-invalid').forEach(function(el) {
                el.classList.remove('is-invalid');
            });
            
            // Validate current password
            if (!currentPassword) {
                isValid = false;
                addError('current_password', 'Please enter your current password');
            }
            
            // Validate new password
            if (!newPassword) {
                isValid = false;
                addError('new_password', 'Please enter a new password');
            } else if (newPassword.length < 6) {
                isValid = false;
                addError('new_password', 'Password must be at least 6 characters');
            }
            
            // Validate confirm password
            if (!confirmPassword) {
                isValid = false;
                addError('confirm_password', 'Please confirm your new password');
            } else if (newPassword !== confirmPassword) {
                isValid = false;
                addError('confirm_password', 'Passwords do not match');
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // Helper function to add error message
    function addError(inputId, errorMessage) {
        var input = document.getElementById(inputId);
        input.classList.add('is-invalid');
        
        var errorDiv = document.createElement('div');
        errorDiv.classList.add('invalid-feedback');
        errorDiv.textContent = errorMessage;
        
        input.parentNode.appendChild(errorDiv);
    }
    
    // Email template form handling
    var emailTemplateForm = document.getElementById('emailTemplateForm');
    if (emailTemplateForm) {
        emailTemplateForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simulate saving templates
            var submitButton = this.querySelector('button[type="submit"]');
            var originalText = submitButton.innerHTML;
            
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
            submitButton.disabled = true;
            
            setTimeout(function() {
                // Create alert to show success
                var alert = document.createElement('div');
                alert.classList.add('alert', 'alert-success', 'alert-dismissible', 'fade', 'show');
                alert.innerHTML = 'Email templates saved successfully! <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                
                // Insert alert before the form
                emailTemplateForm.parentNode.insertBefore(alert, emailTemplateForm);
                
                // Reset button
                submitButton.innerHTML = originalText;
                submitButton.disabled = false;
                
                // Auto-hide alert after 5 seconds
                setTimeout(function() {
                    var bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 5000);
            }, 1500);
        });
    }
});
