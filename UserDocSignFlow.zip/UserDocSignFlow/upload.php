<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Require login to access this page
requireLogin();

// Initialize variables
$message = '';
$messageType = '';

include 'includes/header.php';
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-md-3">
        <?php include 'includes/sidebar.php'; ?>
    </div>
    
    <!-- Main content -->
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">Upload Document</h1>
        </div>
        
        <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Upload New Document</h5>
                    </div>
                    <div class="card-body">
                        <form action="/process/upload_process.php" method="post" enctype="multipart/form-data" id="upload-form">
                            <div class="form-group">
                                <label for="document">Select PDF Document</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="document" name="document" accept=".pdf" required>
                                    <label class="custom-file-label" for="document">Choose file...</label>
                                </div>
                                <small class="form-text text-muted">Only PDF files are supported. Maximum file size: 10MB</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Document Description (Optional)</label>
                                <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter a description for this document"></textarea>
                            </div>
                            
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="send_now" name="send_now">
                                    <label class="custom-control-label" for="send_now">Send for signature immediately</label>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-upload"></i> Upload Document
                            </button>
                        </form>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Upload Tips</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <i class="fas fa-check-circle text-success mr-2"></i> Ensure your PDF document is correctly formatted
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-check-circle text-success mr-2"></i> Make sure the document is not password protected
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-check-circle text-success mr-2"></i> Check that all pages are properly oriented
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-check-circle text-success mr-2"></i> Verify that the PDF file size is under 10MB
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Document Workflow</h5>
                    </div>
                    <div class="card-body">
                        <div class="workflow-steps">
                            <div class="workflow-step">
                                <div class="workflow-step-icon bg-primary">
                                    <i class="fas fa-upload"></i>
                                </div>
                                <div class="workflow-step-content">
                                    <h6>Upload</h6>
                                    <p class="small text-muted">Upload your PDF document</p>
                                </div>
                            </div>
                            <div class="workflow-step">
                                <div class="workflow-step-icon bg-info">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="workflow-step-content">
                                    <h6>Send</h6>
                                    <p class="small text-muted">Send to recipients for signature</p>
                                </div>
                            </div>
                            <div class="workflow-step">
                                <div class="workflow-step-icon bg-warning">
                                    <i class="fas fa-signature"></i>
                                </div>
                                <div class="workflow-step-content">
                                    <h6>Sign</h6>
                                    <p class="small text-muted">Recipients sign the document</p>
                                </div>
                            </div>
                            <div class="workflow-step">
                                <div class="workflow-step-icon bg-success">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="workflow-step-content">
                                    <h6>Complete</h6>
                                    <p class="small text-muted">Document is completed and stored</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40" class="card-img-top" alt="Document signing">
                    <div class="card-body">
                        <h5 class="card-title">Need help?</h5>
                        <p class="card-text">Check out our guide on how to prepare documents for digital signatures.</p>
                        <a href="#" class="btn btn-outline-primary btn-sm">View Guide</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Update file input label with selected filename
    document.querySelector('.custom-file-input').addEventListener('change', function(e) {
        const fileName = e.target.files[0].name;
        const label = e.target.nextElementSibling;
        label.textContent = fileName;
    });
    
    // Show loading state on form submit
    document.getElementById('upload-form').addEventListener('submit', function() {
        const submitButton = this.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
    });
});
</script>

<?php include 'includes/footer.php'; ?>
