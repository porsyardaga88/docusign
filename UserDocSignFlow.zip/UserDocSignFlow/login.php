<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// If user is already logged in, redirect to dashboard
if (isLoggedIn()) {
    redirect("/dashboard.php");
}

$username = $password = "";
$error = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty($_POST["username"])) {
        $error = "Username is required";
    } else {
        $username = clean($_POST["username"]);
    }
    
    // Validate password
    if (empty($_POST["password"])) {
        $error = "Password is required";
    } else {
        $password = $_POST["password"];
    }
    
    // If no errors, attempt login
    if (empty($error)) {
        $user = $db->getRow("SELECT * FROM users WHERE username = ? OR email = ?", [$username, $username]);
        
        if ($user && verifyPassword($password, $user["password"])) {
            // Set session variables
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            
            // Redirect to dashboard
            redirect("/dashboard.php");
        } else {
            $error = "Invalid username or password";
        }
    }
}

include 'includes/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fas fa-sign-in-alt"></i> Login</h4>
            </div>
            <div class="card-body">
                <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="form-group">
                        <label for="username">Username or Email</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter username or email" value="<?php echo htmlspecialchars($username); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            </div>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                        </div>
                    </div>
                    
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="remember">
                        <label class="form-check-label" for="remember">Remember me</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
                
                <hr>
                
                <div class="text-center">
                    <p class="mb-0">Don't have an account? <a href="/register.php">Register here</a></p>
                </div>
                
                <div class="alert alert-info mt-3" role="alert">
                    <strong>Demo Account:</strong> Username: demo | Password: demo123
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
