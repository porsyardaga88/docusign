<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Require login to access this page
requireLogin();

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    redirect("/documents.php");
}

// Get user ID and document ID
$userId = $_SESSION['user_id'];
$documentId = isset($_POST['document_id']) ? (int)$_POST['document_id'] : 0;

// Check if document exists and belongs to the current user
$document = getUserDocument($documentId, $userId);

if (!$document) {
    $_SESSION['send_error'] = 'Document not found or access denied.';
    redirect("/documents.php");
}

// Check if document is already sent
if ($document['status'] != 'draft') {
    $_SESSION['send_error'] = 'This document has already been sent.';
    redirect("/documents.php");
}

// Get form data
$emailSubject = isset($_POST['email_subject']) ? clean($_POST['email_subject']) : '';
$emailMessage = isset($_POST['email_message']) ? $_POST['email_message'] : '';
$sendCopy = isset($_POST['send_copy']) && $_POST['send_copy'] ? true : false;
$recipients = isset($_POST['recipients']) ? $_POST['recipients'] : [];

// Validate form data
if (empty($emailSubject) || empty($emailMessage) || empty($recipients)) {
    $_SESSION['send_error'] = 'Please fill in all required fields.';
    redirect("/send_document.php?id=" . $documentId);
}

// Update document status to 'sent'
$db->query(
    "UPDATE documents SET status = 'sent', updated_at = CURRENT_TIMESTAMP WHERE id = ?",
    [$documentId]
);

// Get current user data for email
$user = getCurrentUser();

// Process recipients
foreach ($recipients as $recipient) {
    // Validate recipient data
    if (empty($recipient['name']) || empty($recipient['email'])) {
        continue;
    }
    
    $name = clean($recipient['name']);
    $email = clean($recipient['email']);
    
    // Generate token for the signing link
    $token = generateToken();
    
    // Generate sign URL
    $signUrl = BASE_URL . "/sign_document.php?token=" . $token;
    
    // Insert recipient record
    $recipientId = $db->insert(
        "INSERT INTO recipients (document_id, name, email, status, token, sign_url) VALUES (?, ?, ?, ?, ?, ?)",
        [$documentId, $name, $email, 'pending', $token, $signUrl]
    );
    
    if ($recipientId) {
        // Send email to recipient
        $emailHtml = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #4e73df; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background-color: #f8f9fc; }
                .button { display: inline-block; background-color: #4e73df; color: white; padding: 12px 24px; 
                          text-decoration: none; border-radius: 4px; margin-top: 20px; margin-bottom: 20px; }
                .footer { font-size: 12px; color: #777; padding-top: 20px; text-align: center; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Document Signing Request</h2>
                </div>
                <div class="content">
                    <p>Hello ' . htmlspecialchars($name) . ',</p>
                    <p>' . nl2br(htmlspecialchars($emailMessage)) . '</p>
                    <p><strong>Document:</strong> ' . htmlspecialchars($document['original_filename']) . '</p>
                    <p><strong>From:</strong> ' . htmlspecialchars($user['full_name']) . ' (' . htmlspecialchars($user['email']) . ')</p>
                    <div style="text-align: center;">
                        <a href="' . $signUrl . '" class="button">Review and Sign Document</a>
                    </div>
                    <p>If the button above doesn\'t work, you can copy and paste the following link into your browser:</p>
                    <p>' . $signUrl . '</p>
                </div>
                <div class="footer">
                    <p>This is an automated message, please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        ';
        
        sendEmail($email, $emailSubject, $emailHtml);
    }
}

// Send a copy to the sender if requested
if ($sendCopy) {
    $emailHtml = '
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #4e73df; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background-color: #f8f9fc; }
            .recipients { margin-top: 20px; }
            .recipient { padding: 10px; border-bottom: 1px solid #eee; }
            .footer { font-size: 12px; color: #777; padding-top: 20px; text-align: center; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Document Sent for Signature</h2>
            </div>
            <div class="content">
                <p>Hello ' . htmlspecialchars($user['full_name']) . ',</p>
                <p>You have sent the document <strong>' . htmlspecialchars($document['original_filename']) . '</strong> for signature.</p>
                <p>Your message to recipients:</p>
                <blockquote>' . nl2br(htmlspecialchars($emailMessage)) . '</blockquote>
                <div class="recipients">
                    <h3>Recipients:</h3>';
    
    foreach ($recipients as $recipient) {
        if (!empty($recipient['name']) && !empty($recipient['email'])) {
            $emailHtml .= '
                    <div class="recipient">
                        <strong>' . htmlspecialchars($recipient['name']) . '</strong><br>
                        <span>' . htmlspecialchars($recipient['email']) . '</span>
                    </div>';
        }
    }
    
    $emailHtml .= '
                </div>
                <p>You can track the signing status from your dashboard.</p>
            </div>
            <div class="footer">
                <p>This is an automated message, please do not reply to this email.</p>
            </div>
        </div>
    </body>
    </html>
    ';
    
    sendEmail($user['email'], 'You sent: ' . $emailSubject, $emailHtml);
}

// Set success message and redirect
$_SESSION['send_success'] = 'Document sent successfully to ' . count($recipients) . ' recipient(s).';
redirect("/documents.php");
?>
