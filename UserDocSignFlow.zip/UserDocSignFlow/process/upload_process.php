<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Require login to access this page
requireLogin();

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    redirect("/upload.php");
}

// Get user ID
$userId = $_SESSION['user_id'];

// Initialize response
$response = [
    'success' => false,
    'message' => '',
    'redirect' => ''
];

// Validate file upload
if (!isset($_FILES['document']) || $_FILES['document']['error'] !== UPLOAD_ERR_OK) {
    $errorMessage = 'File upload failed: ';
    
    switch ($_FILES['document']['error']) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            $errorMessage .= 'The uploaded file exceeds the maximum file size limit.';
            break;
        case UPLOAD_ERR_PARTIAL:
            $errorMessage .= 'The file was only partially uploaded.';
            break;
        case UPLOAD_ERR_NO_FILE:
            $errorMessage .= 'No file was uploaded.';
            break;
        case UPLOAD_ERR_NO_TMP_DIR:
            $errorMessage .= 'Missing a temporary folder.';
            break;
        case UPLOAD_ERR_CANT_WRITE:
            $errorMessage .= 'Failed to write file to disk.';
            break;
        case UPLOAD_ERR_EXTENSION:
            $errorMessage .= 'A PHP extension stopped the file upload.';
            break;
        default:
            $errorMessage .= 'Unknown error occurred.';
    }
    
    $_SESSION['upload_error'] = $errorMessage;
    redirect("/upload.php");
}

// Check file type
$finfo = new finfo(FILEINFO_MIME_TYPE);
$fileType = $finfo->file($_FILES['document']['tmp_name']);

if ($fileType !== 'application/pdf') {
    $_SESSION['upload_error'] = 'Only PDF files are allowed.';
    redirect("/upload.php");
}

// Check file size (10MB limit)
$maxFileSize = 10 * 1024 * 1024; // 10MB in bytes
if ($_FILES['document']['size'] > $maxFileSize) {
    $_SESSION['upload_error'] = 'File size exceeds the maximum limit of 10MB.';
    redirect("/upload.php");
}

// Generate a unique filename
$originalFilename = $_FILES['document']['name'];
$fileExtension = pathinfo($originalFilename, PATHINFO_EXTENSION);
$newFilename = uniqid() . '.' . $fileExtension;

// Create upload directory if it doesn't exist
$uploadDir = UPLOAD_DIR . $userId . '/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$filePath = $uploadDir . $newFilename;
$relativePath = str_replace(__DIR__ . '/../', '/', $filePath);

// Move the uploaded file
if (!move_uploaded_file($_FILES['document']['tmp_name'], $filePath)) {
    $_SESSION['upload_error'] = 'Failed to save the uploaded file.';
    redirect("/upload.php");
}

// Get additional form data
$description = isset($_POST['description']) ? clean($_POST['description']) : '';
$sendNow = isset($_POST['send_now']) && $_POST['send_now'] ? true : false;

// Insert document record into database
$documentId = $db->insert(
    "INSERT INTO documents (user_id, filename, original_filename, file_path, file_size, description, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
    [$userId, $newFilename, $originalFilename, $relativePath, $_FILES['document']['size'], $description, 'draft']
);

if (!$documentId) {
    // Delete the uploaded file if database insert fails
    unlink($filePath);
    
    $_SESSION['upload_error'] = 'Failed to save document information to database.';
    redirect("/upload.php");
}

// Set success message
$_SESSION['upload_success'] = 'Document uploaded successfully.';

// Redirect based on send_now option
if ($sendNow) {
    redirect("/send_document.php?id=" . $documentId);
} else {
    redirect("/documents.php");
}
?>
