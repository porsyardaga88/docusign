<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Require login to access this page
requireLogin();

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    redirect("/settings.php");
}

// Get user ID
$userId = $_SESSION['user_id'];

// Get form data
$emailNotifications = isset($_POST['email_notifications']) ? 1 : 0;
$signatureData = isset($_POST['signature_data']) ? $_POST['signature_data'] : null;

// Get user settings
$settings = $db->getRow("SELECT * FROM settings WHERE user_id = ?", [$userId]);

if ($settings) {
    // Update existing settings
    $db->query(
        "UPDATE settings SET email_notifications = ?, signature_image = ? WHERE user_id = ?",
        [$emailNotifications, $signatureData, $userId]
    );
} else {
    // Create new settings
    $db->insert(
        "INSERT INTO settings (user_id, email_notifications, signature_image) VALUES (?, ?, ?)",
        [$userId, $emailNotifications, $signatureData]
    );
}

// Set success message and redirect
$_SESSION['settings_success'] = 'Settings updated successfully.';
redirect("/settings.php");
?>
