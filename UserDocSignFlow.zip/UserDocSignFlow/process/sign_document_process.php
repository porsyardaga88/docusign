<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    redirect("/");
}

// Get form data
$token = isset($_POST['token']) ? clean($_POST['token']) : '';
$signatureData = isset($_POST['signature_data']) ? $_POST['signature_data'] : '';
$signatureX = isset($_POST['signature_x']) ? (int)$_POST['signature_x'] : 0;
$signatureY = isset($_POST['signature_y']) ? (int)$_POST['signature_y'] : 0;
$signaturePage = isset($_POST['signature_page']) ? (int)$_POST['signature_page'] : 1;

// Validate form data
if (empty($token) || empty($signatureData)) {
    $_SESSION['sign_error'] = 'Invalid signature data.';
    redirect("/sign_document.php?token=" . $token);
}

// Check if token is valid
$recipient = getRecipientByToken($token);

if (!$recipient) {
    $_SESSION['sign_error'] = 'Invalid or expired token.';
    redirect("/");
}

// Get document data
$documentId = $recipient['document_id'];
$document = getDocument($documentId);

if (!$document) {
    $_SESSION['sign_error'] = 'Document not found.';
    redirect("/");
}

// Check if document is already signed by this recipient
if ($recipient['status'] === 'signed') {
    $_SESSION['sign_error'] = 'You have already signed this document.';
    redirect("/verify_signature.php?token=" . $token);
}

try {
    // Start transaction
    $db->query("START TRANSACTION");
    
    // Insert signature record
    $signatureId = $db->insert(
        "INSERT INTO signatures (recipient_id, document_id, signature_data, x_coordinate, y_coordinate, page_number) VALUES (?, ?, ?, ?, ?, ?)",
        [$recipient['id'], $documentId, $signatureData, $signatureX, $signatureY, $signaturePage]
    );
    
    if (!$signatureId) {
        throw new Exception('Failed to save signature data.');
    }
    
    // Update recipient status to 'signed'
    $db->query(
        "UPDATE recipients SET status = 'signed', signed_at = CURRENT_TIMESTAMP WHERE id = ?",
        [$recipient['id']]
    );
    
    // Check if all recipients have signed
    $allSigned = $db->getValue(
        "SELECT COUNT(*) = 0 FROM recipients WHERE document_id = ? AND status != 'signed'",
        [$documentId]
    );
    
    // Update document status if all recipients have signed
    if ($allSigned) {
        $db->query(
            "UPDATE documents SET status = 'completed', updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            [$documentId]
        );
    } else {
        $db->query(
            "UPDATE documents SET status = 'signed', updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            [$documentId]
        );
    }
    
    // Get document owner (creator) information for email notification
    $documentOwner = $db->getRow(
        "SELECT u.* FROM users u JOIN documents d ON u.id = d.user_id WHERE d.id = ?",
        [$documentId]
    );
    
    // Commit transaction
    $db->query("COMMIT");
    
    // Send email notification to document owner
    if ($documentOwner) {
        $emailHtml = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #4e73df; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background-color: #f8f9fc; }
                .button { display: inline-block; background-color: #4e73df; color: white; padding: 12px 24px; 
                          text-decoration: none; border-radius: 4px; margin-top: 20px; margin-bottom: 20px; }
                .signature-info { background-color: #e8f4fd; padding: 15px; border-radius: 4px; margin-top: 15px; }
                .footer { font-size: 12px; color: #777; padding-top: 20px; text-align: center; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Document Signed</h2>
                </div>
                <div class="content">
                    <p>Hello ' . htmlspecialchars($documentOwner['full_name']) . ',</p>
                    <p><strong>' . htmlspecialchars($recipient['name']) . '</strong> has signed your document <strong>' . htmlspecialchars($document['original_filename']) . '</strong>.</p>
                    <div class="signature-info">
                        <h3>Signature Details:</h3>
                        <p><strong>Signer:</strong> ' . htmlspecialchars($recipient['name']) . ' (' . htmlspecialchars($recipient['email']) . ')</p>
                        <p><strong>Signed on:</strong> ' . date('F j, Y, g:i a') . '</p>
                        <p><strong>IP Address:</strong> ' . $_SERVER['REMOTE_ADDR'] . '</p>
                    </div>
                    <div style="text-align: center;">
                        <a href="' . BASE_URL . '/view_document.php?id=' . $documentId . '" class="button">View Document</a>
                    </div>
                </div>
                <div class="footer">
                    <p>This is an automated message, please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        ';
        
        sendEmail($documentOwner['email'], 'Document Signed: ' . $document['original_filename'], $emailHtml);
    }
    
    // Redirect to verification page
    redirect("/verify_signature.php?token=" . $token);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $db->query("ROLLBACK");
    
    $_SESSION['sign_error'] = 'An error occurred: ' . $e->getMessage();
    redirect("/sign_document.php?token=" . $token);
}
?>
