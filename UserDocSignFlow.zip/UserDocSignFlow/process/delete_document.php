<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Require login to access this page
requireLogin();

// Get document ID from URL
$documentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Check if document exists and belongs to the current user
$userId = $_SESSION['user_id'];
$document = getUserDocument($documentId, $userId);

if (!$document) {
    $_SESSION['document_error'] = 'Document not found or access denied.';
    redirect("/documents.php");
}

try {
    // Start transaction
    $db->query("START TRANSACTION");
    
    // Delete signatures related to the document
    $db->query("DELETE FROM signatures WHERE document_id = ?", [$documentId]);
    
    // Delete recipients related to the document
    $db->query("DELETE FROM recipients WHERE document_id = ?", [$documentId]);
    
    // Delete the document record
    $db->query("DELETE FROM documents WHERE id = ?", [$documentId]);
    
    // Delete the physical file from the server
    $filePath = __DIR__ . '/../' . $document['file_path'];
    if (file_exists($filePath)) {
        unlink($filePath);
    }
    
    // Commit transaction
    $db->query("COMMIT");
    
    // Set success message
    $_SESSION['document_success'] = 'Document deleted successfully.';
    
} catch (Exception $e) {
    // Rollback transaction on error
    $db->query("ROLLBACK");
    
    // Set error message
    $_SESSION['document_error'] = 'Failed to delete document: ' . $e->getMessage();
}

// Redirect back to documents page
redirect("/documents.php");
?>
