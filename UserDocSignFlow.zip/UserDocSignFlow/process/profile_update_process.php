<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Require login to access this page
requireLogin();

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    redirect("/profile.php");
}

// Get user ID
$userId = $_SESSION['user_id'];

// Get form data
$fullName = isset($_POST['full_name']) ? clean($_POST['full_name']) : '';
$email = isset($_POST['email']) ? clean($_POST['email']) : '';
$position = isset($_POST['position']) ? clean($_POST['position']) : '';
$company = isset($_POST['company']) ? clean($_POST['company']) : '';

// Validate form data
if (empty($fullName) || empty($email)) {
    $_SESSION['profile_error'] = 'Full name and email are required.';
    redirect("/profile.php");
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['profile_error'] = 'Please enter a valid email address.';
    redirect("/profile.php");
}

// Check if email already exists for another user
$existingUser = $db->getRow("SELECT * FROM users WHERE email = ? AND id != ?", [$email, $userId]);
if ($existingUser) {
    $_SESSION['profile_error'] = 'This email is already in use by another account.';
    redirect("/profile.php");
}

// Update user profile
$db->query(
    "UPDATE users SET full_name = ?, email = ?, position = ?, company = ? WHERE id = ?",
    [$fullName, $email, $position, $company, $userId]
);

// Set success message and redirect
$_SESSION['profile_success'] = 'Profile updated successfully.';
redirect("/profile.php");
?>
