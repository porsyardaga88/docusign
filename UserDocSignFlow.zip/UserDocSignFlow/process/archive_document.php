<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Require login to access this page
requireLogin();

// Get document ID from URL
$documentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Check if document exists and belongs to the current user
$userId = $_SESSION['user_id'];
$document = getUserDocument($documentId, $userId);

if (!$document) {
    $_SESSION['document_error'] = 'Document not found or access denied.';
    redirect("/documents.php");
}

// Update document status to 'archived'
$db->query(
    "UPDATE documents SET status = 'archived', updated_at = CURRENT_TIMESTAMP WHERE id = ?",
    [$documentId]
);

// Set success message
$_SESSION['document_success'] = 'Document archived successfully.';

// Redirect back to documents page
redirect("/documents.php");
?>
