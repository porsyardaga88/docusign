<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db.php';

// Get token from URL
$token = isset($_GET['token']) ? clean($_GET['token']) : '';

// Check if token is valid
$recipient = getRecipientByToken($token);

if (!$recipient) {
    // Invalid token, show error page
    http_response_code(404);
    include 'includes/header.php';
    echo '<div class="container mt-5">
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <h4 class="mb-0">Invalid Link</h4>
            </div>
            <div class="card-body text-center py-5">
                <i class="fas fa-exclamation-triangle fa-4x text-danger mb-3"></i>
                <h5>This verification link is invalid or has expired</h5>
                <p class="text-muted">Please contact the sender for a new link.</p>
            </div>
        </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

// Get document data
$documentId = $recipient['document_id'];
$document = getDocument($documentId);

if (!$document) {
    // Document not found
    http_response_code(404);
    include 'includes/header.php';
    echo '<div class="container mt-5">
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <h4 class="mb-0">Document Not Found</h4>
            </div>
            <div class="card-body text-center py-5">
                <i class="fas fa-file-excel fa-4x text-danger mb-3"></i>
                <h5>The requested document could not be found</h5>
                <p class="text-muted">The document may have been deleted. Please contact the sender.</p>
            </div>
        </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

// Get signature data
$signature = $db->getRow(
    "SELECT * FROM signatures WHERE recipient_id = ? AND document_id = ?",
    [$recipient['id'], $documentId]
);

include 'includes/header.php';
?>

<div class="container mt-4">
    <?php if ($recipient['status'] === 'signed' && $signature): ?>
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card mb-4 border-success">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0"><i class="fas fa-check-circle"></i> Document Successfully Signed</h4>
                </div>
                <div class="card-body text-center">
                    <div class="mb-4">
                        <i class="fas fa-file-signature fa-4x text-success mb-3"></i>
                        <h5>Thank you for signing the document</h5>
                        <p>The document has been successfully signed and the sender has been notified.</p>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 offset-md-3">
                            <div class="card mb-3">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0">Signature Information</h5>
                                </div>
                                <div class="card-body">
                                    <table class="table table-sm table-bordered">
                                        <tr>
                                            <th width="150">Document:</th>
                                            <td><?php echo htmlspecialchars($document['original_filename']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Signed By:</th>
                                            <td><?php echo htmlspecialchars($recipient['name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Email:</th>
                                            <td><?php echo htmlspecialchars($recipient['email']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Signed On:</th>
                                            <td><?php echo formatDate($recipient['signed_at']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>IP Address:</th>
                                            <td><?php echo htmlspecialchars($_SERVER['REMOTE_ADDR']); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <a href="<?php echo $recipient['sign_url']; ?>&download=1" class="btn btn-primary">
                            <i class="fas fa-download"></i> Download Signed Document
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Document Preview</h5>
                    <div class="document-navigation">
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="prev">
                            <i class="fas fa-chevron-left"></i> Previous
                        </button>
                        <span id="page_num"></span> / <span id="page_count"></span>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="next">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="document-container">
                        <canvas id="pdf-renderer"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card border-warning">
                <div class="card-header bg-warning">
                    <h4 class="mb-0"><i class="fas fa-exclamation-triangle"></i> Document Not Yet Signed</h4>
                </div>
                <div class="card-body text-center py-5">
                    <div class="mb-4">
                        <i class="fas fa-signature fa-4x text-warning mb-3"></i>
                        <h5>This document has not been signed yet</h5>
                        <p>You need to sign the document to complete the process.</p>
                    </div>
                    
                    <a href="/sign_document.php?token=<?php echo $token; ?>" class="btn btn-primary btn-lg">
                        <i class="fas fa-pen-fancy"></i> Sign Document Now
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php if ($recipient['status'] === 'signed' && $signature): ?>
<script>
// Initialize variables
let pdfDoc = null;
let pageNum = 1;
let pageRendering = false;
let pageNumPending = null;
let scale = 1.0;
let canvas = document.getElementById('pdf-renderer');
let ctx = canvas.getContext('2d');

// PDF.js initialization
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.6.347/pdf.worker.min.js';

// Load PDF document
function loadPdf() {
    const url = '<?php echo BASE_URL . $document['file_path']; ?>';
    
    pdfjsLib.getDocument(url).promise.then(function(pdf) {
        pdfDoc = pdf;
        document.getElementById('page_count').textContent = pdf.numPages;
        
        // Initial render
        renderPage(pageNum);
        
        // Go to signature page
        const signaturePage = <?php echo $signature['page_number']; ?>;
        if (signaturePage > 0 && signaturePage <= pdf.numPages) {
            pageNum = signaturePage;
            renderPage(pageNum);
        }
    });
}

// Render specific page
function renderPage(num) {
    pageRendering = true;
    
    // Get page
    pdfDoc.getPage(num).then(function(page) {
        const viewport = page.getViewport({scale: scale});
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        // Render PDF page
        const renderContext = {
            canvasContext: ctx,
            viewport: viewport
        };
        
        const renderTask = page.render(renderContext);
        
        renderTask.promise.then(function() {
            pageRendering = false;
            
            if (pageNumPending !== null) {
                renderPage(pageNumPending);
                pageNumPending = null;
            }
            
            // Draw signature if on the correct page
            if (num === <?php echo $signature['page_number']; ?>) {
                drawSignature();
            }
        });
    });
    
    // Update page number
    document.getElementById('page_num').textContent = num;
}

// Draw the signature on the canvas
function drawSignature() {
    const signatureData = "<?php echo $signature['signature_data']; ?>";
    const x = <?php echo $signature['x_coordinate']; ?>;
    const y = <?php echo $signature['y_coordinate']; ?>;
    
    const img = new Image();
    img.onload = function() {
        ctx.drawImage(img, x, y, 200, 100);
    };
    img.src = signatureData;
}

// Queue page rendering when previous rendering is not finished
function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

// Previous page
function previousPage() {
    if (pageNum <= 1) {
        return;
    }
    pageNum--;
    queueRenderPage(pageNum);
}

// Next page
function nextPage() {
    if (pageNum >= pdfDoc.numPages) {
        return;
    }
    pageNum++;
    queueRenderPage(pageNum);
}

// Register navigation buttons
document.getElementById('prev').addEventListener('click', previousPage);
document.getElementById('next').addEventListener('click', nextPage);

// Initialize after page load
document.addEventListener('DOMContentLoaded', function() {
    loadPdf();
});
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
