<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Get admin data
$adminId = $_SESSION['admin_id'];
$admin = $db->getRow("SELECT * FROM admins WHERE id = ?", [$adminId]);

// Process user actions
$message = '';
$messageType = '';

// Handle user delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $userId = $_GET['delete'];
    
    // Get user info for logging
    $user = $db->getRow("SELECT * FROM users WHERE id = ?", [$userId]);
    
    if ($user) {
        // Delete user (in a real system, you might want to soft delete or have a more complex deletion process)
        $db->query("DELETE FROM users WHERE id = ?", [$userId]);
        
        // Log the action
        $db->insert(
            "INSERT INTO admin_logs (admin_id, action, action_description, ip_address) VALUES (?, ?, ?, ?)",
            [
                $adminId, 
                'delete', 
                "Deleted user: {$user['username']} (ID: {$userId})", 
                $_SERVER['REMOTE_ADDR']
            ]
        );
        
        $message = "User {$user['username']} has been deleted successfully.";
        $messageType = 'success';
    } else {
        $message = "User not found.";
        $messageType = 'danger';
    }
}

// Handle user status change
if (isset($_GET['status']) && is_numeric($_GET['user'])) {
    $userId = $_GET['user'];
    $status = $_GET['status'] === 'active' ? 'active' : 'inactive';
    
    // Get user info for logging
    $user = $db->getRow("SELECT * FROM users WHERE id = ?", [$userId]);
    
    if ($user) {
        // Update user status
        $db->query("UPDATE users SET status = ? WHERE id = ?", [$status, $userId]);
        
        // Log the action
        $db->insert(
            "INSERT INTO admin_logs (admin_id, action, action_description, ip_address) VALUES (?, ?, ?, ?)",
            [
                $adminId, 
                'update', 
                "Changed status of user {$user['username']} (ID: {$userId}) to {$status}", 
                $_SERVER['REMOTE_ADDR']
            ]
        );
        
        $message = "User {$user['username']} status has been updated to {$status}.";
        $messageType = 'success';
    } else {
        $message = "User not found.";
        $messageType = 'danger';
    }
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Search functionality
$search = isset($_GET['search']) ? clean($_GET['search']) : '';
$searchWhere = '';
$searchParams = [];

if (!empty($search)) {
    $searchWhere = "WHERE username LIKE ? OR email LIKE ? OR full_name LIKE ?";
    $searchPattern = "%{$search}%";
    $searchParams = [$searchPattern, $searchPattern, $searchPattern];
}

// Get total user count for pagination
$totalUsers = $db->getValue("SELECT COUNT(*) FROM users {$searchWhere}", $searchParams);
$totalPages = ceil($totalUsers / $perPage);

// Get users with pagination and search
$users = $db->getRows(
    "SELECT * FROM users {$searchWhere} ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}",
    $searchParams
);

// Add encryption and decryption functionality (simplified for demo)
function encryptUserData($data) {
    global $db;
    
    // Check if encryption is enabled in settings
    $encryptionEnabled = $db->getValue(
        "SELECT setting_value FROM security_settings WHERE setting_name = 'encrypt_user_data'"
    );
    
    if ($encryptionEnabled !== 'true') {
        return $data;
    }
    
    // Get active key
    $key = $db->getRow("SELECT * FROM encryption_keys WHERE active = true ORDER BY created_at DESC LIMIT 1");
    
    if (!$key) {
        return $data;
    }
    
    // In a real system, use a robust encryption method
    $iv = random_bytes(16); // Generate initialization vector
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', hex2bin($key['key_value']), 0, $iv);
    
    if ($encrypted === false) {
        return $data;
    }
    
    // Return combined IV and encrypted data
    return base64_encode($iv) . '|' . $encrypted;
}

function decryptUserData($encryptedData) {
    if (strpos($encryptedData, '|') === false) {
        return $encryptedData; // Not encrypted
    }
    
    global $db;
    
    // Get active key
    $key = $db->getRow("SELECT * FROM encryption_keys WHERE active = true ORDER BY created_at DESC LIMIT 1");
    
    if (!$key) {
        return $encryptedData;
    }
    
    list($iv, $data) = explode('|', $encryptedData, 2);
    
    $iv = base64_decode($iv);
    
    // Attempt decryption
    $decrypted = openssl_decrypt($data, 'aes-256-cbc', hex2bin($key['key_value']), 0, $iv);
    
    if ($decrypted === false) {
        return $encryptedData;
    }
    
    return $decrypted;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Dashboard</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: #fff;
            position: sticky;
            top: 0;
        }
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: calc(100vh - 48px);
            padding-top: .5rem;
            overflow-x: hidden;
            overflow-y: auto;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
            padding: .75rem 1rem;
        }
        .sidebar .nav-link:hover {
            color: #fff;
        }
        .sidebar .nav-link.active {
            color: #fff;
            background-color: rgba(0, 0, 0, 0.25);
        }
        .sidebar .nav-link i {
            margin-right: .5rem;
            width: 20px;
            text-align: center;
        }
        .sidebar-heading {
            font-size: .75rem;
            text-transform: uppercase;
            padding: 1rem;
            color: rgba(255, 255, 255, 0.5);
        }
        .navbar-brand {
            font-weight: 600;
        }
        .table-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        .status-badge {
            width: 80px;
        }
        .user-info {
            max-width: 250px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .encrypt-note {
            color: #17a2b8;
            font-style: italic;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="sidebar-sticky pt-3">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-shield fa-3x mb-2"></i>
                        <h5 class="mb-0">Admin Panel</h5>
                        <p class="small text-muted mb-0">DocuSign Management</p>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="users.php">
                                <i class="fas fa-users"></i> User Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="documents.php">
                                <i class="fas fa-file-alt"></i> Documents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="security.php">
                                <i class="fas fa-shield-alt"></i> Security Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="encryption.php">
                                <i class="fas fa-key"></i> Encryption Keys
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logs.php">
                                <i class="fas fa-clipboard-list"></i> Activity Logs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="system.php">
                                <i class="fas fa-cogs"></i> System Settings
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="border-secondary">
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-circle"></i> Admin Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Top navigation -->
                <nav class="navbar navbar-expand-lg navbar-light bg-white mb-4 shadow-sm rounded">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="../">
                                    <i class="fas fa-external-link-alt"></i> View Main Site
                                </a>
                            </li>
                        </ul>
                        <div class="dropdown">
                            <button class="btn btn-light dropdown-toggle" type="button" id="userDropdown" data-toggle="dropdown">
                                <i class="fas fa-user-circle mr-1"></i> <?php echo htmlspecialchars($admin['username']); ?>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="profile.php">
                                    <i class="fas fa-user-cog fa-fw mr-2"></i> Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt fa-fw mr-2"></i> Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </nav>
                
                <!-- Page content -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mb-4">
                    <h2><i class="fas fa-users mr-2"></i> User Management</h2>
                    <div>
                        <a href="add_user.php" class="btn btn-sm btn-primary">
                            <i class="fas fa-user-plus"></i> Add New User
                        </a>
                    </div>
                </div>
                
                <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                
                <!-- Search and filter -->
                <div class="card mb-4 border-0 shadow-sm">
                    <div class="card-body">
                        <form method="get" action="" class="form-row align-items-center">
                            <div class="col-md-6 mb-2 mb-md-0">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    </div>
                                    <input type="text" class="form-control" name="search" placeholder="Search users..." value="<?php echo htmlspecialchars($search); ?>">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-primary">Search</button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-row">
                                    <div class="col">
                                        <select class="form-control" name="status" id="statusFilter">
                                            <option value="">All Statuses</option>
                                            <option value="active">Active</option>
                                            <option value="inactive">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-2 text-md-right">
                                <?php if (!empty($search)): ?>
                                <a href="users.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Users table -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Users (<?php echo $totalUsers; ?>)</h5>
                            <div class="encrypt-note">
                                <i class="fas fa-key mr-1"></i> Sensitive data shown is encrypted
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="thead-light">
                                    <tr>
                                        <th>#</th>
                                        <th>User</th>
                                        <th>Email</th>
                                        <th>Registered</th>
                                        <th>Status</th>
                                        <th>Documents</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (count($users) > 0): ?>
                                        <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?php echo $user['id']; ?></td>
                                            <td class="user-info">
                                                <div class="d-flex align-items-center">
                                                    <div class="bg-light rounded-circle p-2 mr-2">
                                                        <i class="fas fa-user text-secondary"></i>
                                                    </div>
                                                    <div>
                                                        <div><?php echo htmlspecialchars($user['full_name']); ?></div>
                                                        <small class="text-muted"><?php echo htmlspecialchars($user['username']); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                            <td>
                                                <?php if (isset($user['status']) && $user['status'] === 'inactive'): ?>
                                                <span class="badge badge-danger status-badge">Inactive</span>
                                                <?php else: ?>
                                                <span class="badge badge-success status-badge">Active</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php 
                                                $docCount = $db->getValue("SELECT COUNT(*) FROM documents WHERE user_id = ?", [$user['id']]);
                                                echo $docCount;
                                                ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="view_user.php?id=<?php echo $user['id']; ?>" class="btn btn-info" title="View User">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-primary" title="Edit User">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <?php if (isset($user['status']) && $user['status'] === 'inactive'): ?>
                                                    <a href="users.php?user=<?php echo $user['id']; ?>&status=active" class="btn btn-success" title="Activate User">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                    <?php else: ?>
                                                    <a href="users.php?user=<?php echo $user['id']; ?>&status=inactive" class="btn btn-warning" title="Deactivate User">
                                                        <i class="fas fa-ban"></i>
                                                    </a>
                                                    <?php endif; ?>
                                                    <button type="button" class="btn btn-danger" title="Delete User" 
                                                            data-toggle="modal" data-target="#deleteModal" 
                                                            data-user-id="<?php echo $user['id']; ?>" 
                                                            data-user-name="<?php echo htmlspecialchars($user['username']); ?>">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-4">
                                                <div class="my-3">
                                                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                                    <h5>No users found</h5>
                                                    <?php if (!empty($search)): ?>
                                                    <p class="text-muted">No users match your search criteria</p>
                                                    <a href="users.php" class="btn btn-outline-primary">Clear Search</a>
                                                    <?php else: ?>
                                                    <p class="text-muted">No users have registered yet</p>
                                                    <a href="add_user.php" class="btn btn-primary">Add New User</a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <?php if ($totalPages > 1): ?>
                    <div class="card-footer bg-white">
                        <nav>
                            <ul class="pagination justify-content-center mb-0">
                                <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>">
                                        <i class="fas fa-chevron-left"></i> Previous
                                    </a>
                                </li>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>">
                                        Next <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Footer -->
                <footer class="pt-3 pb-2 text-muted border-top mt-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <span>DocuSign Management System &copy; <?php echo date('Y'); ?></span>
                        <span class="text-right">Version 1.0.0</span>
                    </div>
                </footer>
            </main>
        </div>
    </div>
    
    <!-- Delete User Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the user <strong id="deleteUserName"></strong>?</p>
                    <p>This action cannot be undone and will delete all user data including documents and signatures.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <a href="#" id="confirmDeleteBtn" class="btn btn-danger">Delete User</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap & jQuery JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        // Handle delete modal
        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var userId = button.data('user-id');
            var userName = button.data('user-name');
            
            var modal = $(this);
            modal.find('#deleteUserName').text(userName);
            modal.find('#confirmDeleteBtn').attr('href', 'users.php?delete=' + userId);
        });
        
        // Handle status filter
        $(document).ready(function() {
            // Get the status from the URL
            var urlParams = new URLSearchParams(window.location.search);
            var status = urlParams.get('status');
            
            // Set the dropdown value based on the URL parameter
            if (status) {
                $('#statusFilter').val(status);
            }
            
            // Update the form action when the status filter changes
            $('#statusFilter').on('change', function() {
                $(this).closest('form').submit();
            });
        });
    </script>
</body>
</html>