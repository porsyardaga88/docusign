<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

session_start();

// Log the logout action if admin was logged in
if (isset($_SESSION['admin_id'])) {
    $adminId = $_SESSION['admin_id'];
    
    // Log the logout action
    $db->insert(
        "INSERT INTO admin_logs (admin_id, action, action_description, ip_address) VALUES (?, ?, ?, ?)",
        [$adminId, 'logout', 'Admin logout', $_SERVER['REMOTE_ADDR']]
    );
    
    // Clear session variables
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_username']);
}

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: login.php");
exit;
?>