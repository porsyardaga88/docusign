<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

session_start();

// Check if already logged in as admin
if (isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean($_POST['username']);
    $password = $_POST['password'];
    
    // Validate input
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        // Check if admin exists
        $admin = $db->getRow("SELECT * FROM admins WHERE username = ?", [$username]);
        
        if ($admin && verifyPassword($password, $admin['password'])) {
            // Create session
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            
            // Log successful login
            $db->insert(
                "INSERT INTO admin_logs (admin_id, action, action_description, ip_address) VALUES (?, ?, ?, ?)",
                [$admin['id'], 'login', 'Admin login successful', $_SERVER['REMOTE_ADDR']]
            );
            
            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
            
            // Log failed login attempt if username exists
            if ($admin) {
                $db->insert(
                    "INSERT INTO admin_logs (admin_id, action, action_description, ip_address) VALUES (?, ?, ?, ?)",
                    [$admin['id'], 'login_failed', 'Failed login attempt', $_SERVER['REMOTE_ADDR']]
                );
            }
        }
    }
}

// Check if admin tables exist, create them if they don't
$adminTableExists = $db->getValue("SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'admins'");
if (!$adminTableExists) {
    // Create admin tables
    $db->query("
        CREATE TABLE IF NOT EXISTS admins (
            id SERIAL PRIMARY KEY,
            username VARCHAR(255) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            full_name VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL DEFAULT 'admin',
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP
        )
    ");
    
    $db->query("
        CREATE TABLE IF NOT EXISTS admin_logs (
            id SERIAL PRIMARY KEY,
            admin_id INTEGER,
            action VARCHAR(255) NOT NULL,
            action_description TEXT,
            ip_address VARCHAR(45),
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL
        )
    ");
    
    // Create default admin account
    $hashedPassword = hashPassword('admin123');
    $db->insert(
        "INSERT INTO admins (username, password, email, full_name, role) VALUES (?, ?, ?, ?, ?)",
        ['admin', $hashedPassword, 'admin@example.com', 'System Administrator', 'super_admin']
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - DocuSign Management System</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            max-width: 400px;
            width: 100%;
            padding: 15px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #343a40;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 20px;
        }
        .btn-primary {
            background-color: #343a40;
            border-color: #343a40;
        }
        .btn-primary:hover {
            background-color: #23272b;
            border-color: #23272b;
        }
        .admin-icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="text-center mb-4">
            <i class="fas fa-user-shield admin-icon text-dark"></i>
            <h2 class="font-weight-bold">Admin Portal</h2>
            <p class="text-muted">DocuSign Management System</p>
        </div>
        
        <div class="card">
            <div class="card-header text-center">
                <h4 class="mb-0">Administrator Login</h4>
            </div>
            <div class="card-body p-4">
                <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $error; ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            </div>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block mt-4">
                        <i class="fas fa-sign-in-alt mr-2"></i> Login
                    </button>
                </form>
                
                <div class="mt-3 text-center">
                    <small class="text-muted">
                        <i class="fas fa-info-circle"></i> Default credentials: admin / admin123
                    </small>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-3">
            <a href="/" class="text-muted small">
                <i class="fas fa-arrow-left mr-1"></i> Return to Main Site
            </a>
        </div>
    </div>
    
    <!-- Bootstrap & jQuery JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>