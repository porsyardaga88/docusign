<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Get admin data
$adminId = $_SESSION['admin_id'];
$admin = $db->getRow("SELECT * FROM admins WHERE id = ?", [$adminId]);

// Update last login time
$db->query("UPDATE admins SET last_login = NOW() WHERE id = ?", [$adminId]);

// Get system statistics
$totalUsers = $db->getValue("SELECT COUNT(*) FROM users");
$totalDocuments = $db->getValue("SELECT COUNT(*) FROM documents");
$totalSignatures = $db->getValue("SELECT COUNT(*) FROM signatures");
$newUsersToday = $db->getValue("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURRENT_DATE");

// Get recent user registrations
$recentUsers = $db->getRows("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");

// Get recent admin activities
$recentActivities = $db->getRows(
    "SELECT al.*, a.username FROM admin_logs al 
    LEFT JOIN admins a ON al.admin_id = a.id 
    ORDER BY al.created_at DESC LIMIT 10"
);

// Add the encryption_keys table if it doesn't exist (for storing encryption keys used by the system)
$encryptionTableExists = $db->getValue("SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'encryption_keys'");

if (!$encryptionTableExists) {
    $db->query("
        CREATE TABLE IF NOT EXISTS encryption_keys (
            id SERIAL PRIMARY KEY,
            key_name VARCHAR(255) NOT NULL UNIQUE,
            key_type VARCHAR(50) NOT NULL,
            key_value TEXT NOT NULL,
            created_by INTEGER,
            active BOOLEAN NOT NULL DEFAULT true,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_used TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
        )
    ");
    
    // Create a default system encryption key (in a real system, use a more robust method for key generation)
    $systemKey = bin2hex(random_bytes(32)); // 256-bit key
    $db->insert(
        "INSERT INTO encryption_keys (key_name, key_type, key_value, created_by) VALUES (?, ?, ?, ?)",
        ['system_default', 'aes-256', $systemKey, $adminId]
    );
}

// Add security_settings table if it doesn't exist
$securitySettingsTableExists = $db->getValue("SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'security_settings'");

if (!$securitySettingsTableExists) {
    $db->query("
        CREATE TABLE IF NOT EXISTS security_settings (
            id SERIAL PRIMARY KEY,
            setting_name VARCHAR(255) NOT NULL UNIQUE,
            setting_value TEXT NOT NULL,
            description TEXT,
            created_by INTEGER,
            updated_by INTEGER,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL,
            FOREIGN KEY (updated_by) REFERENCES admins(id) ON DELETE SET NULL
        )
    ");
    
    // Insert default security settings
    $securitySettings = [
        [
            'password_min_length', 
            '8', 
            'Minimum password length for user accounts'
        ],
        [
            'password_require_uppercase', 
            'true', 
            'Require at least one uppercase letter in passwords'
        ],
        [
            'password_require_number', 
            'true', 
            'Require at least one number in passwords'
        ],
        [
            'password_require_special', 
            'false', 
            'Require at least one special character in passwords'
        ],
        [
            'session_timeout', 
            '3600', 
            'Session timeout in seconds (3600 = 1 hour)'
        ],
        [
            'enable_encryption', 
            'true', 
            'Enable data encryption for sensitive information'
        ],
        [
            'encrypt_user_data', 
            'true', 
            'Encrypt personal user data'
        ],
        [
            'encrypt_documents', 
            'true', 
            'Encrypt stored documents'
        ],
        [
            'max_login_attempts', 
            '5', 
            'Maximum number of failed login attempts before account lockout'
        ]
    ];
    
    foreach ($securitySettings as $setting) {
        $db->insert(
            "INSERT INTO security_settings (setting_name, setting_value, description, created_by) VALUES (?, ?, ?, ?)",
            [$setting[0], $setting[1], $setting[2], $adminId]
        );
    }
}

// Function to get active encryption key
function getActiveEncryptionKey() {
    global $db;
    
    $key = $db->getRow("SELECT * FROM encryption_keys WHERE active = true ORDER BY created_at DESC LIMIT 1");
    
    if ($key) {
        // Update last used timestamp
        $db->query("UPDATE encryption_keys SET last_used = NOW() WHERE id = ?", [$key['id']]);
        return $key['key_value'];
    }
    
    return false;
}

// Simple encryption function (for demo purposes - in production, use a proper encryption library)
function encryptData($data, $key = null) {
    if ($key === null) {
        $key = getActiveEncryptionKey();
    }
    
    if (!$key) {
        return $data; // If no key is available, return data unencrypted
    }
    
    $iv = random_bytes(16); // Generate initialization vector
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', hex2bin($key), 0, $iv);
    
    if ($encrypted === false) {
        return $data; // Return original data if encryption fails
    }
    
    // Combine IV and encrypted data with a delimiter that won't appear in base64
    return base64_encode($iv) . '|' . $encrypted;
}

// Simple decryption function (for demo purposes - in production, use a proper encryption library)
function decryptData($encryptedData, $key = null) {
    if ($key === null) {
        $key = getActiveEncryptionKey();
    }
    
    if (!$key || strpos($encryptedData, '|') === false) {
        return $encryptedData; // Return as is if no key or invalid format
    }
    
    list($iv, $data) = explode('|', $encryptedData, 2);
    
    $iv = base64_decode($iv);
    
    $decrypted = openssl_decrypt($data, 'aes-256-cbc', hex2bin($key), 0, $iv);
    
    if ($decrypted === false) {
        return $encryptedData; // Return encrypted data if decryption fails
    }
    
    return $decrypted;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - DocuSign Management System</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: #fff;
            position: sticky;
            top: 0;
        }
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: calc(100vh - 48px);
            padding-top: .5rem;
            overflow-x: hidden;
            overflow-y: auto;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.75);
            padding: .75rem 1rem;
        }
        .sidebar .nav-link:hover {
            color: #fff;
        }
        .sidebar .nav-link.active {
            color: #fff;
            background-color: rgba(0, 0, 0, 0.25);
        }
        .sidebar .nav-link i {
            margin-right: .5rem;
            width: 20px;
            text-align: center;
        }
        .sidebar-heading {
            font-size: .75rem;
            text-transform: uppercase;
            padding: 1rem;
            color: rgba(255, 255, 255, 0.5);
        }
        .navbar-brand {
            font-weight: 600;
        }
        .stat-card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        .table-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        .activity-time {
            font-size: 0.8rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="sidebar-sticky pt-3">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-shield fa-3x mb-2"></i>
                        <h5 class="mb-0">Admin Panel</h5>
                        <p class="small text-muted mb-0">DocuSign Management</p>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users"></i> User Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="documents.php">
                                <i class="fas fa-file-alt"></i> Documents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="security.php">
                                <i class="fas fa-shield-alt"></i> Security Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="encryption.php">
                                <i class="fas fa-key"></i> Encryption Keys
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logs.php">
                                <i class="fas fa-clipboard-list"></i> Activity Logs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="system.php">
                                <i class="fas fa-cogs"></i> System Settings
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="border-secondary">
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user-circle"></i> Admin Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4 py-4">
                <!-- Top navigation -->
                <nav class="navbar navbar-expand-lg navbar-light bg-white mb-4 shadow-sm rounded">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="../">
                                    <i class="fas fa-external-link-alt"></i> View Main Site
                                </a>
                            </li>
                        </ul>
                        <div class="dropdown">
                            <button class="btn btn-light dropdown-toggle" type="button" id="userDropdown" data-toggle="dropdown">
                                <i class="fas fa-user-circle mr-1"></i> <?php echo htmlspecialchars($admin['username']); ?>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="profile.php">
                                    <i class="fas fa-user-cog fa-fw mr-2"></i> Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt fa-fw mr-2"></i> Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </nav>
                
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mb-4">
                    <h2><i class="fas fa-tachometer-alt mr-2"></i> Admin Dashboard</h2>
                    <div>
                        <button class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-download"></i> Export Report
                        </button>
                    </div>
                </div>
                
                <!-- Statistics cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-4 mb-md-0">
                        <div class="card border-0 stat-card h-100 bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Total Users</h5>
                                        <h2 class="mb-0"><?php echo $totalUsers; ?></h2>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-users"></i>
                                    </div>
                                </div>
                                <p class="card-text mt-2 mb-0">
                                    <span class="badge badge-light">
                                        <i class="fas fa-user-plus"></i> <?php echo $newUsersToday; ?> new today
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-4 mb-md-0">
                        <div class="card border-0 stat-card h-100 bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Documents</h5>
                                        <h2 class="mb-0"><?php echo $totalDocuments; ?></h2>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-file-alt"></i>
                                    </div>
                                </div>
                                <p class="card-text mt-2 mb-0">
                                    <span class="badge badge-light">
                                        <i class="fas fa-file-signature"></i> <?php echo $totalSignatures; ?> signatures
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-4 mb-md-0">
                        <div class="card border-0 stat-card h-100 bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Security</h5>
                                        <h2 class="mb-0">Enabled</h2>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-shield-alt"></i>
                                    </div>
                                </div>
                                <p class="card-text mt-2 mb-0">
                                    <span class="badge badge-light">
                                        <i class="fas fa-key"></i> Encryption Active
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-4 mb-md-0">
                        <div class="card border-0 stat-card h-100 bg-secondary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">System Status</h5>
                                        <h2 class="mb-0">Healthy</h2>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-server"></i>
                                    </div>
                                </div>
                                <p class="card-text mt-2 mb-0">
                                    <span class="badge badge-light">
                                        <i class="fas fa-check-circle"></i> All Systems Operational
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Recent users -->
                    <div class="col-md-6 mb-4">
                        <div class="card table-container border-0">
                            <div class="card-header bg-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Recent Users</h5>
                                    <a href="users.php" class="btn btn-sm btn-outline-primary">
                                        View All
                                    </a>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>User</th>
                                                <th>Email</th>
                                                <th>Registered</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recentUsers as $user): ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="bg-light rounded-circle p-2 mr-2">
                                                            <i class="fas fa-user text-secondary"></i>
                                                        </div>
                                                        <?php echo htmlspecialchars($user['full_name']); ?>
                                                    </div>
                                                </td>
                                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                                <td><small><?php echo date('M j, Y', strtotime($user['created_at'])); ?></small></td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php if (empty($recentUsers)): ?>
                                            <tr>
                                                <td colspan="3" class="text-center py-3">No users found</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Admin activities -->
                    <div class="col-md-6 mb-4">
                        <div class="card table-container border-0">
                            <div class="card-header bg-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Admin Activities</h5>
                                    <a href="logs.php" class="btn btn-sm btn-outline-primary">
                                        View All
                                    </a>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Admin</th>
                                                <th>Action</th>
                                                <th>Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recentActivities as $activity): ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="bg-light rounded-circle p-2 mr-2">
                                                            <i class="fas fa-user-shield text-secondary"></i>
                                                        </div>
                                                        <?php echo htmlspecialchars($activity['username'] ?? 'System'); ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php 
                                                    $actionIcon = 'fas fa-info-circle text-secondary';
                                                    
                                                    switch ($activity['action']) {
                                                        case 'login':
                                                            $actionIcon = 'fas fa-sign-in-alt text-success';
                                                            break;
                                                        case 'login_failed':
                                                            $actionIcon = 'fas fa-exclamation-triangle text-warning';
                                                            break;
                                                        case 'logout':
                                                            $actionIcon = 'fas fa-sign-out-alt text-info';
                                                            break;
                                                        case 'update':
                                                            $actionIcon = 'fas fa-edit text-primary';
                                                            break;
                                                        case 'delete':
                                                            $actionIcon = 'fas fa-trash-alt text-danger';
                                                            break;
                                                    }
                                                    ?>
                                                    <i class="<?php echo $actionIcon; ?> mr-1"></i>
                                                    <?php echo htmlspecialchars($activity['action_description']); ?>
                                                </td>
                                                <td class="activity-time">
                                                    <?php echo date('M j, g:i a', strtotime($activity['created_at'])); ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php if (empty($recentActivities)): ?>
                                            <tr>
                                                <td colspan="3" class="text-center py-3">No activities found</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- System Status -->
                <div class="row">
                    <div class="col-12 mb-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">System Security Status</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-4">
                                            <h6 class="mb-3">Data Encryption</h6>
                                            <div class="progress mb-2" style="height: 10px;">
                                                <div class="progress-bar bg-success" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                            <div class="d-flex justify-content-between small text-muted">
                                                <span>Encryption Status: <span class="text-success">Active</span></span>
                                                <span>Method: AES-256</span>
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <h6 class="mb-3">Authentication Security</h6>
                                            <div class="progress mb-2" style="height: 10px;">
                                                <div class="progress-bar bg-primary" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                            <div class="d-flex justify-content-between small text-muted">
                                                <span>Password Policy: <span class="text-success">Strong</span></span>
                                                <span>Session Timeout: 60 mins</span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="mb-4">
                                            <h6 class="mb-3">Security Recommendations</h6>
                                            <ul class="list-group">
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span><i class="fas fa-check-circle text-success mr-2"></i> Data encryption enabled</span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span><i class="fas fa-check-circle text-success mr-2"></i> Strong password policy enforced</span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span><i class="fas fa-exclamation-circle text-warning mr-2"></i> Enable two-factor authentication</span>
                                                    <a href="security.php" class="btn btn-sm btn-outline-primary">Configure</a>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span><i class="fas fa-exclamation-circle text-warning mr-2"></i> Rotate encryption keys</span>
                                                    <a href="encryption.php" class="btn btn-sm btn-outline-primary">Configure</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Footer -->
                <footer class="pt-3 pb-2 text-muted border-top mt-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <span>DocuSign Management System &copy; <?php echo date('Y'); ?></span>
                        <span class="text-right">Version 1.0.0</span>
                    </div>
                </footer>
            </main>
        </div>
    </div>
    
    <!-- Bootstrap & jQuery JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>