# DocuSign Management System User Guide

## System Overview

The DocuSign Management System is a comprehensive document management solution with electronic signature capabilities. It allows users to securely upload, send, and sign PDF documents, making document workflows simpler and more efficient.

## Features

- **Document Management**: Upload, organize, view, download, and archive documents
- **Electronic Signatures**: Sign documents directly in the browser with position-specific signature locations
- **Multiple Recipients**: Send documents to multiple recipients for signing
- **Template Management**: Use pre-built templates or create your own
- **User Management**: Admin portal for managing users and permissions
- **Secure Storage**: All documents are securely stored with user-level access control
- **Email Notifications**: Recipients are notified when they have documents to sign

## Getting Started

### System Requirements

- Modern web browser (Chrome, Firefox, Safari, or Edge)
- PDF viewer capability
- Internet connection

### Account Access

1. **Login**: Navigate to the login page and enter your credentials
   - Demo account: Username: `demo` / Password: `demo123`
   - Admin account: Username: `admin` / Password: `admin123`

2. **Registration**: New users can register by clicking "Register" on the login page

### Dashboard

The dashboard provides an overview of your document activity:
- Recent documents
- Documents by status (Draft, Sent, Signed, Completed, Archived)
- Quick access to common actions

## Working with Documents

### Uploading Documents

1. Click "Upload Document" from the dashboard or documents page
2. Select a PDF file from your computer
3. Add a description (optional)
4. Click "Upload"

### Viewing Documents

1. Navigate to the "Documents" section
2. Click on any document to view its details
3. Use the viewer to see the document content
4. Download the document if needed

### Sending Documents for Signature

1. From the documents list, find the document you want to send
2. Click the "Send" button (paper plane icon)
3. Add recipient(s) with their name and email
4. Position signature fields on the document by clicking where signatures should appear
5. Add a message (optional)
6. Click "Send" to distribute the document

### Signing Documents

When you receive a document to sign:
1. Open the link provided in the email notification
2. Review the document
3. Click on each signature field
4. Sign using the signature pad
5. Click "Complete Signing" when finished

### Using Templates

1. Navigate to the "Templates" section
2. Browse available templates
3. Preview or download a template
4. Create a document from a template by clicking "Use Template"
5. Upload your own template in PDF format by clicking "Upload Template"

## Admin Functions

The admin portal provides additional functionality for managing the system:

### User Management

1. Login to the admin portal with admin credentials
2. Navigate to "Users"
3. View all registered users
4. Activate/deactivate accounts
5. Reset passwords

### System Monitoring

The admin dashboard provides system statistics:
- Total users
- Document counts
- Recent activity
- System health

## Security Features

- All data is encrypted in transit
- Database information is encrypted
- User authentication with password hashing
- Role-based access control
- Session timeout protection

## Troubleshooting

### Common Issues

1. **Can't upload documents**
   - Check your file format (only PDF is supported)
   - Ensure the file size is under 5MB
   - Verify you have appropriate permissions

2. **Email notifications not received**
   - Check spam/junk folders
   - Verify the email address is correct
   - Contact your system administrator

3. **Can't view document**
   - Ensure you have PDF viewing capability in your browser
   - Try downloading the document to view locally
   - Verify you have permission to access the document

### Getting Help

For additional assistance, contact your system administrator or support team.