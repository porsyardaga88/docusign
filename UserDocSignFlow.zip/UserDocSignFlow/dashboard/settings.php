<?php
// Set page title
$page_title = "Settings";

// Include necessary files
require_once '../config/database.php';
require_once '../includes/header.php';

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Initialize variables
$notification_email = true;
$notification_browser = true;
$update_success = $update_error = "";

// Get user settings if they exist
$stmt = $conn->prepare("SELECT notification_email, notification_browser FROM user_settings WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $settings = $result->fetch_assoc();
    $notification_email = (bool)$settings['notification_email'];
    $notification_browser = (bool)$settings['notification_browser'];
}

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get values from form
    $notification_email = isset($_POST['notification_email']) ? 1 : 0;
    $notification_browser = isset($_POST['notification_browser']) ? 1 : 0;
    
    // Check if settings already exist
    $stmt = $conn->prepare("SELECT id FROM user_settings WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update existing settings
        $stmt = $conn->prepare("UPDATE user_settings SET notification_email = ?, notification_browser = ? WHERE user_id = ?");
        $stmt->bind_param("iii", $notification_email, $notification_browser, $user_id);
    } else {
        // Insert new settings
        $stmt = $conn->prepare("INSERT INTO user_settings (user_id, notification_email, notification_browser) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $user_id, $notification_email, $notification_browser);
    }
    
    if ($stmt->execute()) {
        $update_success = "Your settings have been updated successfully.";
    } else {
        $update_error = "Something went wrong. Please try again later.";
    }
    
    // Close statement
    $stmt->close();
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Settings</h1>
    </div>

    <?php if (!empty($update_success)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $update_success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($update_error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $update_error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Notification Settings</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="mb-3 form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="notification_email" name="notification_email" <?php echo $notification_email ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="notification_email">Receive email notifications</label>
                            <div class="form-text">Get notified when documents are ready for signing or have been signed.</div>
                        </div>
                        
                        <div class="mb-3 form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="notification_browser" name="notification_browser" <?php echo $notification_browser ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="notification_browser">Enable browser notifications</label>
                            <div class="form-text">Receive browser notifications when you're using the application.</div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">Save Settings</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Email Templates</h5>
                </div>
                <div class="card-body">
                    <form action="#" method="post" id="emailTemplateForm">
                        <div class="mb-3">
                            <label for="signatureRequest" class="form-label">Signature Request Template</label>
                            <textarea class="form-control" id="signatureRequest" name="signatureRequest" rows="4">Hello,

I've sent you a document to sign using DocuSign Management System. Please click on the link below to view and sign the document:

{DOCUMENT_LINK}

Thanks,
{SENDER_NAME}</textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="signatureComplete" class="form-label">Signature Complete Template</label>
                            <textarea class="form-control" id="signatureComplete" name="signatureComplete" rows="4">Hello,

The document "{DOCUMENT_TITLE}" has been signed successfully. You can download the signed document from your dashboard or using the link below:

{DOCUMENT_LINK}

Thanks,
DocuSign Management System</textarea>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">Save Templates</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Account Information</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <p class="form-control-static"><?php echo htmlspecialchars($_SESSION['name']); ?></p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <p class="form-control-static"><?php echo htmlspecialchars($_SESSION['email']); ?></p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Account Status</label>
                        <p class="form-control-static"><span class="badge bg-success">Active</span></p>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <a href="../dashboard/profile.php" class="btn btn-outline-primary">Edit Profile</a>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">Danger Zone</h5>
                </div>
                <div class="card-body">
                    <p>Permanently delete your account and all associated data.</p>
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                            Delete Account
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Account Modal -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-labelledby="deleteAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteAccountModalLabel">Confirm Account Deletion</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete your account? This action <strong>cannot be undone</strong> and will permanently delete all your documents and data.</p>
                <div class="mb-3">
                    <label for="confirmDelete" class="form-label">Type "DELETE" to confirm</label>
                    <input type="text" class="form-control" id="confirmDelete" placeholder="DELETE">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn" disabled>Delete Account</button>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once '../includes/footer.php';
?>
