<?php
// Set page title
$page_title = "My Documents";

// Include necessary files
require_once '../config/database.php';
require_once '../includes/header.php';

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Check if status filter is set
$status_filter = isset($_GET['status']) ? (int)$_GET['status'] : null;

// Prepare the SQL query based on the filter
if ($status_filter !== null) {
    $sql = "SELECT id, title, filename, status, recipient_email, created_at FROM documents WHERE user_id = ? AND status = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $status_filter);
} else {
    $sql = "SELECT id, title, filename, status, recipient_email, created_at FROM documents WHERE user_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
}

// Execute the query
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">My Documents</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="../documents/upload.php" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-upload"></i> Upload Document
                </a>
            </div>
        </div>
    </div>

    <!-- Filter Options -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Filter Documents</h5>
                        <div>
                            <a href="documents.php" class="btn btn-sm <?php echo !isset($_GET['status']) ? 'btn-primary' : 'btn-outline-primary'; ?>">All</a>
                            <a href="documents.php?status=0" class="btn btn-sm <?php echo isset($_GET['status']) && $_GET['status'] == '0' ? 'btn-warning' : 'btn-outline-warning'; ?>">Pending</a>
                            <a href="documents.php?status=1" class="btn btn-sm <?php echo isset($_GET['status']) && $_GET['status'] == '1' ? 'btn-success' : 'btn-outline-success'; ?>">Signed</a>
                            <a href="documents.php?status=2" class="btn btn-sm <?php echo isset($_GET['status']) && $_GET['status'] == '2' ? 'btn-danger' : 'btn-outline-danger'; ?>">Expired</a>
                            <a href="documents.php?status=3" class="btn btn-sm <?php echo isset($_GET['status']) && $_GET['status'] == '3' ? 'btn-danger' : 'btn-outline-danger'; ?>">Rejected</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Documents List -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if ($result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Filename</th>
                                        <th>Recipient</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($doc = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($doc['title']); ?></td>
                                            <td><?php echo htmlspecialchars($doc['filename']); ?></td>
                                            <td><?php echo htmlspecialchars($doc['recipient_email'] ?? 'N/A'); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo getDocumentStatusClass($doc['status']); ?>">
                                                    <?php echo getDocumentStatus($doc['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo formatDate($doc['created_at']); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="../documents/view.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-outline-primary" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="../documents/send.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-outline-success" title="Send">
                                                        <i class="fas fa-paper-plane"></i>
                                                    </a>
                                                    <a href="../documents/download.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-outline-info" title="Download">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $doc['id']; ?>" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                                
                                                <!-- Delete Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo $doc['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure you want to delete the document "<?php echo htmlspecialchars($doc['title']); ?>"?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                                <a href="../documents/delete.php?id=<?php echo $doc['id']; ?>" class="btn btn-danger">Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No documents found.
                            <?php if ($status_filter !== null): ?>
                                <a href="documents.php">View all documents</a>
                            <?php else: ?>
                                <a href="../documents/upload.php">Upload your first document</a> to get started.
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once '../includes/footer.php';
?>
