<?php
// Set page title
$page_title = "Dashboard";

// Include necessary files
require_once '../config/database.php';
require_once '../includes/header.php';

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Get count of documents
$stmt = $conn->prepare("SELECT COUNT(*) as total_docs FROM documents WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_docs = $row['total_docs'];

// Get count of pending signatures
$stmt = $conn->prepare("SELECT COUNT(*) as pending_signs FROM documents WHERE status = 0 AND user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$pending_signs = $row['pending_signs'];

// Get count of completed signatures
$stmt = $conn->prepare("SELECT COUNT(*) as completed_signs FROM documents WHERE status = 1 AND user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$completed_signs = $row['completed_signs'];

// Get recent documents
$stmt = $conn->prepare("SELECT id, title, filename, status, created_at FROM documents WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$recent_docs = $stmt->get_result();
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="../documents/upload.php" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-upload"></i> Upload Document
                </a>
            </div>
        </div>
    </div>

    <!-- Dashboard Cards -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-primary mb-3">
                <div class="card-body text-primary">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Total Documents</h5>
                            <h2 class="card-text"><?php echo $total_docs; ?></h2>
                        </div>
                        <i class="fas fa-file-pdf fa-3x"></i>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-primary">
                    <a href="documents.php" class="text-primary text-decoration-none">View all documents <i class="fas fa-arrow-right ms-1"></i></a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card border-warning mb-3">
                <div class="card-body text-warning">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Pending Signatures</h5>
                            <h2 class="card-text"><?php echo $pending_signs; ?></h2>
                        </div>
                        <i class="fas fa-clock fa-3x"></i>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-warning">
                    <a href="documents.php?status=0" class="text-warning text-decoration-none">View pending documents <i class="fas fa-arrow-right ms-1"></i></a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card border-success mb-3">
                <div class="card-body text-success">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title">Completed Signatures</h5>
                            <h2 class="card-text"><?php echo $completed_signs; ?></h2>
                        </div>
                        <i class="fas fa-check-circle fa-3x"></i>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-success">
                    <a href="documents.php?status=1" class="text-success text-decoration-none">View signed documents <i class="fas fa-arrow-right ms-1"></i></a>
                </div>
            </div>
        </div>
    </div>

    <!-- Banner Image -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-0">
                    <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f" class="img-fluid rounded" alt="Document Signing">
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Documents -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Recent Documents</h5>
                </div>
                <div class="card-body">
                    <?php if ($recent_docs->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Filename</th>
                                        <th>Status</th>
                                        <th>Date Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($doc = $recent_docs->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($doc['title']); ?></td>
                                            <td><?php echo htmlspecialchars($doc['filename']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo getDocumentStatusClass($doc['status']); ?>">
                                                    <?php echo getDocumentStatus($doc['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo formatDate($doc['created_at']); ?></td>
                                            <td>
                                                <a href="../documents/view.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="../documents/send.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-outline-success">
                                                    <i class="fas fa-paper-plane"></i>
                                                </a>
                                                <a href="../documents/download.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-outline-info">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No documents found. <a href="../documents/upload.php">Upload your first document</a> to get started.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- System Features -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-file-signature fa-4x text-primary mb-3"></i>
                    <h5 class="card-title">Digital Signatures</h5>
                    <p class="card-text">Create legally binding digital signatures on your documents with our easy-to-use signature tool.</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-envelope fa-4x text-primary mb-3"></i>
                    <h5 class="card-title">Email Integration</h5>
                    <p class="card-text">Send documents to multiple recipients for signing and track the status of each document.</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body text-center">
                    <i class="fas fa-shield-alt fa-4x text-primary mb-3"></i>
                    <h5 class="card-title">Secure Storage</h5>
                    <p class="card-text">All your documents are stored securely and can be accessed anytime, anywhere.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once '../includes/footer.php';
?>
