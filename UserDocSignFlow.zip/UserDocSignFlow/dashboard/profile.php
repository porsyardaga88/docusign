<?php
// Set page title
$page_title = "Profile";

// Include necessary files
require_once '../config/database.php';
require_once '../includes/header.php';

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Initialize variables
$name = $email = $profile_image = "";
$update_success = $update_error = "";

// Get user data
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $name = $user['name'];
    $email = $user['email'];
}

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty(trim($_POST["name"]))) {
        $update_error = "Please enter your name.";
    } else {
        $name = sanitize($_POST["name"]);
    }
    
    // If there's no error, proceed with update
    if (empty($update_error)) {
        // Update user information
        $stmt = $conn->prepare("UPDATE users SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $user_id);
        
        if ($stmt->execute()) {
            // Update session variables
            $_SESSION["name"] = $name;
            $update_success = "Your profile has been updated successfully.";
        } else {
            $update_error = "Something went wrong. Please try again later.";
        }
        
        // Close statement
        $stmt->close();
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">My Profile</h1>
    </div>

    <?php if (!empty($update_success)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $update_success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($update_error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $update_error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf" class="rounded-circle img-fluid" style="width: 150px; height: 150px; object-fit: cover;" alt="Profile Image">
                    </div>
                    <h5 class="card-title"><?php echo htmlspecialchars($name); ?></h5>
                    <p class="card-text text-muted"><?php echo htmlspecialchars($email); ?></p>
                    <p class="card-text">
                        <small class="text-muted">Member since: <?php echo date("F j, Y", strtotime($_SESSION['created_at'] ?? 'now')); ?></small>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Edit Profile</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($email); ?>" disabled>
                            <div class="form-text">Email address cannot be changed.</div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Change Password</h5>
                </div>
                <div class="card-body">
                    <form action="#" method="post" id="changePasswordForm">
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">Change Password</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once '../includes/footer.php';
?>
